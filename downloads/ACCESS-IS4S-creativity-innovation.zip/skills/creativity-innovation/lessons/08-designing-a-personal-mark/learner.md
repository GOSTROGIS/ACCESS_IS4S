---
title: Designing your own personal mark
summary: Design an original symbol for your toolbox, business card or portfolio, research what it stands for, and present it.
level: 1-2
time: 90 min
components: Use your imagination and curiosity; Generate ideas that are novel to yourself or others; Develop your ideas
rebuilds: A - Computer Use/assigment criteria ik.docx
---

# Designing your own personal mark

## Why this matters on the job

Tradespeople mark their tools so they come home from a shared site. Contractors and small trade businesses need a simple mark for a truck door, a business card or an invoice, so customers remember them. Designing a mark is also a good way to practise creativity: you choose something that says how you work, try many versions, and test whether other people read it the way you meant.

## Key ideas

**Why this lesson says "personal mark", not "totem" or "crest".** The English word "totem" comes from Ojibwe. The Ojibwe People's Dictionary gives the word stem doodem- with the meaning "clan, totem." On the Northwest Coast, the animals carved on totem poles are crests. The Canadian Encyclopedia describes these crests as "the property of specific family lineages." It also says totem poles are specific to certain First Nations, and have been wrongly used as a general symbol of Canada. Clans and crests belong to the families and Nations they come from, and are passed on by their own protocols.

So in this lesson:

- you do not design a totem or a crest, and you do not call your mark one
- you do not copy designs or art styles that belong to a Nation, such as Northwest Coast formline
- if your own family or Nation has clan or crest traditions, those come to you through your family and community. You are not asked to share them or use them here

**What a personal mark is.** A simple symbol you draw yourself. It can come from an animal, a plant, a tool, an object, a place or a shape that says something about how you work. For example, a level for someone who cares about getting it right, or a bridge for someone who likes connecting people.

**What makes a mark work:**

- **simple**: a few shapes, no fine detail
- **readable small and from far away**: it still makes sense at 2 cm wide on a hard hat sticker
- **works in one colour**: so it can be stamped, engraved or photocopied
- **original**: your own drawing, not copied from a company logo, clip art or someone else's culture

<div class="figure-art">
<svg viewBox="0 0 720 400" width="100%" role="img" aria-labelledby="cr08-f1-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="cr08-f1-title">Two marks drawn at three sizes. The detailed mark with many thin lines becomes a smudge when small. The simple three-line mark on a level line stays clear at about 2 cm.</title>
<defs><marker id="cr08-f1-ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#222222"/></marker><marker id="cr08-f1-ds" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0,1.5 L10,5 L0,8.5 z" fill="#222222"/></marker></defs>
<rect x="0" y="0" width="720" height="400" fill="#ffffff"/>
<text x="360.0" y="28.0" font-size="20" text-anchor="middle" font-weight="bold" fill="#222222">Test a mark big and small</text>
<text x="200.0" y="70.0" font-size="15" text-anchor="middle" font-weight="normal" fill="#6b6b6b">large</text>
<text x="400.0" y="70.0" font-size="15" text-anchor="middle" font-weight="normal" fill="#6b6b6b">medium</text>
<text x="600.0" y="70.0" font-size="15" text-anchor="middle" font-weight="normal" fill="#6b6b6b">about 2 cm</text>
<text x="20.0" y="160.0" font-size="16" text-anchor="start" font-weight="bold" fill="#b3261e">Detailed</text>
<text x="20.0" y="300.0" font-size="16" text-anchor="start" font-weight="bold" fill="#2e6b34">Simple</text>
<line x1="200.0" y1="150.0" x2="224.0" y2="108.4" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="230.2" y2="112.7" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="235.7" y2="117.9" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="240.3" y2="123.9" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="243.9" y2="130.5" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="246.4" y2="137.6" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="247.7" y2="145.0" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="247.9" y2="152.5" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="247.0" y2="160.0" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="244.8" y2="167.2" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="241.6" y2="174.0" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="237.3" y2="180.2" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="232.1" y2="185.7" stroke="#222222" stroke-width="1.6"/>
<line x1="200.0" y1="150.0" x2="226.1" y2="190.3" stroke="#222222" stroke-width="1.6"/>
<circle cx="216.0" cy="114.8" r="9.6" fill="none" stroke="#222222" stroke-width="1.6"/>
<line x1="155.2" y1="198.0" x2="164.8" y2="178.8" stroke="#222222" stroke-width="1.2800000000000002"/>
<line x1="161.6" y1="198.0" x2="171.2" y2="178.8" stroke="#222222" stroke-width="1.2800000000000002"/>
<line x1="168.0" y1="198.0" x2="177.6" y2="178.8" stroke="#222222" stroke-width="1.2800000000000002"/>
<line x1="174.4" y1="198.0" x2="184.0" y2="178.8" stroke="#222222" stroke-width="1.2800000000000002"/>
<line x1="180.8" y1="198.0" x2="190.4" y2="178.8" stroke="#222222" stroke-width="1.2800000000000002"/>
<line x1="187.2" y1="198.0" x2="196.8" y2="178.8" stroke="#222222" stroke-width="1.2800000000000002"/>
<circle cx="200.0" cy="150.0" r="54.4" fill="none" stroke="#222222" stroke-width="1.6" stroke-dasharray="2 2"/>
<line x1="400.0" y1="150.0" x2="415.0" y2="124.0" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="418.9" y2="126.7" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="422.3" y2="129.9" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="425.2" y2="133.7" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="427.4" y2="137.8" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="429.0" y2="142.2" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="429.8" y2="146.9" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="430.0" y2="151.6" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="429.3" y2="156.2" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="428.0" y2="160.8" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="426.0" y2="165.0" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="423.3" y2="168.9" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="420.1" y2="172.3" stroke="#222222" stroke-width="1.0"/>
<line x1="400.0" y1="150.0" x2="416.3" y2="175.2" stroke="#222222" stroke-width="1.0"/>
<circle cx="410.0" cy="128.0" r="6.0" fill="none" stroke="#222222" stroke-width="1.0"/>
<line x1="372.0" y1="180.0" x2="378.0" y2="168.0" stroke="#222222" stroke-width="0.8"/>
<line x1="376.0" y1="180.0" x2="382.0" y2="168.0" stroke="#222222" stroke-width="0.8"/>
<line x1="380.0" y1="180.0" x2="386.0" y2="168.0" stroke="#222222" stroke-width="0.8"/>
<line x1="384.0" y1="180.0" x2="390.0" y2="168.0" stroke="#222222" stroke-width="0.8"/>
<line x1="388.0" y1="180.0" x2="394.0" y2="168.0" stroke="#222222" stroke-width="0.8"/>
<line x1="392.0" y1="180.0" x2="398.0" y2="168.0" stroke="#222222" stroke-width="0.8"/>
<circle cx="400.0" cy="150.0" r="34.0" fill="none" stroke="#222222" stroke-width="1.0" stroke-dasharray="2 2"/>
<line x1="600.0" y1="150.0" x2="606.0" y2="139.6" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="607.6" y2="140.7" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="608.9" y2="142.0" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="610.1" y2="143.5" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="611.0" y2="145.1" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="611.6" y2="146.9" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="611.9" y2="148.7" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="612.0" y2="150.6" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="611.7" y2="152.5" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="611.2" y2="154.3" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="610.4" y2="156.0" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="609.3" y2="157.6" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="608.0" y2="158.9" stroke="#222222" stroke-width="0.6"/>
<line x1="600.0" y1="150.0" x2="606.5" y2="160.1" stroke="#222222" stroke-width="0.6"/>
<circle cx="604.0" cy="141.2" r="2.4" fill="none" stroke="#222222" stroke-width="0.6"/>
<line x1="588.8" y1="162.0" x2="591.2" y2="157.2" stroke="#222222" stroke-width="0.5"/>
<line x1="590.4" y1="162.0" x2="592.8" y2="157.2" stroke="#222222" stroke-width="0.5"/>
<line x1="592.0" y1="162.0" x2="594.4" y2="157.2" stroke="#222222" stroke-width="0.5"/>
<line x1="593.6" y1="162.0" x2="596.0" y2="157.2" stroke="#222222" stroke-width="0.5"/>
<line x1="595.2" y1="162.0" x2="597.6" y2="157.2" stroke="#222222" stroke-width="0.5"/>
<line x1="596.8" y1="162.0" x2="599.2" y2="157.2" stroke="#222222" stroke-width="0.5"/>
<circle cx="600.0" cy="150.0" r="13.6" fill="none" stroke="#222222" stroke-width="0.6" stroke-dasharray="2 2"/>
<line x1="158.0" y1="332.0" x2="242.0" y2="332.0" stroke="#222222" stroke-width="7.0"/>
<line x1="200.0" y1="332.0" x2="200.0" y2="276.0" stroke="#222222" stroke-width="7.0"/>
<line x1="200.0" y1="276.0" x2="222.4" y2="248.0" stroke="#222222" stroke-width="7.0"/>
<line x1="222.4" y1="248.0" x2="242.0" y2="253.6" stroke="#222222" stroke-width="7.0"/>
<line x1="373.0" y1="317.0" x2="427.0" y2="317.0" stroke="#222222" stroke-width="4.5"/>
<line x1="400.0" y1="317.0" x2="400.0" y2="281.0" stroke="#222222" stroke-width="4.5"/>
<line x1="400.0" y1="281.0" x2="414.4" y2="263.0" stroke="#222222" stroke-width="4.5"/>
<line x1="414.4" y1="263.0" x2="427.0" y2="266.6" stroke="#222222" stroke-width="4.5"/>
<line x1="588.0" y1="302.0" x2="612.0" y2="302.0" stroke="#222222" stroke-width="2.0"/>
<line x1="600.0" y1="302.0" x2="600.0" y2="286.0" stroke="#222222" stroke-width="2.0"/>
<line x1="600.0" y1="286.0" x2="606.4" y2="278.0" stroke="#222222" stroke-width="2.0"/>
<line x1="606.4" y1="278.0" x2="612.0" y2="279.6" stroke="#222222" stroke-width="2.0"/>
<line x1="20.0" y1="220.0" x2="700.0" y2="220.0" stroke="#bdb6aa" stroke-width="1"/>
<text x="360.0" y="385.0" font-size="15" text-anchor="middle" font-weight="normal" fill="#6b6b6b">At 2 cm the detailed mark turns to a smudge. The simple mark still reads.</text>
</svg>
</div>

**Research what you chose.** If your mark comes from an animal or plant, find out about it from a reliable source, the way the original ACCESS assignment asked:

- its attributes (what it looks like and does)
- its habitat and range (where it lives)
- its role in the food chain
- its conservation status

Two official places to look up conservation status:

- Species at Risk Public Registry (Government of Canada): https://www.canada.ca/en/environment-climate-change/services/species-risk-public-registry.html
- BC Species and Ecosystems Explorer (Government of BC): https://a100.gov.bc.ca/pub/eswp/

COSEWIC, the national committee that assesses wildlife, uses these status categories: Extinct, Extirpated, Endangered, Threatened, Special Concern, Data Deficient and Not At Risk. Write down where you found each fact and the date you checked it.

### Worked example

Kai is training for carpentry. He lists five things that say how he works: a level, a heron, a framing square, a river, a cedar plank. He picks the heron. He has watched herons on the river near his home wait a long time and then move fast, and that is how he likes to measure and cut.

He looks up the great blue heron on the BC Species and Ecosystems Explorer and writes down its status, the source and the date. He uses the same site and a second reliable source for its habitat and what it eats.

He sketches six versions: a full heron, a heron head only, a heron standing on a level line, a heron inside a circle, a heron made from three straight lines, and the letter K shaped like a heron's leg. At 2 cm wide, his partner thinks the full heron is "a bird of some kind" and the three-line heron is "a heron with a level." Kai picks the three-line version. It is simple, works in black only, and is his own drawing.

## Practice

**Task 1** (level 1) List five animals, plants, tools or objects that say something about how you work. Write one word beside each to say why. Circle the one you will use.

1. ______________________ Why: ______________
2. ______________________ Why: ______________
3. ______________________ Why: ______________
4. ______________________ Why: ______________
5. ______________________ Why: ______________

**Task 2** (level 2) Research your choice. If it is an animal or plant, find its attributes, habitat and range, role in the food chain and conservation status. If it is a tool or object, find what it is used for and one fact about how it is made or where it came from. Write the source and the date for each fact.

| Fact | Source (website name and address) | Date checked |
|---|---|---|
| | | |
| | | |
| | | |
| | | |

**Task 3** (level 2) Sketch at least six different versions of your mark. Make them different in shape or idea, not just in colour. Keep every sketch.

**Task 4** (level 2) Test two of your sketches. Draw each one about 2 cm wide in black only. Show them to a partner from about 3 m away. Ask, "What do you see?" Write down what they say. Improve the one you like best.

What my partner saw: ______________________________________________

What I changed: ______________________________________________

**Task 5** (level 2) Make 5 to 8 slides in PowerPoint or Google Slides, or a one-page poster. Include:

- a title slide or poster heading with your name, the date and your mark
- what your mark comes from
- your research facts, each with its source
- how the mark relates to you and the way you work
- two or three earlier sketches and the final mark, with a sentence on what changed

**Task 6** (level 2) Present for 2 minutes. When others present, give one positive, specific comment and ask one question.

## Check yourself

1. Why does this lesson use the words "personal mark" instead of "totem" or "crest"?
2. Name three things that make a mark work well.
3. Name the two official places in this lesson where you can look up a species' conservation status.
4. Why do you test your mark at a small size, from a distance?
