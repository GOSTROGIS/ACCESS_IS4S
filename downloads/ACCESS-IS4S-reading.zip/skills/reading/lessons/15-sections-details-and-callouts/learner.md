---
title: Sections, details and callouts
summary: Read cutting-plane lines and section views, name common material hatch patterns, and follow section marks and detail callouts from one sheet to another.
level: 1-3
time: 90 min
components: Identify the information; Make connections between different parts of the document(s); Understand and apply the information; Evaluate the document(s)
---

# Sections, details and callouts

## Why this matters on the job

Plans and elevations show the outside of things. To see how a wall, a footing or a pipe fitting is built inside, drawings **cut** through it and show the cut face. These cut views are called **sections**. Small, tricky areas, such as where a wall sits on a foundation, are drawn bigger as **details**. Small symbols on the drawings, called **callouts**, tell you which sheet to turn to. A drawing set can have hundreds of sheets. If you can follow a callout, you can find the one detail that answers your question. This lesson follows [Reading lesson 13](../13-lines-and-dimensions/learner.html) (lines) and [Reading lesson 14](../14-drawing-scales/learner.html) (scales).

## Key ideas

**1. Cutting plane and section view.** A **cutting-plane line** (thick, with a long dash and two short dashes) shows where the object is cut. The **arrows** at its ends show which way you look at the cut. The letters at the ends, such as **A-A**, name the section. The section view is labelled with the same letters, such as **SECTION A-A**.

**2. Section lines (hatching).** In a section view, the surfaces the cut passes through are filled with thin lines or a pattern. Holes and empty spaces are left blank. Edges you see beyond the cut are drawn as object lines. Hidden lines are usually not needed.

**3. Kinds of section.**

- **Full section:** the cut goes all the way through the object.
- **Half section:** one quarter of the object is cut away. Half the view shows the outside and half shows the inside. It is used for round, matching parts such as bushings and flanges.
- **Broken-out section:** only a small area is cut open, bounded by a thick, wavy break line. It shows one feature, such as a drilled hole, without cutting the whole part.

**4. Material hatch patterns.** On building drawings, the pattern tells you the material. Common ones are concrete (dots and small triangles), earth, gravel, brick (45° lines), concrete block, wood framing cut across the grain (a box with an X), finish wood, steel, batt insulation (a looping line) and rigid insulation (a crosshatch). Patterns are not the same in every office. **Always check the legend** of the drawing set.

**5. Section marks.** On a plan, a section is shown by a cut line with a **bubble** at the end. The bubble is split by a line. The **top** number is the section number. The **bottom** is the **sheet** it is drawn on. **1 over A-301** means section 1 on sheet A-301. A solid triangle on the bubble points the way you look.

**6. Detail callouts.** A circle or box drawn around an area, with a bubble such as **3 over A-501**, means that area is drawn bigger as detail 3 on sheet A-501. **Elevation markers** use the same kind of bubble, with a triangle pointing at the wall that is shown.

**7. Drawing titles close the loop.** Under each section or detail is a **title** with the same bubble, its name and its scale. When you arrive at sheet A-501, look for the title bubble **3 over A-501**. Details are drawn at a bigger scale (such as 1:5 or 3" = 1'-0") so small parts can be read.

**8. Sheet numbers.** The letter at the front of a sheet number often tells you the discipline, such as **A** for architectural or **S** for structural. The number tells you where the sheet sits in the set. Real drawing sets are covered in Reading lesson 16.

<div class="figure-art">
<svg viewBox="0 0 720 560" width="100%" role="img" aria-labelledby="rd15-f1-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd15-f1-title">Section views of a flanged steel bushing. Top left: the top view, with cutting-plane line A-A across the middle and arrows pointing up. Below it: SECTION A-A, a full section, with the cut steel hatched, the bore through the middle and a bolt hole through the flange on each side. Top right: a half section of the same bushing, with the left half drawn as the outside and the right half cut. Bottom right: a steel shaft with a broken-out section at one end that shows a drilled hole.</title>
<defs><pattern id="rd15-f1-steel" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f1-brick" patternUnits="userSpaceOnUse" width="8" height="8" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="8" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f1-conc" patternUnits="userSpaceOnUse" width="40" height="40"><circle cx="13.31" cy="6.73" r="0.9" fill="#111111"/><circle cx="25.74" cy="3.75" r="0.9" fill="#111111"/><circle cx="21.36" cy="14.9" r="0.9" fill="#111111"/><circle cx="3.2" cy="20.28" r="0.9" fill="#111111"/><circle cx="2.42" cy="17.48" r="0.9" fill="#111111"/><circle cx="3.65" cy="4.45" r="0.9" fill="#111111"/><circle cx="17.13" cy="32.42" r="0.9" fill="#111111"/><circle cx="5.7" cy="9.48" r="0.9" fill="#111111"/><circle cx="24.84" cy="37.01" r="0.9" fill="#111111"/><circle cx="22.93" cy="16.07" r="0.9" fill="#111111"/><circle cx="38.1" cy="2.77" r="0.9" fill="#111111"/><circle cx="33.62" cy="12.01" r="0.9" fill="#111111"/><circle cx="6.48" cy="5.48" r="0.9" fill="#111111"/><circle cx="12.72" cy="32.01" r="0.9" fill="#111111"/><polygon points="7.73,20.16 12.93,22.05 8.69,25.62" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="18.87,22.76 13.38,23.47 15.5,18.35" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="4.55,7.69 9.1,10.87 4.08,13.22" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="14.93,12.41 20.48,12.49 17.64,17.25" fill="none" stroke="#111111" stroke-width="0.8"/></pattern><pattern id="rd15-f1-cmu" patternUnits="userSpaceOnUse" width="14" height="14"><line x1="0" y1="14" x2="14" y2="0" stroke="#111111" stroke-width="0.8"/><circle cx="4" cy="4" r="0.8" fill="#111111"/><circle cx="10" cy="9" r="0.8" fill="#111111"/></pattern><pattern id="rd15-f1-earth" patternUnits="userSpaceOnUse" width="40" height="40"><line x1="6" y1="11" x2="10" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="8.5" y1="11" x2="12.5" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="11" y1="11" x2="15" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="24" y1="15" x2="28" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="26.5" y1="15" x2="30.5" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="29" y1="15" x2="33" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="14" y1="29" x2="18" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="16.5" y1="29" x2="20.5" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="19" y1="29" x2="23" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="32" y1="33" x2="36" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="34.5" y1="33" x2="38.5" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="37" y1="33" x2="41" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="4" y1="39" x2="8" y2="33" stroke="#111111" stroke-width="0.9"/><line x1="6.5" y1="39" x2="10.5" y2="33" stroke="#111111" stroke-width="0.9"/><line x1="9" y1="39" x2="13" y2="33" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f1-gravel" patternUnits="userSpaceOnUse" width="30" height="30"><ellipse cx="13.86" cy="16.43" rx="2.7" ry="1.67" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="15.19" cy="17.1" rx="1.74" ry="1.71" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="18.12" cy="22.03" rx="1.62" ry="1.5" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="5.18" cy="22.43" rx="2.4" ry="1.24" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="26.57" cy="26.15" rx="2.35" ry="1.82" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="6.78" cy="3.36" rx="2.19" ry="1.26" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="7.56" cy="8.81" rx="1.54" ry="1.66" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="13.57" cy="23.22" rx="2.17" ry="1.84" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="14.99" cy="18.9" rx="2.09" ry="1.48" fill="none" stroke="#111111" stroke-width="0.8"/></pattern><pattern id="rd15-f1-rigid" patternUnits="userSpaceOnUse" width="8" height="8"><line x1="0" y1="0" x2="8" y2="8" stroke="#111111" stroke-width="0.7"/><line x1="8" y1="0" x2="0" y2="8" stroke="#111111" stroke-width="0.7"/></pattern><pattern id="rd15-f1-fwood" patternUnits="userSpaceOnUse" width="30" height="7"><path d="M0 3.5 Q7.5 0 15 3.5 T30 3.5" fill="none" stroke="#111111" stroke-width="0.8"/></pattern></defs>
<rect x="0" y="0" width="720" height="560" fill="#ffffff"/>
<circle cx="175" cy="120" r="100" fill="none" stroke="#111111" stroke-width="2.6"/>
<circle cx="175" cy="120" r="60" fill="none" stroke="#111111" stroke-width="2.6"/>
<circle cx="175" cy="120" r="30" fill="none" stroke="#111111" stroke-width="2.6"/>
<circle cx="95" cy="120" r="10" fill="none" stroke="#111111" stroke-width="2.6"/>
<line x1="95" y1="104" x2="95" y2="136" stroke="#111111" stroke-width="1.1" stroke-dasharray="22 4 5 4" fill="none" stroke-linecap="butt"/>
<circle cx="255" cy="120" r="10" fill="none" stroke="#111111" stroke-width="2.6"/>
<line x1="255" y1="104" x2="255" y2="136" stroke="#111111" stroke-width="1.1" stroke-dasharray="22 4 5 4" fill="none" stroke-linecap="butt"/>
<line x1="175" y1="4" x2="175" y2="236" stroke="#111111" stroke-width="1.1" stroke-dasharray="22 4 5 4" fill="none" stroke-linecap="butt"/>
<line x1="51" y1="120" x2="299" y2="120" stroke="#111111" stroke-width="3" stroke-dasharray="24 5 6 5 6 5" fill="none" stroke-linecap="butt"/>
<line x1="51" y1="120" x2="51" y2="94" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="51,94 54.15,103.49 47.85,103.49" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="39" y="102" font-size="16" text-anchor="middle" font-weight="bold" fill="#111111">A</text>
<line x1="299" y1="120" x2="299" y2="94" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="299,94 302.15,103.49 295.85,103.49" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="311" y="102" font-size="16" text-anchor="middle" font-weight="bold" fill="#111111">A</text>
<text x="175" y="246" font-size="14" text-anchor="middle" font-weight="bold" fill="#111111">TOP VIEW</text>
<polygon points="145,470 105,470 105,440 115,440 115,370 145,370" fill="url(#rd15-f1-steel)" stroke="none"/>
<polygon points="145,470 105,470 105,440 115,440 115,370 145,370" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="85,470 75,470 75,440 85,440" fill="url(#rd15-f1-steel)" stroke="none"/>
<polygon points="85,470 75,470 75,440 85,440" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="205,470 245,470 245,440 235,440 235,370 205,370" fill="url(#rd15-f1-steel)" stroke="none"/>
<polygon points="205,470 245,470 245,440 235,440 235,370 205,370" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="265,470 275,470 275,440 265,440" fill="url(#rd15-f1-steel)" stroke="none"/>
<polygon points="265,470 275,470 275,440 265,440" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<line x1="145" y1="470" x2="205" y2="470" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="145" y1="370" x2="205" y2="370" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="105" y1="470" x2="85" y2="470" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="105" y1="440" x2="85" y2="440" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="245" y1="470" x2="265" y2="470" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="245" y1="440" x2="265" y2="440" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="175" y1="482" x2="175" y2="358" stroke="#111111" stroke-width="1.1" stroke-dasharray="22 4 5 4" fill="none" stroke-linecap="butt"/>
<line x1="95" y1="480" x2="95" y2="430" stroke="#111111" stroke-width="1.1" stroke-dasharray="22 4 5 4" fill="none" stroke-linecap="butt"/>
<line x1="255" y1="480" x2="255" y2="430" stroke="#111111" stroke-width="1.1" stroke-dasharray="22 4 5 4" fill="none" stroke-linecap="butt"/>
<text x="175" y="500" font-size="14" text-anchor="middle" font-weight="bold" fill="#111111">SECTION A-A (full section)</text>
<line x1="75" y1="254" x2="75" y2="436" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<line x1="275" y1="254" x2="275" y2="436" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<polyline points="545,230 445,230 445,200 485,200 485,130 545,130" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="575,230 615,230 615,200 605,200 605,130 575,130" fill="url(#rd15-f1-steel)" stroke="none"/>
<polygon points="575,230 615,230 615,200 605,200 605,130 575,130" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="635,230 645,230 645,200 635,200" fill="url(#rd15-f1-steel)" stroke="none"/>
<polygon points="635,230 645,230 645,200 635,200" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<line x1="545" y1="230" x2="575" y2="230" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="545" y1="130" x2="575" y2="130" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="615" y1="230" x2="635" y2="230" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="615" y1="200" x2="635" y2="200" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="545" y1="246" x2="545" y2="114" stroke="#111111" stroke-width="1.1" stroke-dasharray="22 4 5 4" fill="none" stroke-linecap="butt"/>
<text x="545" y="260" font-size="14" text-anchor="middle" font-weight="bold" fill="#111111">HALF SECTION</text>
<text x="445" y="280" font-size="13" text-anchor="start" font-weight="normal" fill="#777777">outside</text>
<text x="645" y="280" font-size="13" text-anchor="end" font-weight="normal" fill="#777777">cut</text>
<line x1="430" y1="386" x2="702" y2="386" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="430" y1="454" x2="702" y2="454" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="430" y1="386" x2="430" y2="454" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="702" y1="386" x2="702" y2="454" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="620.4,386 622.5,388.27 624.4,390.53 625.9,392.8 626.87,395.07 627.2,397.33 626.87,399.6 625.9,401.87 624.4,404.13 622.5,406.4 620.4,408.67 618.3,410.93 616.4,413.2 614.9,415.47 613.93,417.73 613.6,420 613.93,422.27 614.9,424.53 616.4,426.8 618.3,429.07 620.4,431.33 622.5,433.6 624.4,435.87 625.9,438.13 626.87,440.4 627.2,442.67 626.87,444.93 625.9,447.2 624.4,449.47 622.5,451.73 620.4,454 702,454 702,386" fill="url(#rd15-f1-steel)" stroke="none"/>
<polygon points="702,409.8 651,409.8 644.87,420 651,430.2 702,430.2" fill="#ffffff" stroke="none"/>
<polyline points="702,409.8 651,409.8 644.87,420 651,430.2 702,430.2" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<line x1="651" y1="409.8" x2="651" y2="430.2" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polyline points="620.4,386 622.5,388.27 624.4,390.53 625.9,392.8 626.87,395.07 627.2,397.33 626.87,399.6 625.9,401.87 624.4,404.13 622.5,406.4 620.4,408.67 618.3,410.93 616.4,413.2 614.9,415.47 613.93,417.73 613.6,420 613.93,422.27 614.9,424.53 616.4,426.8 618.3,429.07 620.4,431.33 622.5,433.6 624.4,435.87 625.9,438.13 626.87,440.4 627.2,442.67 626.87,444.93 625.9,447.2 624.4,449.47 622.5,451.73 620.4,454" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="round"/>
<line x1="416.4" y1="420" x2="715.6" y2="420" stroke="#111111" stroke-width="1.1" stroke-dasharray="22 4 5 4" fill="none" stroke-linecap="butt"/>
<text x="566" y="480" font-size="14" text-anchor="middle" font-weight="bold" fill="#111111">BROKEN-OUT SECTION</text>
<polyline points="668,408.8 634,356 583,356" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<polygon points="668,408.8 660.22,402.52 665.51,399.12" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="578" y="362" font-size="13" text-anchor="end" font-weight="normal" fill="#111111">drilled hole</text>
</svg>
</div>

*Figure 1. Section views of a flanged steel bushing. Top left: the top view, with cutting-plane line A-A through the middle and arrows pointing up (toward the back). Bottom left: SECTION A-A, a full section, with the cut steel hatched and the bore and two bolt holes left blank. Top right: a half section, with the outside on the left half and the cut on the right half. Bottom right: a steel shaft with a broken-out section at one end showing a drilled hole.*

<div class="figure-art">
<svg viewBox="0 0 640 400" width="100%" role="img" aria-labelledby="rd15-f2-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd15-f2-title">Material symbols in section, as used in many drawing sets. Concrete: dots and small triangles. Earth: short strokes in clusters. Gravel: small open circles. Brick masonry: diagonal lines at 45 degrees. Concrete block: diagonal lines with dots. Wood framing cut across the grain: a box with a diagonal cross. Finish wood: wavy grain lines. Steel: close diagonal lines. Batt insulation: a looping line. Rigid insulation: a crosshatch. Always check the legend of the drawing set you are using.</title>
<defs><pattern id="rd15-f2-steel" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f2-brick" patternUnits="userSpaceOnUse" width="8" height="8" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="8" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f2-conc" patternUnits="userSpaceOnUse" width="40" height="40"><circle cx="13.31" cy="6.73" r="0.9" fill="#111111"/><circle cx="25.74" cy="3.75" r="0.9" fill="#111111"/><circle cx="21.36" cy="14.9" r="0.9" fill="#111111"/><circle cx="3.2" cy="20.28" r="0.9" fill="#111111"/><circle cx="2.42" cy="17.48" r="0.9" fill="#111111"/><circle cx="3.65" cy="4.45" r="0.9" fill="#111111"/><circle cx="17.13" cy="32.42" r="0.9" fill="#111111"/><circle cx="5.7" cy="9.48" r="0.9" fill="#111111"/><circle cx="24.84" cy="37.01" r="0.9" fill="#111111"/><circle cx="22.93" cy="16.07" r="0.9" fill="#111111"/><circle cx="38.1" cy="2.77" r="0.9" fill="#111111"/><circle cx="33.62" cy="12.01" r="0.9" fill="#111111"/><circle cx="6.48" cy="5.48" r="0.9" fill="#111111"/><circle cx="12.72" cy="32.01" r="0.9" fill="#111111"/><polygon points="7.73,20.16 12.93,22.05 8.69,25.62" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="18.87,22.76 13.38,23.47 15.5,18.35" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="4.55,7.69 9.1,10.87 4.08,13.22" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="14.93,12.41 20.48,12.49 17.64,17.25" fill="none" stroke="#111111" stroke-width="0.8"/></pattern><pattern id="rd15-f2-cmu" patternUnits="userSpaceOnUse" width="14" height="14"><line x1="0" y1="14" x2="14" y2="0" stroke="#111111" stroke-width="0.8"/><circle cx="4" cy="4" r="0.8" fill="#111111"/><circle cx="10" cy="9" r="0.8" fill="#111111"/></pattern><pattern id="rd15-f2-earth" patternUnits="userSpaceOnUse" width="40" height="40"><line x1="6" y1="11" x2="10" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="8.5" y1="11" x2="12.5" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="11" y1="11" x2="15" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="24" y1="15" x2="28" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="26.5" y1="15" x2="30.5" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="29" y1="15" x2="33" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="14" y1="29" x2="18" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="16.5" y1="29" x2="20.5" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="19" y1="29" x2="23" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="32" y1="33" x2="36" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="34.5" y1="33" x2="38.5" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="37" y1="33" x2="41" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="4" y1="39" x2="8" y2="33" stroke="#111111" stroke-width="0.9"/><line x1="6.5" y1="39" x2="10.5" y2="33" stroke="#111111" stroke-width="0.9"/><line x1="9" y1="39" x2="13" y2="33" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f2-gravel" patternUnits="userSpaceOnUse" width="30" height="30"><ellipse cx="13.86" cy="16.43" rx="2.7" ry="1.67" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="15.19" cy="17.1" rx="1.74" ry="1.71" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="18.12" cy="22.03" rx="1.62" ry="1.5" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="5.18" cy="22.43" rx="2.4" ry="1.24" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="26.57" cy="26.15" rx="2.35" ry="1.82" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="6.78" cy="3.36" rx="2.19" ry="1.26" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="7.56" cy="8.81" rx="1.54" ry="1.66" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="13.57" cy="23.22" rx="2.17" ry="1.84" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="14.99" cy="18.9" rx="2.09" ry="1.48" fill="none" stroke="#111111" stroke-width="0.8"/></pattern><pattern id="rd15-f2-rigid" patternUnits="userSpaceOnUse" width="8" height="8"><line x1="0" y1="0" x2="8" y2="8" stroke="#111111" stroke-width="0.7"/><line x1="8" y1="0" x2="0" y2="8" stroke="#111111" stroke-width="0.7"/></pattern><pattern id="rd15-f2-fwood" patternUnits="userSpaceOnUse" width="30" height="7"><path d="M0 3.5 Q7.5 0 15 3.5 T30 3.5" fill="none" stroke="#111111" stroke-width="0.8"/></pattern></defs>
<rect x="0" y="0" width="640" height="400" fill="#ffffff"/>
<rect x="30" y="30" width="90" height="46" fill="url(#rd15-f2-conc)" stroke="none"/>
<rect x="30" y="30" width="90" height="46" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="134" y="59" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Concrete</text>
<rect x="340" y="30" width="90" height="46" fill="url(#rd15-f2-earth)" stroke="none"/>
<rect x="340" y="30" width="90" height="46" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="444" y="59" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Earth</text>
<rect x="30" y="100" width="90" height="46" fill="url(#rd15-f2-gravel)" stroke="none"/>
<rect x="30" y="100" width="90" height="46" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="134" y="129" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Gravel</text>
<rect x="340" y="100" width="90" height="46" fill="url(#rd15-f2-brick)" stroke="none"/>
<rect x="340" y="100" width="90" height="46" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="444" y="129" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Brick masonry</text>
<rect x="30" y="170" width="90" height="46" fill="url(#rd15-f2-cmu)" stroke="none"/>
<rect x="30" y="170" width="90" height="46" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="134" y="199" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Concrete block (CMU)</text>
<rect x="340" y="170" width="90" height="46" fill="#ffffff" stroke="#111111" stroke-width="2.6"/>
<line x1="340" y1="170" x2="430" y2="216" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="430" y1="170" x2="340" y2="216" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="444" y="199" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Wood framing (cut)</text>
<rect x="30" y="240" width="90" height="46" fill="url(#rd15-f2-fwood)" stroke="none"/>
<rect x="30" y="240" width="90" height="46" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="134" y="269" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Finish wood</text>
<rect x="340" y="240" width="90" height="46" fill="url(#rd15-f2-steel)" stroke="none"/>
<rect x="340" y="240" width="90" height="46" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="444" y="269" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Steel (or general use)</text>
<rect x="30" y="310" width="90" height="46" fill="none" stroke="#111111" stroke-width="1.1"/>
<g transform="rotate(-90 75 333)">
<path d="M 56 288 C 97.8 288 97.8 299.25 75 299.25 C 52.2 299.25 52.2 310.5 56 310.5 C 97.8 310.5 97.8 321.75 75 321.75 C 52.2 321.75 52.2 333 56 333 C 97.8 333 97.8 344.25 75 344.25 C 52.2 344.25 52.2 355.5 56 355.5 C 97.8 355.5 97.8 366.75 75 366.75 C 52.2 366.75 52.2 378 56 378 " fill="none" stroke="#111111" stroke-width="0.9"/>
</g>
<text x="134" y="339" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Batt insulation</text>
<rect x="340" y="310" width="90" height="46" fill="url(#rd15-f2-rigid)" stroke="none"/>
<rect x="340" y="310" width="90" height="46" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="444" y="339" font-size="16" text-anchor="start" font-weight="normal" fill="#111111">Rigid insulation</text>
<text x="320" y="388" font-size="14" text-anchor="middle" font-weight="normal" fill="#b3261e">Patterns vary between offices. Always read the legend.</text>
</svg>
</div>

*Figure 2. Common material symbols in section. Concrete: dots and small triangles. Earth: short strokes in clusters. Gravel: small open circles. Brick masonry: 45° lines. Concrete block: diagonal lines with dots. Wood framing cut across the grain: a box with a diagonal cross. Finish wood: wavy grain lines. Steel or general use: close diagonal lines. Batt insulation: a looping line. Rigid insulation: a crosshatch.*

### Worked example 1: read a section view

**Question:** In Figure 1, the bushing flange is 100 mm across, the hub is 60 mm across, and the bore is 30 mm across. How thick is the hub wall, and why are there blank gaps in the flange in SECTION A-A?

1. The cutting-plane line goes straight through the centre, so the section shows the full width of each part.
2. Hub wall thickness = (hub diameter − bore) ÷ 2 = (60 − 30) ÷ 2 = 30 ÷ 2 = **15 mm**. Brackets first (BEDMAS).
3. In the top view, the cutting-plane line passes through the two small bolt holes. A hole has no steel to cut, so in the section it is left blank. The lines across the top and bottom of each gap are the far side of the hole.

**Answer:** the hub wall is 15 mm thick. The gaps are the two bolt holes, cut through their centres.

<div class="figure-art">
<svg viewBox="0 0 640 720" width="100%" role="img" aria-labelledby="rd15-f3-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd15-f3-title">Simplified wall section of a small wood-frame building on a concrete foundation, for reading practice. Letters A to F mark hatched areas. A: dots and small triangles in the footing, the foundation wall and the floor slab. B: short strokes in clusters, outside the foundation and under the footing. C: small open circles under the slab. D: a crosshatch under the slab and on the inside of the foundation wall. E: a box with a diagonal cross on top of the foundation wall. F: a looping line in the wall cavity. A detail callout circle around the sill area points to a bubble reading 3 over A-501.</title>
<defs><pattern id="rd15-f3-steel" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f3-brick" patternUnits="userSpaceOnUse" width="8" height="8" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="8" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f3-conc" patternUnits="userSpaceOnUse" width="40" height="40"><circle cx="13.31" cy="6.73" r="0.9" fill="#111111"/><circle cx="25.74" cy="3.75" r="0.9" fill="#111111"/><circle cx="21.36" cy="14.9" r="0.9" fill="#111111"/><circle cx="3.2" cy="20.28" r="0.9" fill="#111111"/><circle cx="2.42" cy="17.48" r="0.9" fill="#111111"/><circle cx="3.65" cy="4.45" r="0.9" fill="#111111"/><circle cx="17.13" cy="32.42" r="0.9" fill="#111111"/><circle cx="5.7" cy="9.48" r="0.9" fill="#111111"/><circle cx="24.84" cy="37.01" r="0.9" fill="#111111"/><circle cx="22.93" cy="16.07" r="0.9" fill="#111111"/><circle cx="38.1" cy="2.77" r="0.9" fill="#111111"/><circle cx="33.62" cy="12.01" r="0.9" fill="#111111"/><circle cx="6.48" cy="5.48" r="0.9" fill="#111111"/><circle cx="12.72" cy="32.01" r="0.9" fill="#111111"/><polygon points="7.73,20.16 12.93,22.05 8.69,25.62" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="18.87,22.76 13.38,23.47 15.5,18.35" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="4.55,7.69 9.1,10.87 4.08,13.22" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="14.93,12.41 20.48,12.49 17.64,17.25" fill="none" stroke="#111111" stroke-width="0.8"/></pattern><pattern id="rd15-f3-cmu" patternUnits="userSpaceOnUse" width="14" height="14"><line x1="0" y1="14" x2="14" y2="0" stroke="#111111" stroke-width="0.8"/><circle cx="4" cy="4" r="0.8" fill="#111111"/><circle cx="10" cy="9" r="0.8" fill="#111111"/></pattern><pattern id="rd15-f3-earth" patternUnits="userSpaceOnUse" width="40" height="40"><line x1="6" y1="11" x2="10" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="8.5" y1="11" x2="12.5" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="11" y1="11" x2="15" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="24" y1="15" x2="28" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="26.5" y1="15" x2="30.5" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="29" y1="15" x2="33" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="14" y1="29" x2="18" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="16.5" y1="29" x2="20.5" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="19" y1="29" x2="23" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="32" y1="33" x2="36" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="34.5" y1="33" x2="38.5" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="37" y1="33" x2="41" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="4" y1="39" x2="8" y2="33" stroke="#111111" stroke-width="0.9"/><line x1="6.5" y1="39" x2="10.5" y2="33" stroke="#111111" stroke-width="0.9"/><line x1="9" y1="39" x2="13" y2="33" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f3-gravel" patternUnits="userSpaceOnUse" width="30" height="30"><ellipse cx="13.86" cy="16.43" rx="2.7" ry="1.67" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="15.19" cy="17.1" rx="1.74" ry="1.71" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="18.12" cy="22.03" rx="1.62" ry="1.5" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="5.18" cy="22.43" rx="2.4" ry="1.24" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="26.57" cy="26.15" rx="2.35" ry="1.82" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="6.78" cy="3.36" rx="2.19" ry="1.26" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="7.56" cy="8.81" rx="1.54" ry="1.66" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="13.57" cy="23.22" rx="2.17" ry="1.84" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="14.99" cy="18.9" rx="2.09" ry="1.48" fill="none" stroke="#111111" stroke-width="0.8"/></pattern><pattern id="rd15-f3-rigid" patternUnits="userSpaceOnUse" width="8" height="8"><line x1="0" y1="0" x2="8" y2="8" stroke="#111111" stroke-width="0.7"/><line x1="8" y1="0" x2="0" y2="8" stroke="#111111" stroke-width="0.7"/></pattern><pattern id="rd15-f3-fwood" patternUnits="userSpaceOnUse" width="30" height="7"><path d="M0 3.5 Q7.5 0 15 3.5 T30 3.5" fill="none" stroke="#111111" stroke-width="0.8"/></pattern></defs>
<rect x="0" y="0" width="640" height="720" fill="#ffffff"/>
<polygon points="140,303 250,303 250,534 206,534 206,578 140,578" fill="url(#rd15-f3-earth)"/>
<polygon points="140,578 448,578 448,622 140,622" fill="url(#rd15-f3-earth)"/>
<line x1="140" y1="303" x2="250" y2="303" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="144.4" y="296.4" font-size="12" text-anchor="start" font-weight="normal" fill="#777777">GRADE</text>
<polygon points="206,534 338,534 338,578 206,578" fill="url(#rd15-f3-conc)" stroke="none"/>
<polygon points="206,534 338,534 338,578 206,578" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="250,226 294,226 294,534 250,534" fill="url(#rd15-f3-conc)" stroke="none"/>
<polygon points="250,226 294,226 294,534 250,534" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="294,292 305,292 305,534 294,534" fill="url(#rd15-f3-rigid)" stroke="none"/>
<polygon points="294,292 305,292 305,534 294,534" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="305,270 448,270 448,292 305,292" fill="url(#rd15-f3-conc)" stroke="none"/>
<polygon points="305,270 448,270 448,292 305,292" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<line x1="294" y1="270" x2="305" y2="270" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="305,292 448,292 448,303 305,303" fill="url(#rd15-f3-rigid)" stroke="none"/>
<polygon points="305,292 448,292 448,303 305,303" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="305,303 448,303 448,336 305,336" fill="url(#rd15-f3-gravel)" stroke="none"/>
<polygon points="305,303 448,303 448,336 305,336" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="305,336 448,336 448,578 338,578 338,534 305,534" fill="url(#rd15-f3-earth)"/>
<rect x="250" y="217.64" width="30.8" height="8.36" fill="#ffffff" stroke="#111111" stroke-width="2.6"/>
<line x1="250" y1="217.64" x2="280.8" y2="226" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="280.8" y1="217.64" x2="250" y2="226" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="250" y1="217.64" x2="250" y2="50" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="280.8" y1="217.64" x2="280.8" y2="50" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<path d="M 251.76 50 C 281.77 50 281.77 58.38 265.4 58.38 C 249.03 58.38 249.03 66.76 251.76 66.76 C 281.77 66.76 281.77 75.15 265.4 75.15 C 249.03 75.15 249.03 83.53 251.76 83.53 C 281.77 83.53 281.77 91.91 265.4 91.91 C 249.03 91.91 249.03 100.29 251.76 100.29 C 281.77 100.29 281.77 108.67 265.4 108.67 C 249.03 108.67 249.03 117.06 251.76 117.06 C 281.77 117.06 281.77 125.44 265.4 125.44 C 249.03 125.44 249.03 133.82 251.76 133.82 C 281.77 133.82 281.77 142.2 265.4 142.2 C 249.03 142.2 249.03 150.58 251.76 150.58 C 281.77 150.58 281.77 158.97 265.4 158.97 C 249.03 158.97 249.03 167.35 251.76 167.35 C 281.77 167.35 281.77 175.73 265.4 175.73 C 249.03 175.73 249.03 184.11 251.76 184.11 C 281.77 184.11 281.77 192.49 265.4 192.49 C 249.03 192.49 249.03 200.88 251.76 200.88 C 281.77 200.88 281.77 209.26 265.4 209.26 C 249.03 209.26 249.03 217.64 251.76 217.64 " fill="none" stroke="#111111" stroke-width="0.9"/>
<rect x="247.36" y="50" width="2.64" height="176" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<rect x="280.8" y="50" width="2.86" height="167.64" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<line x1="241.2" y1="50" x2="294" y2="50" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polyline points="241.2,50 258.8,50 262.1,42 266.5,58 269.8,50 294,50" fill="none" stroke="#111111" stroke-width="1.1"/>
<rect x="261" y="408" width="22" height="22" fill="#ffffff" stroke="#1f5fa8" stroke-width="1.4"/>
<text x="272" y="425" font-size="16" text-anchor="middle" font-weight="bold" fill="#1f5fa8">A</text>
<rect x="173" y="408" width="22" height="22" fill="#ffffff" stroke="#1f5fa8" stroke-width="1.4"/>
<text x="184" y="425" font-size="16" text-anchor="middle" font-weight="bold" fill="#1f5fa8">B</text>
<rect x="382" y="303.5" width="22" height="22" fill="#ffffff" stroke="#1f5fa8" stroke-width="1.4"/>
<text x="393" y="320.5" font-size="16" text-anchor="middle" font-weight="bold" fill="#1f5fa8">C</text>
<line x1="373.2" y1="419" x2="299.5" y2="424" stroke="#1f5fa8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<circle cx="299.5" cy="424" r="2.5" fill="#1f5fa8"/>
<rect x="362.2" y="408" width="22" height="22" fill="#ffffff" stroke="#1f5fa8" stroke-width="1.4"/>
<text x="373.2" y="425" font-size="16" text-anchor="middle" font-weight="bold" fill="#1f5fa8">D</text>
<line x1="173" y1="214.4" x2="254.4" y2="221.82" stroke="#1f5fa8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<circle cx="254.4" cy="221.82" r="2.5" fill="#1f5fa8"/>
<rect x="162" y="203.4" width="22" height="22" fill="#ffffff" stroke="#1f5fa8" stroke-width="1.4"/>
<text x="173" y="220.4" font-size="16" text-anchor="middle" font-weight="bold" fill="#1f5fa8">E</text>
<line x1="173" y1="111" x2="265.4" y2="116" stroke="#1f5fa8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<circle cx="265.4" cy="116" r="2.5" fill="#1f5fa8"/>
<rect x="162" y="100" width="22" height="22" fill="#ffffff" stroke="#1f5fa8" stroke-width="1.4"/>
<text x="173" y="117" font-size="16" text-anchor="middle" font-weight="bold" fill="#1f5fa8">F</text>
<rect x="382" y="265" width="22" height="22" fill="#ffffff" stroke="#1f5fa8" stroke-width="1.4"/>
<text x="393" y="282" font-size="16" text-anchor="middle" font-weight="bold" fill="#1f5fa8">A</text>
<rect x="261" y="542.2" width="22" height="22" fill="#ffffff" stroke="#1f5fa8" stroke-width="1.4"/>
<text x="272" y="559.2" font-size="16" text-anchor="middle" font-weight="bold" fill="#1f5fa8">A</text>
<circle cx="272" cy="237" r="46" fill="none" stroke="#111111" stroke-width="1.1"/>
<circle cx="272" cy="237" r="46" fill="none" stroke="#111111" stroke-width="1.2" stroke-dasharray="8 4"/>
<line x1="306.5" y1="206.64" x2="367" y2="166" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<circle cx="393" cy="160" r="26" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="393" cy="160" r="26" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="367" y1="160" x2="419" y2="160" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="393" y="153" font-size="16" text-anchor="middle" font-weight="bold" fill="#111111">3</text>
<text x="393" y="178" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">A-501</text>
<text x="427" y="166" font-size="13" text-anchor="start" font-weight="normal" fill="#111111">DETAIL</text>
<circle cx="70" cy="680" r="26" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="70" cy="680" r="26" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="44" y1="680" x2="96" y2="680" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="70" y="673" font-size="16" text-anchor="middle" font-weight="bold" fill="#111111">1</text>
<text x="70" y="698" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">A-301</text>
<line x1="96" y1="680" x2="250" y2="680" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<text x="104" y="672" font-size="16" text-anchor="start" font-weight="bold" fill="#111111">WALL SECTION</text>
<text x="104" y="698" font-size="13" text-anchor="start" font-weight="normal" fill="#111111">SCALE 1:20</text>
<text x="620" y="706" font-size="12" text-anchor="end" font-weight="normal" fill="#777777">For reading practice only</text>
</svg>
</div>

*Figure 3. Wall section 1 on sheet A-301 (fictional, for reading practice), scale 1:20. Letters A to F mark hatched areas. A: dots and small triangles, in the footing, the foundation wall and the floor slab. B: short strokes in clusters, outside the foundation. C: small open circles, under the slab. D: a crosshatch, under the slab and on the inside face of the foundation wall. E: a box with a diagonal cross, on top of the foundation wall. F: a looping line, in the wall cavity. A detail callout circle around the sill area points to a bubble reading 3 over A-501.*

<div class="figure-art">
<svg viewBox="0 0 700 500" width="100%" role="img" aria-labelledby="rd15-f4-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd15-f4-title">Reference symbols. 1: a section mark: a cut line across the plan with a bubble at each end, a solid triangle pointing the way you look, and the bubble reading 1 over A-301. 2: a detail callout: a dashed circle around an area with a bubble reading 3 over A-501. 3: an elevation marker: a bubble reading 2 over A-201 with a triangle pointing at the wall to be shown. 4: an interior elevation marker with four triangles numbered 1 to 4 on sheet A-401. 5: a drawing title: bubble 3 over A-301, the name of the detail and its scale.</title>
<rect x="0" y="0" width="700" height="500" fill="#ffffff"/>
<text x="30" y="32" font-size="16" text-anchor="start" font-weight="bold" fill="#111111">1  Section mark</text>
<rect x="60" y="70" width="240" height="90" fill="none" stroke="#111111" stroke-width="2.6"/>
<line x1="180" y1="50" x2="180" y2="180" stroke="#111111" stroke-width="3" stroke-dasharray="24 5 6 5 6 5" fill="none" stroke-linecap="butt"/>
<polygon points="180,186 180,234 140,210" fill="#111111"/>
<circle cx="180" cy="210" r="24" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="180" cy="210" r="24" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="156" y1="210" x2="204" y2="210" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="180" y="203" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">1</text>
<text x="180" y="228" font-size="11" text-anchor="middle" font-weight="normal" fill="#111111">A-301</text>
<text x="60" y="268" font-size="13" text-anchor="start" font-weight="normal" fill="#111111">Cut here. Look the way the</text>
<text x="60" y="286" font-size="13" text-anchor="start" font-weight="normal" fill="#111111">triangle points. Drawn as</text>
<text x="60" y="304" font-size="13" text-anchor="start" font-weight="normal" fill="#111111">section 1 on sheet A-301.</text>
<text x="370" y="32" font-size="16" text-anchor="start" font-weight="bold" fill="#111111">2  Detail callout</text>
<line x1="380" y1="140" x2="520" y2="140" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="450" y1="140" x2="450" y2="70" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<circle cx="450" cy="140" r="34" fill="none" stroke="#111111" stroke-width="1.2" stroke-dasharray="8 4"/>
<line x1="474" y1="116" x2="570" y2="80" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<circle cx="596" cy="80" r="26" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="596" cy="80" r="26" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="570" y1="80" x2="622" y2="80" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="596" y="73" font-size="16" text-anchor="middle" font-weight="bold" fill="#111111">3</text>
<text x="596" y="98" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">A-501</text>
<text x="380" y="200" font-size="13" text-anchor="start" font-weight="normal" fill="#111111">The circled area is drawn larger</text>
<text x="380" y="218" font-size="13" text-anchor="start" font-weight="normal" fill="#111111">as detail 3 on sheet A-501.</text>
<text x="30" y="360" font-size="16" text-anchor="start" font-weight="bold" fill="#111111">3  Elevation marker</text>
<line x1="40" y1="458" x2="160" y2="458" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="80,415 120,415 100,451" fill="#111111"/>
<circle cx="100" cy="415" r="20" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="100" cy="415" r="20" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="80" y1="415" x2="120" y2="415" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="100" y="408" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">2</text>
<text x="100" y="428" font-size="10" text-anchor="middle" font-weight="normal" fill="#111111">A-201</text>
<text x="240" y="360" font-size="16" text-anchor="start" font-weight="bold" fill="#111111">4  Interior elevations</text>
<polygon points="320,396 336.78,423.48 303.22,423.48" fill="#111111"/>
<text x="320" y="389" font-size="13" text-anchor="middle" font-weight="bold" fill="#111111">1</text>
<polygon points="354,430 326.52,446.78 326.52,413.22" fill="#111111"/>
<text x="366" y="435" font-size="13" text-anchor="middle" font-weight="bold" fill="#111111">2</text>
<polygon points="320,464 303.22,436.52 336.78,436.52" fill="#111111"/>
<text x="320" y="481" font-size="13" text-anchor="middle" font-weight="bold" fill="#111111">3</text>
<polygon points="286,430 313.48,413.22 313.48,446.78" fill="#111111"/>
<text x="274" y="435" font-size="13" text-anchor="middle" font-weight="bold" fill="#111111">4</text>
<circle cx="320" cy="430" r="18" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<text x="320" y="435" font-size="10" text-anchor="middle" font-weight="normal" fill="#111111">A-401</text>
<text x="470" y="360" font-size="16" text-anchor="start" font-weight="bold" fill="#111111">5  Drawing title</text>
<circle cx="500" cy="420" r="26" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="500" cy="420" r="26" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="474" y1="420" x2="526" y2="420" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="500" y="413" font-size="16" text-anchor="middle" font-weight="bold" fill="#111111">3</text>
<text x="500" y="438" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">A-501</text>
<line x1="526" y1="420" x2="680" y2="420" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<text x="534" y="412" font-size="16" text-anchor="start" font-weight="bold" fill="#111111">SILL DETAIL</text>
<text x="534" y="438" font-size="13" text-anchor="start" font-weight="normal" fill="#111111">SCALE 1:5</text>
</svg>
</div>

*Figure 4. Reference symbols. 1: a section mark with a bubble reading 1 over A-301 and a triangle showing the viewing direction. 2: a detail callout, a dashed circle with a bubble reading 3 over A-501. 3: an elevation marker reading 2 over A-201, with a triangle pointing at the wall to be shown. 4: an interior elevation marker with four triangles, numbered 1 to 4, on sheet A-401. 5: a drawing title: bubble 3 over A-501, SILL DETAIL, SCALE 1:5.*

<div class="figure-art">
<svg viewBox="0 0 720 360" width="100%" role="img" aria-labelledby="rd15-f5-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd15-f5-title">Three sheets that refer to each other. Sheet A-101, the floor plan, has a section mark 1 over A-301 across an outside wall. Sheet A-301, the wall sections, shows section 1 with a detail callout 3 over A-501 at the sill. Sheet A-501, the details, shows detail 3, the sill, drawn larger. Arrows show the path from the plan to the section to the detail.</title>
<defs><pattern id="rd15-f5-steel" patternUnits="userSpaceOnUse" width="6" height="6" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="6" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f5-brick" patternUnits="userSpaceOnUse" width="8" height="8" patternTransform="rotate(45)"><line x1="0" y1="0" x2="0" y2="8" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f5-conc" patternUnits="userSpaceOnUse" width="40" height="40"><circle cx="13.31" cy="6.73" r="0.9" fill="#111111"/><circle cx="25.74" cy="3.75" r="0.9" fill="#111111"/><circle cx="21.36" cy="14.9" r="0.9" fill="#111111"/><circle cx="3.2" cy="20.28" r="0.9" fill="#111111"/><circle cx="2.42" cy="17.48" r="0.9" fill="#111111"/><circle cx="3.65" cy="4.45" r="0.9" fill="#111111"/><circle cx="17.13" cy="32.42" r="0.9" fill="#111111"/><circle cx="5.7" cy="9.48" r="0.9" fill="#111111"/><circle cx="24.84" cy="37.01" r="0.9" fill="#111111"/><circle cx="22.93" cy="16.07" r="0.9" fill="#111111"/><circle cx="38.1" cy="2.77" r="0.9" fill="#111111"/><circle cx="33.62" cy="12.01" r="0.9" fill="#111111"/><circle cx="6.48" cy="5.48" r="0.9" fill="#111111"/><circle cx="12.72" cy="32.01" r="0.9" fill="#111111"/><polygon points="7.73,20.16 12.93,22.05 8.69,25.62" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="18.87,22.76 13.38,23.47 15.5,18.35" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="4.55,7.69 9.1,10.87 4.08,13.22" fill="none" stroke="#111111" stroke-width="0.8"/><polygon points="14.93,12.41 20.48,12.49 17.64,17.25" fill="none" stroke="#111111" stroke-width="0.8"/></pattern><pattern id="rd15-f5-cmu" patternUnits="userSpaceOnUse" width="14" height="14"><line x1="0" y1="14" x2="14" y2="0" stroke="#111111" stroke-width="0.8"/><circle cx="4" cy="4" r="0.8" fill="#111111"/><circle cx="10" cy="9" r="0.8" fill="#111111"/></pattern><pattern id="rd15-f5-earth" patternUnits="userSpaceOnUse" width="40" height="40"><line x1="6" y1="11" x2="10" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="8.5" y1="11" x2="12.5" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="11" y1="11" x2="15" y2="5" stroke="#111111" stroke-width="0.9"/><line x1="24" y1="15" x2="28" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="26.5" y1="15" x2="30.5" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="29" y1="15" x2="33" y2="9" stroke="#111111" stroke-width="0.9"/><line x1="14" y1="29" x2="18" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="16.5" y1="29" x2="20.5" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="19" y1="29" x2="23" y2="23" stroke="#111111" stroke-width="0.9"/><line x1="32" y1="33" x2="36" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="34.5" y1="33" x2="38.5" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="37" y1="33" x2="41" y2="27" stroke="#111111" stroke-width="0.9"/><line x1="4" y1="39" x2="8" y2="33" stroke="#111111" stroke-width="0.9"/><line x1="6.5" y1="39" x2="10.5" y2="33" stroke="#111111" stroke-width="0.9"/><line x1="9" y1="39" x2="13" y2="33" stroke="#111111" stroke-width="0.9"/></pattern><pattern id="rd15-f5-gravel" patternUnits="userSpaceOnUse" width="30" height="30"><ellipse cx="13.86" cy="16.43" rx="2.7" ry="1.67" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="15.19" cy="17.1" rx="1.74" ry="1.71" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="18.12" cy="22.03" rx="1.62" ry="1.5" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="5.18" cy="22.43" rx="2.4" ry="1.24" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="26.57" cy="26.15" rx="2.35" ry="1.82" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="6.78" cy="3.36" rx="2.19" ry="1.26" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="7.56" cy="8.81" rx="1.54" ry="1.66" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="13.57" cy="23.22" rx="2.17" ry="1.84" fill="none" stroke="#111111" stroke-width="0.8"/><ellipse cx="14.99" cy="18.9" rx="2.09" ry="1.48" fill="none" stroke="#111111" stroke-width="0.8"/></pattern><pattern id="rd15-f5-rigid" patternUnits="userSpaceOnUse" width="8" height="8"><line x1="0" y1="0" x2="8" y2="8" stroke="#111111" stroke-width="0.7"/><line x1="8" y1="0" x2="0" y2="8" stroke="#111111" stroke-width="0.7"/></pattern><pattern id="rd15-f5-fwood" patternUnits="userSpaceOnUse" width="30" height="7"><path d="M0 3.5 Q7.5 0 15 3.5 T30 3.5" fill="none" stroke="#111111" stroke-width="0.8"/></pattern></defs>
<rect x="0" y="0" width="720" height="360" fill="#ffffff"/>
<rect x="20" y="40" width="210" height="260" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<rect x="20" y="40" width="210" height="260" fill="none" stroke="#111111" stroke-width="2"/>
<line x1="20" y1="266" x2="230" y2="266" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="28" y="288" font-size="12" text-anchor="start" font-weight="normal" fill="#111111">FLOOR PLAN 1:50</text>
<text x="222" y="290" font-size="16" text-anchor="end" font-weight="bold" fill="#111111">A-101</text>
<rect x="85" y="80" width="125" height="120" fill="none" stroke="#111111" stroke-width="7"/>
<rect x="85" y="80" width="125" height="120" fill="none" stroke="#ffffff" stroke-width="3"/>
<line x1="66" y1="140" x2="120" y2="140" stroke="#111111" stroke-width="3" stroke-dasharray="24 5 6 5 6 5" fill="none" stroke-linecap="butt"/>
<polygon points="48,122 48,158 82,140" fill="#111111"/>
<circle cx="48" cy="140" r="18" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="48" cy="140" r="18" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="30" y1="140" x2="66" y2="140" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="48" y="133" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">1</text>
<text x="48" y="152.5" font-size="9" text-anchor="middle" font-weight="normal" fill="#111111">A-301</text>
<rect x="255" y="40" width="210" height="260" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<rect x="255" y="40" width="210" height="260" fill="none" stroke="#111111" stroke-width="2"/>
<line x1="255" y1="266" x2="465" y2="266" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="263" y="288" font-size="12" text-anchor="start" font-weight="normal" fill="#111111">WALL SECTIONS 1:20</text>
<text x="457" y="290" font-size="16" text-anchor="end" font-weight="bold" fill="#111111">A-301</text>
<rect x="330" y="160" width="24" height="70" fill="url(#rd15-f5-conc)" stroke="#111111" stroke-width="1.6"/>
<rect x="330" y="148" width="20" height="12" fill="#ffffff" stroke="#111111" stroke-width="2.6"/>
<line x1="330" y1="148" x2="350" y2="160" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="350" y1="148" x2="330" y2="160" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="330" y1="148" x2="330" y2="70" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="350" y1="148" x2="350" y2="70" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<path d="M 332 70 C 349.6 70 349.6 76.5 340 76.5 C 330.4 76.5 330.4 83 332 83 C 349.6 83 349.6 89.5 340 89.5 C 330.4 89.5 330.4 96 332 96 C 349.6 96 349.6 102.5 340 102.5 C 330.4 102.5 330.4 109 332 109 C 349.6 109 349.6 115.5 340 115.5 C 330.4 115.5 330.4 122 332 122 C 349.6 122 349.6 128.5 340 128.5 C 330.4 128.5 330.4 135 332 135 C 349.6 135 349.6 141.5 340 141.5 C 330.4 141.5 330.4 148 332 148 " fill="none" stroke="#111111" stroke-width="0.9"/>
<circle cx="342" cy="154" r="20" fill="none" stroke="#111111" stroke-width="1.2" stroke-dasharray="6 3"/>
<line x1="360" y1="140" x2="420" y2="120" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<circle cx="430" cy="108" r="19" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="430" cy="108" r="19" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="411" y1="108" x2="449" y2="108" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="430" y="101" font-size="14" text-anchor="middle" font-weight="bold" fill="#111111">3</text>
<text x="430" y="120.5" font-size="9" text-anchor="middle" font-weight="normal" fill="#111111">A-501</text>
<circle cx="292" cy="221" r="19" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="292" cy="221" r="19" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="273" y1="221" x2="311" y2="221" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="292" y="214" font-size="14" text-anchor="middle" font-weight="bold" fill="#111111">1</text>
<text x="292" y="233.5" font-size="9" text-anchor="middle" font-weight="normal" fill="#111111">A-301</text>
<rect x="490" y="40" width="210" height="260" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<rect x="490" y="40" width="210" height="260" fill="none" stroke="#111111" stroke-width="2"/>
<line x1="490" y1="266" x2="700" y2="266" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="498" y="288" font-size="12" text-anchor="start" font-weight="normal" fill="#111111">DETAILS 1:5</text>
<text x="692" y="290" font-size="16" text-anchor="end" font-weight="bold" fill="#111111">A-501</text>
<rect x="550" y="190" width="96" height="60" fill="url(#rd15-f5-conc)" stroke="#111111" stroke-width="2"/>
<rect x="550" y="152" width="80" height="38" fill="#ffffff" stroke="#111111" stroke-width="2.6"/>
<line x1="550" y1="152" x2="630" y2="190" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="630" y1="152" x2="550" y2="190" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="550" y1="152" x2="550" y2="70" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="630" y1="152" x2="630" y2="70" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<circle cx="522" cy="221" r="19" fill="#ffffff" stroke="#111111" stroke-width="1.1"/>
<circle cx="522" cy="221" r="19" fill="#ffffff" stroke="#111111" stroke-width="1.6"/>
<line x1="503" y1="221" x2="541" y2="221" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="522" y="214" font-size="14" text-anchor="middle" font-weight="bold" fill="#111111">3</text>
<text x="522" y="233.5" font-size="9" text-anchor="middle" font-weight="normal" fill="#111111">A-501</text>
<text x="600" y="66" font-size="12" text-anchor="middle" font-weight="normal" fill="#777777">SILL</text>
<line x1="150" y1="320" x2="330" y2="320" stroke="#1f5fa8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="330,320 318.61,323.77 318.61,316.23" fill="#1f5fa8" stroke="#1f5fa8" stroke-width="1"/>
<line x1="385" y1="320" x2="565" y2="320" stroke="#1f5fa8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="565,320 553.61,323.77 553.61,316.23" fill="#1f5fa8" stroke="#1f5fa8" stroke-width="1"/>
<text x="240" y="345" font-size="13" text-anchor="middle" font-weight="normal" fill="#1f5fa8">section 1 is on A-301</text>
<text x="475" y="345" font-size="13" text-anchor="middle" font-weight="normal" fill="#1f5fa8">detail 3 is on A-501</text>
</svg>
</div>

*Figure 5. Three sheets that point to each other. A-101 (floor plan, 1:50) has a section mark 1 over A-301 across an outside wall. A-301 (wall sections, 1:20) shows section 1, with a detail callout 3 over A-501 at the sill. A-501 (details, 1:5) shows detail 3, the sill, drawn larger.*

### Worked example 2: follow the callouts

**Question:** A carpenter on the floor plan (A-101) needs to know how the sill plate sits on the foundation wall. Where does she look?

1. On A-101, she finds the section mark on the outside wall. The bubble reads **1 over A-301**.
2. She turns to sheet **A-301** and finds the title bubble **1 over A-301**: WALL SECTION, 1:20 (Figure 3).
3. On the wall section, the sill area is circled. The bubble reads **3 over A-501**.
4. She turns to sheet **A-501** and finds the title bubble **3 over A-501**: SILL DETAIL, 1:5.

**Answer:** detail 3 on sheet A-501, reached from A-101 through section 1 on A-301.

### Worked example 3: how much bigger is the detail?

**Question:** The wall section is at 1:20 and the sill detail is at 1:5. The sill plate is 38 mm thick. How thick is it drawn on each sheet, and how many times bigger is the detail?

1. At 1:20: 38 ÷ 20 = **1.9 mm** on paper.
2. At 1:5: 38 ÷ 5 = **7.6 mm** on paper.
3. 20 ÷ 5 = **4**. The detail is drawn 4 times bigger. Check: 1.9 × 4 = 7.6.

**Answer:** 1.9 mm on the wall section, 7.6 mm on the detail. The detail is 4 times bigger.

## Practice

**Task 1** (level 1)
Use Figure 1.
a) What do the arrows on cutting-plane line A-A tell you?
b) What is the name of the view drawn from that cut?
c) What do the thin diagonal lines in that view show?

**Task 2** (level 1)
Use Figure 4. Say in your own words what each bubble means.
a) 1 over A-301 on a section mark
b) 3 over A-501 on a detail callout
c) 2 over A-201 on an elevation marker

**Task 3** (level 1)
Use Figure 2. Which material does each pattern stand for?
a) A box with a diagonal cross
b) Dots and small triangles
c) A looping line
d) A crosshatch

**Task 4** (level 2)
Use Figure 1.
a) What does the half section show that the full section does not?
b) Why is a half section a good choice for this bushing?
c) Why did the drafter use a broken-out section for the shaft instead of a full section?

**Task 5** (level 2)
Use Figures 2 and 3. Name the material at each letter A to F. Say which pattern told you.

**Task 6** (level 2)
Use Figure 1 and Worked example 1. The flange is 100 mm across and the hub is 60 mm across.
a) How far does the flange stick out past the hub on each side?
b) The bolt holes are Ø10, with centres 40 mm from the centre of the bushing. How far from the centre is the inner edge of each hole? The outer edge?

**Task 7** (level 2)
Use Figure 5.
a) A framer on A-101 needs to see how the whole outside wall is built, from footing to wall. Which sheet and which view?
b) A plumber needs to see exactly where the sill plate sits on the concrete. Which sheet and which detail?
c) What scale is each of those views drawn at?

**Task 8** (level 2)
A pipe sleeve through the foundation wall is 100 mm across. How big is it drawn:
a) on the 1:20 wall section?
b) on a 1:5 detail?
c) How many times bigger is the 1:5 drawing?

**Task 9** (level 3)
On a real job, the wall section on A-301 has a callout bubble reading 3 over A-501. You go to sheet A-501. It has details 1, 2 and 4, but no detail 3. What could have happened? What do you do before you build that part?

**Task 10** (level 3)
A small drawing set has no material legend. A wall in section is filled with 45° lines. A co-worker says, "That's brick." Use Key idea 4 and Figure 2 to explain why you cannot be sure. List two places in the drawing set where you could look to find out, and say what you do if you still cannot tell.

**Task 11** (level 3)
You are the lead hand. Write the steps you would give a new apprentice to find the detail for the sill in Figure 5, starting from the floor plan. Use the words section mark, bubble, sheet number and title.

_______________________________________________

_______________________________________________

## Check yourself

1. What shows which way you are looking at a section?
2. What is left blank in a section view?
3. In a reference bubble, what does the top number mean? The bottom number?
4. Why should you check the legend before naming a hatch pattern?
5. Why are details drawn at a bigger scale than plans?

The next lesson, Reading lesson 16, uses real construction drawing sets.
