---
title: Pictorial drawings: isometric, oblique and perspective
summary: Tell isometric, oblique and perspective drawings apart, know which lines you can measure on each, read a single-line piping isometric, and sketch an object on isometric grid paper.
level: 1-3
time: 90 min
components: Identify the information; Make connections between different parts of the document(s); Understand and apply the information; Evaluate the document(s)
---

# Pictorial drawings: isometric, oblique and perspective

## Why this matters on the job

A **pictorial drawing** shows an object in 3D, in one picture. It is easier to understand at a glance than a set of flat views. Pipefitters work from piping **isometrics** every day. Welders and carpenters sketch parts in **oblique** to show a co-worker what they mean. Builders show customers a **perspective** rendering of a new house or deck. Each kind has its own rules. You need to know which lines you can measure and which you cannot. In [Reading lesson 11](../11-orthographic-projection/learner.html) you read flat views. This lesson turns flat views into pictures and back.

## Key ideas

**1. Isometric drawing.** Height is drawn **vertical**. Width and depth go up and away at **30°** from horizontal, one to the left and one to the right. The three axes are **120°** apart. You can see this at the top front corner of a box: one edge goes straight down and the other two go up at 30°, and each pair is 120° apart. In an isometric drawing, lengths along the three axes are drawn at full size (or at the drawing scale).

**2. Isometric lines and non-isometric lines.** A line parallel to one of the three axes is an **isometric line**. You can measure it. A sloped line that is not parallel to an axis is a **non-isometric line**. It is drawn too long or too short, so you cannot measure it. To draw it, find its two end points along isometric lines, then join them.

**3. Circles become ellipses in isometric.** A round hole or pipe end on any face of an isometric drawing is drawn as an ellipse.

**4. Oblique drawing.** The front face is drawn true shape, just like a front view. Depth goes back at an angle, most often **45°**.

- **Cavalier oblique:** depth drawn at **full** length.
- **Cabinet oblique:** depth drawn at **half** length. It looks less stretched. Furniture and cabinet makers use it.

Because the front face is true shape, a circle on the front face stays a true circle. That makes oblique quick for shop sketches. Put the face with the holes or curves at the front.

**5. Perspective drawing.** Perspective looks the most real. Lines that go away from you get closer together and meet at a **vanishing point (VP)**. The vanishing points sit on the **horizon line (HL)**, which is at the viewer's eye level.

- **One-point perspective:** you look straight at one face. Receding lines meet at **one** VP.
- **Two-point perspective:** you look at a corner. Horizontal edges go to **two** VPs on the horizon line. Vertical edges stay vertical.

Things farther away are drawn smaller, so you **cannot measure** a perspective drawing.

**6. Which one is used where.**

- **Isometric:** piping drawings, assembly sketches and grid-paper sketches. Piping isometrics are drawn with a single line for the pipe and are **not to scale**. They carry written dimensions.
- **Oblique:** quick shop sketches of a part with holes or curves on one face.
- **Perspective:** renderings that show a customer what the finished job will look like.

<div class="figure-art">
<svg viewBox="0 0 720 385" width="100%" role="img" aria-labelledby="rd12-f1-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd12-f1-title">One pipe support block with a round hole drawn three ways: isometric, cavalier oblique and cabinet oblique. In the isometric drawing the hole is an ellipse. In both oblique drawings the front face is true shape, so the hole is a true circle. The cabinet drawing shows the depth at half length.</title>
<defs><clipPath id="rd12-f1-iso"><polygon points="103.83,228.88 103.79,227.33 103.66,225.74 103.44,224.12 103.14,222.46 102.76,220.78 102.3,219.09 101.75,217.39 101.13,215.69 100.44,214 99.67,212.32 98.83,210.66 97.93,209.03 96.97,207.43 95.95,205.88 94.88,204.38 93.76,202.93 92.6,201.54 91.4,200.22 90.17,198.97 88.9,197.8 87.62,196.71 86.32,195.72 85.01,194.81 83.69,194 82.38,193.29 81.07,192.68 79.77,192.18 78.48,191.78 77.22,191.5 75.99,191.32 74.79,191.26 73.63,191.3 72.51,191.46 71.44,191.73 70.42,192.1 69.46,192.59 68.56,193.18 67.72,193.87 66.95,194.67 66.26,195.56 65.63,196.54 65.09,197.61 64.63,198.77 64.24,200 63.95,201.31 63.73,202.69 63.6,204.13 63.56,205.62 63.6,207.17 63.73,208.76 63.95,210.38 64.24,212.04 64.63,213.72 65.09,215.41 65.63,217.11 66.26,218.81 66.95,220.5 67.72,222.18 68.56,223.84 69.46,225.47 70.42,227.07 71.44,228.62 72.51,230.12 73.63,231.57 74.79,232.96 75.99,234.28 77.22,235.53 78.48,236.7 79.77,237.79 81.07,238.78 82.38,239.69 83.69,240.5 85.01,241.21 86.32,241.82 87.62,242.32 88.9,242.72 90.17,243 91.4,243.18 92.6,243.24 93.76,243.2 94.88,243.04 95.95,242.77 96.97,242.4 97.93,241.91 98.83,241.32 99.67,240.63 100.44,239.83 101.13,238.94 101.75,237.96 102.3,236.89 102.76,235.73 103.14,234.5 103.44,233.19 103.66,231.81 103.79,230.37 103.83,228.88"/></clipPath><clipPath id="rd12-f1-ob0"><polygon points="375.25,211.25 375.2,209.73 375.05,208.22 374.8,206.71 374.46,205.23 374.02,203.78 373.48,202.35 372.85,200.97 372.14,199.62 371.33,198.33 370.45,197.1 369.48,195.92 368.44,194.81 367.33,193.77 366.15,192.8 364.92,191.92 363.62,191.11 362.28,190.4 360.9,189.77 359.47,189.23 358.02,188.79 356.54,188.45 355.03,188.2 353.52,188.05 352,188 350.48,188.05 348.97,188.2 347.46,188.45 345.98,188.79 344.53,189.23 343.1,189.77 341.72,190.4 340.38,191.11 339.08,191.92 337.85,192.8 336.67,193.77 335.56,194.81 334.52,195.92 333.55,197.1 332.67,198.33 331.86,199.62 331.15,200.97 330.52,202.35 329.98,203.78 329.54,205.23 329.2,206.71 328.95,208.22 328.8,209.73 328.75,211.25 328.8,212.77 328.95,214.28 329.2,215.79 329.54,217.27 329.98,218.72 330.52,220.15 331.15,221.53 331.86,222.88 332.67,224.17 333.55,225.4 334.52,226.58 335.56,227.69 336.67,228.73 337.85,229.7 339.08,230.58 340.38,231.39 341.72,232.1 343.1,232.73 344.53,233.27 345.98,233.71 347.46,234.05 348.97,234.3 350.48,234.45 352,234.5 353.52,234.45 355.03,234.3 356.54,234.05 358.02,233.71 359.47,233.27 360.9,232.73 362.28,232.1 363.62,231.39 364.92,230.58 366.15,229.7 367.33,228.73 368.44,227.69 369.48,226.58 370.45,225.4 371.33,224.17 372.14,222.88 372.85,221.53 373.48,220.15 374.02,218.72 374.46,217.27 374.8,215.79 375.05,214.28 375.2,212.77 375.25,211.25"/></clipPath><clipPath id="rd12-f1-ob1"><polygon points="600.25,211.25 600.2,209.73 600.05,208.22 599.8,206.71 599.46,205.23 599.02,203.78 598.48,202.35 597.85,200.97 597.14,199.62 596.33,198.33 595.45,197.1 594.48,195.92 593.44,194.81 592.33,193.77 591.15,192.8 589.92,191.92 588.62,191.11 587.28,190.4 585.9,189.77 584.47,189.23 583.02,188.79 581.54,188.45 580.03,188.2 578.52,188.05 577,188 575.48,188.05 573.97,188.2 572.46,188.45 570.98,188.79 569.53,189.23 568.1,189.77 566.72,190.4 565.38,191.11 564.08,191.92 562.85,192.8 561.67,193.77 560.56,194.81 559.52,195.92 558.55,197.1 557.67,198.33 556.86,199.62 556.15,200.97 555.52,202.35 554.98,203.78 554.54,205.23 554.2,206.71 553.95,208.22 553.8,209.73 553.75,211.25 553.8,212.77 553.95,214.28 554.2,215.79 554.54,217.27 554.98,218.72 555.52,220.15 556.15,221.53 556.86,222.88 557.67,224.17 558.55,225.4 559.52,226.58 560.56,227.69 561.67,228.73 562.85,229.7 564.08,230.58 565.38,231.39 566.72,232.1 568.1,232.73 569.53,233.27 570.98,233.71 572.46,234.05 573.97,234.3 575.48,234.45 577,234.5 578.52,234.45 580.03,234.3 581.54,234.05 583.02,233.71 584.47,233.27 585.9,232.73 587.28,232.1 588.62,231.39 589.92,230.58 591.15,229.7 592.33,228.73 593.44,227.69 594.48,226.58 595.45,225.4 596.33,224.17 597.14,222.88 597.85,221.53 598.48,220.15 599.02,218.72 599.46,217.27 599.8,215.79 600.05,214.28 600.2,212.77 600.25,211.25"/></clipPath></defs>
<rect x="0" y="0" width="720" height="385" fill="#ffffff"/>
<polygon points="30,147.5 137.39,209.5 217.93,163 110.54,101" fill="#f4f4f4" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="137.39,287 217.93,240.5 217.93,163 137.39,209.5" fill="#bdbdbd" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="30,225 137.39,287 137.39,209.5 30,147.5" fill="#d9d9d9" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="103.83,228.88 103.79,227.33 103.66,225.74 103.44,224.12 103.14,222.46 102.76,220.78 102.3,219.09 101.75,217.39 101.13,215.69 100.44,214 99.67,212.32 98.83,210.66 97.93,209.03 96.97,207.43 95.95,205.88 94.88,204.38 93.76,202.93 92.6,201.54 91.4,200.22 90.17,198.97 88.9,197.8 87.62,196.71 86.32,195.72 85.01,194.81 83.69,194 82.38,193.29 81.07,192.68 79.77,192.18 78.48,191.78 77.22,191.5 75.99,191.32 74.79,191.26 73.63,191.3 72.51,191.46 71.44,191.73 70.42,192.1 69.46,192.59 68.56,193.18 67.72,193.87 66.95,194.67 66.26,195.56 65.63,196.54 65.09,197.61 64.63,198.77 64.24,200 63.95,201.31 63.73,202.69 63.6,204.13 63.56,205.62 63.6,207.17 63.73,208.76 63.95,210.38 64.24,212.04 64.63,213.72 65.09,215.41 65.63,217.11 66.26,218.81 66.95,220.5 67.72,222.18 68.56,223.84 69.46,225.47 70.42,227.07 71.44,228.62 72.51,230.12 73.63,231.57 74.79,232.96 75.99,234.28 77.22,235.53 78.48,236.7 79.77,237.79 81.07,238.78 82.38,239.69 83.69,240.5 85.01,241.21 86.32,241.82 87.62,242.32 88.9,242.72 90.17,243 91.4,243.18 92.6,243.24 93.76,243.2 94.88,243.04 95.95,242.77 96.97,242.4 97.93,241.91 98.83,241.32 99.67,240.63 100.44,239.83 101.13,238.94 101.75,237.96 102.3,236.89 102.76,235.73 103.14,234.5 103.44,233.19 103.66,231.81 103.79,230.37 103.83,228.88" fill="#5a5a5a" stroke="#5a5a5a" stroke-width="0.5" stroke-linejoin="round"/>
<g clip-path="url(#rd12-f1-iso)"><polygon points="184.37,182.38 184.33,180.83 184.2,179.24 183.98,177.62 183.68,175.96 183.3,174.28 182.84,172.59 182.29,170.89 181.67,169.19 180.98,167.5 180.21,165.82 179.37,164.16 178.47,162.53 177.51,160.93 176.49,159.38 175.42,157.88 174.3,156.43 173.14,155.04 171.94,153.72 170.71,152.47 169.45,151.3 168.16,150.21 166.86,149.22 165.55,148.31 164.23,147.5 162.92,146.79 161.61,146.18 160.31,145.68 159.02,145.28 157.76,145 156.53,144.82 155.33,144.76 154.17,144.8 153.05,144.96 151.98,145.23 150.96,145.6 150,146.09 149.1,146.68 148.26,147.37 147.49,148.17 146.8,149.06 146.18,150.04 145.63,151.11 145.17,152.27 144.78,153.5 144.49,154.81 144.27,156.19 144.14,157.63 144.1,159.12 144.14,160.67 144.27,162.26 144.49,163.88 144.78,165.54 145.17,167.22 145.63,168.91 146.18,170.61 146.8,172.31 147.49,174 148.26,175.68 149.1,177.34 150,178.97 150.96,180.57 151.98,182.12 153.05,183.62 154.17,185.07 155.33,186.46 156.53,187.78 157.76,189.03 159.02,190.2 160.31,191.29 161.61,192.28 162.92,193.19 164.23,194 165.55,194.71 166.86,195.32 168.16,195.82 169.45,196.22 170.71,196.5 171.94,196.68 173.14,196.74 174.3,196.7 175.42,196.54 176.49,196.27 177.51,195.9 178.47,195.41 179.37,194.82 180.21,194.13 180.98,193.33 181.67,192.44 182.29,191.46 182.84,190.39 183.3,189.23 183.68,188 183.98,186.69 184.2,185.31 184.33,183.87 184.37,182.38" fill="#e9e9e9" stroke="#111111" stroke-width="1.2"/></g>
<polygon points="103.83,228.88 103.79,227.33 103.66,225.74 103.44,224.12 103.14,222.46 102.76,220.78 102.3,219.09 101.75,217.39 101.13,215.69 100.44,214 99.67,212.32 98.83,210.66 97.93,209.03 96.97,207.43 95.95,205.88 94.88,204.38 93.76,202.93 92.6,201.54 91.4,200.22 90.17,198.97 88.9,197.8 87.62,196.71 86.32,195.72 85.01,194.81 83.69,194 82.38,193.29 81.07,192.68 79.77,192.18 78.48,191.78 77.22,191.5 75.99,191.32 74.79,191.26 73.63,191.3 72.51,191.46 71.44,191.73 70.42,192.1 69.46,192.59 68.56,193.18 67.72,193.87 66.95,194.67 66.26,195.56 65.63,196.54 65.09,197.61 64.63,198.77 64.24,200 63.95,201.31 63.73,202.69 63.6,204.13 63.56,205.62 63.6,207.17 63.73,208.76 63.95,210.38 64.24,212.04 64.63,213.72 65.09,215.41 65.63,217.11 66.26,218.81 66.95,220.5 67.72,222.18 68.56,223.84 69.46,225.47 70.42,227.07 71.44,228.62 72.51,230.12 73.63,231.57 74.79,232.96 75.99,234.28 77.22,235.53 78.48,236.7 79.77,237.79 81.07,238.78 82.38,239.69 83.69,240.5 85.01,241.21 86.32,241.82 87.62,242.32 88.9,242.72 90.17,243 91.4,243.18 92.6,243.24 93.76,243.2 94.88,243.04 95.95,242.77 96.97,242.4 97.93,241.91 98.83,241.32 99.67,240.63 100.44,239.83 101.13,238.94 101.75,237.96 102.3,236.89 102.76,235.73 103.14,234.5 103.44,233.19 103.66,231.81 103.79,230.37 103.83,228.88" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<text x="125" y="40" font-size="17" text-anchor="middle" font-weight="bold" fill="#111111">ISOMETRIC</text>
<text x="125" y="312" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">Width and depth at 30°.</text>
<text x="125" y="330" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">All three at full size.</text>
<polygon points="290,172.5 414,172.5 479.76,106.74 355.76,106.74" fill="#f4f4f4" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="414,250 479.76,184.24 479.76,106.74 414,172.5" fill="#bdbdbd" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="290,250 414,250 414,172.5 290,172.5" fill="#d9d9d9" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="375.25,211.25 375.2,209.73 375.05,208.22 374.8,206.71 374.46,205.23 374.02,203.78 373.48,202.35 372.85,200.97 372.14,199.62 371.33,198.33 370.45,197.1 369.48,195.92 368.44,194.81 367.33,193.77 366.15,192.8 364.92,191.92 363.62,191.11 362.28,190.4 360.9,189.77 359.47,189.23 358.02,188.79 356.54,188.45 355.03,188.2 353.52,188.05 352,188 350.48,188.05 348.97,188.2 347.46,188.45 345.98,188.79 344.53,189.23 343.1,189.77 341.72,190.4 340.38,191.11 339.08,191.92 337.85,192.8 336.67,193.77 335.56,194.81 334.52,195.92 333.55,197.1 332.67,198.33 331.86,199.62 331.15,200.97 330.52,202.35 329.98,203.78 329.54,205.23 329.2,206.71 328.95,208.22 328.8,209.73 328.75,211.25 328.8,212.77 328.95,214.28 329.2,215.79 329.54,217.27 329.98,218.72 330.52,220.15 331.15,221.53 331.86,222.88 332.67,224.17 333.55,225.4 334.52,226.58 335.56,227.69 336.67,228.73 337.85,229.7 339.08,230.58 340.38,231.39 341.72,232.1 343.1,232.73 344.53,233.27 345.98,233.71 347.46,234.05 348.97,234.3 350.48,234.45 352,234.5 353.52,234.45 355.03,234.3 356.54,234.05 358.02,233.71 359.47,233.27 360.9,232.73 362.28,232.1 363.62,231.39 364.92,230.58 366.15,229.7 367.33,228.73 368.44,227.69 369.48,226.58 370.45,225.4 371.33,224.17 372.14,222.88 372.85,221.53 373.48,220.15 374.02,218.72 374.46,217.27 374.8,215.79 375.05,214.28 375.2,212.77 375.25,211.25" fill="#5a5a5a" stroke="#5a5a5a" stroke-width="0.5" stroke-linejoin="round"/>
<g clip-path="url(#rd12-f1-ob0)"><polygon points="441.01,145.49 440.96,143.97 440.81,142.45 440.56,140.95 440.22,139.47 439.78,138.02 439.24,136.59 438.61,135.21 437.9,133.86 437.09,132.57 436.21,131.34 435.24,130.16 434.2,129.05 433.09,128.01 431.91,127.04 430.68,126.16 429.39,125.35 428.04,124.64 426.66,124.01 425.23,123.47 423.78,123.03 422.3,122.69 420.8,122.44 419.28,122.29 417.76,122.24 416.24,122.29 414.73,122.44 413.23,122.69 411.74,123.03 410.29,123.47 408.86,124.01 407.48,124.64 406.14,125.35 404.84,126.16 403.61,127.04 402.43,128.01 401.32,129.05 400.28,130.16 399.32,131.34 398.43,132.57 397.63,133.86 396.91,135.21 396.28,136.59 395.74,138.02 395.3,139.47 394.96,140.95 394.71,142.45 394.56,143.97 394.51,145.49 394.56,147.01 394.71,148.52 394.96,150.02 395.3,151.51 395.74,152.96 396.28,154.39 396.91,155.77 397.63,157.11 398.43,158.41 399.32,159.64 400.28,160.82 401.32,161.93 402.43,162.97 403.61,163.93 404.84,164.82 406.14,165.62 407.48,166.34 408.86,166.97 410.29,167.51 411.74,167.95 413.23,168.29 414.73,168.54 416.24,168.69 417.76,168.74 419.28,168.69 420.8,168.54 422.3,168.29 423.78,167.95 425.23,167.51 426.66,166.97 428.04,166.34 429.39,165.62 430.68,164.82 431.91,163.93 433.09,162.97 434.2,161.93 435.24,160.82 436.21,159.64 437.09,158.41 437.9,157.11 438.61,155.77 439.24,154.39 439.78,152.96 440.22,151.51 440.56,150.02 440.81,148.52 440.96,147.01 441.01,145.49" fill="#e9e9e9" stroke="#111111" stroke-width="1.2"/></g>
<polygon points="375.25,211.25 375.2,209.73 375.05,208.22 374.8,206.71 374.46,205.23 374.02,203.78 373.48,202.35 372.85,200.97 372.14,199.62 371.33,198.33 370.45,197.1 369.48,195.92 368.44,194.81 367.33,193.77 366.15,192.8 364.92,191.92 363.62,191.11 362.28,190.4 360.9,189.77 359.47,189.23 358.02,188.79 356.54,188.45 355.03,188.2 353.52,188.05 352,188 350.48,188.05 348.97,188.2 347.46,188.45 345.98,188.79 344.53,189.23 343.1,189.77 341.72,190.4 340.38,191.11 339.08,191.92 337.85,192.8 336.67,193.77 335.56,194.81 334.52,195.92 333.55,197.1 332.67,198.33 331.86,199.62 331.15,200.97 330.52,202.35 329.98,203.78 329.54,205.23 329.2,206.71 328.95,208.22 328.8,209.73 328.75,211.25 328.8,212.77 328.95,214.28 329.2,215.79 329.54,217.27 329.98,218.72 330.52,220.15 331.15,221.53 331.86,222.88 332.67,224.17 333.55,225.4 334.52,226.58 335.56,227.69 336.67,228.73 337.85,229.7 339.08,230.58 340.38,231.39 341.72,232.1 343.1,232.73 344.53,233.27 345.98,233.71 347.46,234.05 348.97,234.3 350.48,234.45 352,234.5 353.52,234.45 355.03,234.3 356.54,234.05 358.02,233.71 359.47,233.27 360.9,232.73 362.28,232.1 363.62,231.39 364.92,230.58 366.15,229.7 367.33,228.73 368.44,227.69 369.48,226.58 370.45,225.4 371.33,224.17 372.14,222.88 372.85,221.53 373.48,220.15 374.02,218.72 374.46,217.27 374.8,215.79 375.05,214.28 375.2,212.77 375.25,211.25" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<text x="375" y="40" font-size="17" text-anchor="middle" font-weight="bold" fill="#111111">CAVALIER OBLIQUE</text>
<text x="375" y="312" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">Depth at 45°,</text>
<text x="375" y="330" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">full length.</text>
<polygon points="515,172.5 639,172.5 671.88,139.62 547.88,139.62" fill="#f4f4f4" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="639,250 671.88,217.12 671.88,139.62 639,172.5" fill="#bdbdbd" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="515,250 639,250 639,172.5 515,172.5" fill="#d9d9d9" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="600.25,211.25 600.2,209.73 600.05,208.22 599.8,206.71 599.46,205.23 599.02,203.78 598.48,202.35 597.85,200.97 597.14,199.62 596.33,198.33 595.45,197.1 594.48,195.92 593.44,194.81 592.33,193.77 591.15,192.8 589.92,191.92 588.62,191.11 587.28,190.4 585.9,189.77 584.47,189.23 583.02,188.79 581.54,188.45 580.03,188.2 578.52,188.05 577,188 575.48,188.05 573.97,188.2 572.46,188.45 570.98,188.79 569.53,189.23 568.1,189.77 566.72,190.4 565.38,191.11 564.08,191.92 562.85,192.8 561.67,193.77 560.56,194.81 559.52,195.92 558.55,197.1 557.67,198.33 556.86,199.62 556.15,200.97 555.52,202.35 554.98,203.78 554.54,205.23 554.2,206.71 553.95,208.22 553.8,209.73 553.75,211.25 553.8,212.77 553.95,214.28 554.2,215.79 554.54,217.27 554.98,218.72 555.52,220.15 556.15,221.53 556.86,222.88 557.67,224.17 558.55,225.4 559.52,226.58 560.56,227.69 561.67,228.73 562.85,229.7 564.08,230.58 565.38,231.39 566.72,232.1 568.1,232.73 569.53,233.27 570.98,233.71 572.46,234.05 573.97,234.3 575.48,234.45 577,234.5 578.52,234.45 580.03,234.3 581.54,234.05 583.02,233.71 584.47,233.27 585.9,232.73 587.28,232.1 588.62,231.39 589.92,230.58 591.15,229.7 592.33,228.73 593.44,227.69 594.48,226.58 595.45,225.4 596.33,224.17 597.14,222.88 597.85,221.53 598.48,220.15 599.02,218.72 599.46,217.27 599.8,215.79 600.05,214.28 600.2,212.77 600.25,211.25" fill="#5a5a5a" stroke="#5a5a5a" stroke-width="0.5" stroke-linejoin="round"/>
<g clip-path="url(#rd12-f1-ob1)"><polygon points="633.13,178.37 633.08,176.85 632.93,175.33 632.68,173.83 632.34,172.35 631.9,170.9 631.36,169.47 630.73,168.09 630.02,166.74 629.21,165.45 628.33,164.22 627.36,163.04 626.32,161.93 625.21,160.89 624.03,159.92 622.8,159.04 621.51,158.23 620.16,157.52 618.78,156.89 617.35,156.35 615.9,155.91 614.42,155.57 612.92,155.32 611.4,155.17 609.88,155.12 608.36,155.17 606.85,155.32 605.34,155.57 603.86,155.91 602.41,156.35 600.98,156.89 599.6,157.52 598.26,158.23 596.96,159.04 595.73,159.92 594.55,160.89 593.44,161.93 592.4,163.04 591.44,164.22 590.55,165.45 589.75,166.74 589.03,168.09 588.4,169.47 587.86,170.9 587.42,172.35 587.08,173.83 586.83,175.33 586.68,176.85 586.63,178.37 586.68,179.89 586.83,181.4 587.08,182.91 587.42,184.39 587.86,185.84 588.4,187.27 589.03,188.65 589.75,189.99 590.55,191.29 591.44,192.52 592.4,193.7 593.44,194.81 594.55,195.85 595.73,196.81 596.96,197.7 598.26,198.5 599.6,199.22 600.98,199.85 602.41,200.39 603.86,200.83 605.34,201.17 606.85,201.42 608.36,201.57 609.88,201.62 611.4,201.57 612.92,201.42 614.42,201.17 615.9,200.83 617.35,200.39 618.78,199.85 620.16,199.22 621.51,198.5 622.8,197.7 624.03,196.81 625.21,195.85 626.32,194.81 627.36,193.7 628.33,192.52 629.21,191.29 630.02,189.99 630.73,188.65 631.36,187.27 631.9,185.84 632.34,184.39 632.68,182.91 632.93,181.4 633.08,179.89 633.13,178.37" fill="#e9e9e9" stroke="#111111" stroke-width="1.2"/></g>
<polygon points="600.25,211.25 600.2,209.73 600.05,208.22 599.8,206.71 599.46,205.23 599.02,203.78 598.48,202.35 597.85,200.97 597.14,199.62 596.33,198.33 595.45,197.1 594.48,195.92 593.44,194.81 592.33,193.77 591.15,192.8 589.92,191.92 588.62,191.11 587.28,190.4 585.9,189.77 584.47,189.23 583.02,188.79 581.54,188.45 580.03,188.2 578.52,188.05 577,188 575.48,188.05 573.97,188.2 572.46,188.45 570.98,188.79 569.53,189.23 568.1,189.77 566.72,190.4 565.38,191.11 564.08,191.92 562.85,192.8 561.67,193.77 560.56,194.81 559.52,195.92 558.55,197.1 557.67,198.33 556.86,199.62 556.15,200.97 555.52,202.35 554.98,203.78 554.54,205.23 554.2,206.71 553.95,208.22 553.8,209.73 553.75,211.25 553.8,212.77 553.95,214.28 554.2,215.79 554.54,217.27 554.98,218.72 555.52,220.15 556.15,221.53 556.86,222.88 557.67,224.17 558.55,225.4 559.52,226.58 560.56,227.69 561.67,228.73 562.85,229.7 564.08,230.58 565.38,231.39 566.72,232.1 568.1,232.73 569.53,233.27 570.98,233.71 572.46,234.05 573.97,234.3 575.48,234.45 577,234.5 578.52,234.45 580.03,234.3 581.54,234.05 583.02,233.71 584.47,233.27 585.9,232.73 587.28,232.1 588.62,231.39 589.92,230.58 591.15,229.7 592.33,228.73 593.44,227.69 594.48,226.58 595.45,225.4 596.33,224.17 597.14,222.88 597.85,221.53 598.48,220.15 599.02,218.72 599.46,217.27 599.8,215.79 600.05,214.28 600.2,212.77 600.25,211.25" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<text x="600" y="40" font-size="17" text-anchor="middle" font-weight="bold" fill="#111111">CABINET OBLIQUE</text>
<text x="600" y="312" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">Depth at 45°,</text>
<text x="600" y="330" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">half length.</text>
<text x="360" y="372" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">Block: 80 wide, 60 deep, 50 high, Ø30 hole front to back (mm)</text>
</svg>
</div>

*Figure 1. One pipe support block, 80 mm wide, 60 mm deep and 50 mm high, with a Ø30 hole from front to back, drawn three ways. In the isometric drawing the hole is an ellipse. In the two oblique drawings the front face is true shape, so the hole is a true circle. The cavalier drawing shows the depth at full length. The cabinet drawing shows it at half length.*

<div class="figure-art">
<svg viewBox="0 0 760 420" width="100%" role="img" aria-labelledby="rd12-f2-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd12-f2-title">Left: isometric axes. Height is vertical. Width and depth go up at 30 degrees from horizontal, so the three axes are 120 degrees apart. Right: a block with a sloped top. Edges along the axes are isometric lines and can be measured. The sloped edge is a non-isometric line and is found by plotting its two end points.</title>
<rect x="0" y="0" width="760" height="420" fill="#ffffff"/>
<line x1="170" y1="250" x2="170" y2="120" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="170,120 173.77,131.39 166.23,131.39" fill="#111111" stroke="#111111" stroke-width="1"/>
<line x1="170" y1="250" x2="57.42" y2="185" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="57.42,185 69.17,187.43 65.39,193.96" fill="#111111" stroke="#111111" stroke-width="1"/>
<line x1="170" y1="250" x2="282.58" y2="185" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="282.58,185 274.61,193.96 270.83,187.43" fill="#111111" stroke="#111111" stroke-width="1"/>
<line x1="20" y1="250" x2="320" y2="250" stroke="#777777" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="170" y="106" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">HEIGHT</text>
<text x="51.42" y="173" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">WIDTH</text>
<text x="288.58" y="173" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">DEPTH</text>
<polyline points="100,250 100.02,248.17 100.1,246.34 100.22,244.51 100.38,242.68 100.6,240.86 100.86,239.05 101.17,237.24 101.53,235.45 101.93,233.66 102.39,231.88 102.88,230.12 103.43,228.37 104.02,226.63 104.65,224.91 105.33,223.21 106.05,221.53 106.82,219.86 107.63,218.22 108.48,216.6 109.38,215" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<text x="72" y="238" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">30°</text>
<polyline points="240,250 239.98,248.17 239.9,246.34 239.78,244.51 239.62,242.68 239.4,240.86 239.14,239.05 238.83,237.24 238.47,235.45 238.07,233.66 237.61,231.88 237.12,230.12 236.57,228.37 235.98,226.63 235.35,224.91 234.67,223.21 233.95,221.53 233.18,219.86 232.37,218.22 231.52,216.6 230.62,215" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<text x="268" y="238" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">30°</text>
<polyline points="142.29,234 144.11,231.19 146.22,228.59 148.59,226.22 151.19,224.11 154,222.29 156.98,220.77 160.11,219.57 163.35,218.7 166.66,218.18 170,218 173.34,218.18 176.65,218.7 179.89,219.57 183.02,220.77 186,222.29 188.81,224.11 191.41,226.22 193.78,228.59 195.89,231.19 197.71,234" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<text x="170" y="210" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">120°</text>
<text x="170" y="284" font-size="14" text-anchor="middle" font-weight="normal" fill="#777777">horizontal</text>
<polygon points="405,274 547.03,356 653.55,233 511.52,151" fill="#f4f4f4" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="547.03,397 653.55,335.5 653.55,233 547.03,356" fill="#bdbdbd" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="405,315 547.03,397 547.03,356 405,274" fill="#d9d9d9" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<line x1="547.03" y1="356" x2="547.03" y2="294.5" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<line x1="547.03" y1="294.5" x2="653.55" y2="233" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<line x1="547.03" y1="356" x2="653.55" y2="233" stroke="#b3261e" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polyline points="603.29,296.5 640.29,334.5 660.29,334.5" fill="none" stroke="#b3261e" stroke-width="1.1" stroke-linejoin="miter"/>
<polygon points="603.29,296.5 612.16,301.11 607.66,305.5" fill="#b3261e" stroke="#b3261e" stroke-width="1"/>
<text x="664.29" y="330.5" font-size="14" text-anchor="start" font-weight="normal" fill="#b3261e">non-isometric</text>
<text x="664.29" y="348.5" font-size="14" text-anchor="start" font-weight="normal" fill="#b3261e">line</text>
<polyline points="474.01,359 446.01,396 416.01,396" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<polygon points="474.01,359 470.79,368.47 465.78,364.67" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="411.01" y="402" font-size="14" text-anchor="end" font-weight="normal" fill="#111111">isometric line</text>
<text x="560" y="40" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">Front 20 high, back 50 high</text>
<text x="560" y="58" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">(sizes in mm)</text>
</svg>
</div>

*Figure 2. Left: the isometric axes. Height is vertical. Width and depth are at 30° from horizontal. The axes are 120° apart. Right: a block 80 mm wide and 60 mm deep, 20 mm high at the front and 50 mm high at the back. The bottom front edge is an isometric line. The sloped edge on the right face (in red) is a non-isometric line.*

<div class="figure-art">
<svg viewBox="0 0 400 365" width="100%" role="img" aria-labelledby="rd12-f3-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd12-f3-title">A cube drawn in isometric with a circle on the top, the front and the right side. Each circle shows as an ellipse.</title>
<rect x="0" y="0" width="400" height="365" fill="#ffffff"/>
<polygon points="70,120 199.9,195 329.81,120 199.9,45" fill="#f4f4f4" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="199.9,345 329.81,270 329.81,120 199.9,195" fill="#bdbdbd" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="70,270 199.9,345 199.9,195 70,120" fill="#d9d9d9" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="251.87,150 255.15,147.97 258.2,145.83 261,143.57 263.54,141.21 265.81,138.76 267.79,136.24 269.49,133.64 270.88,130.98 271.98,128.28 272.76,125.54 273.23,122.77 273.39,120 273.23,117.23 272.76,114.46 271.98,111.72 270.88,109.02 269.49,106.36 267.79,103.76 265.81,101.24 263.54,98.79 261,96.43 258.2,94.17 255.15,92.03 251.87,90 248.36,88.1 244.64,86.34 240.73,84.72 236.65,83.26 232.41,81.95 228.03,80.8 223.52,79.83 218.92,79.02 214.24,78.39 209.5,77.94 204.71,77.66 199.9,77.57 195.1,77.66 190.31,77.94 185.57,78.39 180.88,79.02 176.28,79.83 171.78,80.8 167.4,81.95 163.16,83.26 159.08,84.72 155.17,86.34 151.45,88.1 147.94,90 144.66,92.03 141.6,94.17 138.8,96.43 136.26,98.79 134,101.24 132.01,103.76 130.32,106.36 128.92,109.02 127.83,111.72 127.05,114.46 126.58,117.23 126.42,120 126.58,122.77 127.05,125.54 127.83,128.28 128.92,130.98 130.32,133.64 132.01,136.24 134,138.76 136.26,141.21 138.8,143.57 141.6,145.83 144.66,147.97 147.94,150 151.45,151.9 155.17,153.66 159.08,155.28 163.16,156.74 167.4,158.05 171.78,159.2 176.28,160.17 180.88,160.98 185.57,161.61 190.31,162.06 195.1,162.34 199.9,162.43 204.71,162.34 209.5,162.06 214.24,161.61 218.92,160.98 223.52,160.17 228.03,159.2 232.41,158.05 236.65,156.74 240.73,155.28 244.64,153.66 248.36,151.9 251.87,150" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="186.91,262.5 186.8,258.51 186.47,254.41 185.92,250.22 185.14,245.95 184.16,241.62 182.96,237.26 181.55,232.87 179.95,228.48 178.16,224.11 176.18,219.77 174.02,215.49 171.69,211.29 169.21,207.17 166.58,203.16 163.82,199.28 160.93,195.54 157.93,191.96 154.84,188.55 151.65,185.33 148.4,182.31 145.09,179.51 141.73,176.93 138.35,174.59 134.95,172.5 131.55,170.67 128.17,169.1 124.81,167.8 121.5,166.78 118.25,166.04 115.07,165.59 111.97,165.42 108.97,165.54 106.08,165.94 103.32,166.64 100.69,167.61 98.21,168.86 95.89,170.38 93.73,172.17 91.75,174.22 89.95,176.52 88.35,179.06 86.95,181.82 85.75,184.81 84.76,187.99 83.99,191.37 83.43,194.93 83.1,198.64 82.99,202.5 83.1,206.49 83.43,210.59 83.99,214.78 84.76,219.05 85.75,223.38 86.95,227.74 88.35,232.13 89.95,236.52 91.75,240.89 93.73,245.23 95.89,249.51 98.21,253.71 100.69,257.83 103.32,261.84 106.08,265.72 108.97,269.46 111.97,273.04 115.07,276.45 118.25,279.67 121.5,282.69 124.81,285.49 128.17,288.07 131.55,290.41 134.95,292.5 138.35,294.33 141.73,295.9 145.09,297.2 148.4,298.22 151.65,298.96 154.84,299.41 157.93,299.58 160.93,299.46 163.82,299.06 166.58,298.36 169.21,297.39 171.69,296.14 174.02,294.62 176.18,292.83 178.16,290.78 179.95,288.48 181.55,285.94 182.96,283.18 184.16,280.19 185.14,277.01 185.92,273.63 186.47,270.07 186.8,266.36 186.91,262.5" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<polygon points="316.82,202.5 316.71,198.64 316.37,194.93 315.82,191.37 315.05,187.99 314.06,184.81 312.86,181.82 311.46,179.06 309.86,176.52 308.06,174.22 306.08,172.17 303.92,170.38 301.6,168.86 299.12,167.61 296.49,166.64 293.72,165.94 290.84,165.54 287.84,165.42 284.74,165.59 281.56,166.04 278.3,166.78 274.99,167.8 271.64,169.1 268.25,170.67 264.86,172.5 261.46,174.59 258.07,176.93 254.72,179.51 251.41,182.31 248.15,185.33 244.97,188.55 241.87,191.96 238.87,195.54 235.99,199.28 233.22,203.16 230.6,207.17 228.11,211.29 225.79,215.49 223.63,219.77 221.65,224.11 219.86,228.48 218.25,232.87 216.85,237.26 215.65,241.62 214.66,245.95 213.89,250.22 213.34,254.41 213.01,258.51 212.89,262.5 213.01,266.36 213.34,270.07 213.89,273.63 214.66,277.01 215.65,280.19 216.85,283.18 218.25,285.94 219.86,288.48 221.65,290.78 223.63,292.83 225.79,294.62 228.11,296.14 230.6,297.39 233.22,298.36 235.99,299.06 238.87,299.46 241.87,299.58 244.97,299.41 248.15,298.96 251.41,298.22 254.72,297.2 258.07,295.9 261.46,294.33 264.86,292.5 268.25,290.41 271.64,288.07 274.99,285.49 278.3,282.69 281.56,279.67 284.74,276.45 287.84,273.04 290.84,269.46 293.72,265.72 296.49,261.84 299.12,257.83 301.6,253.71 303.92,249.51 306.08,245.23 308.06,240.89 309.86,236.52 311.46,232.13 312.86,227.74 314.06,223.38 315.05,219.05 315.82,214.78 316.37,210.59 316.71,206.49 316.82,202.5" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<text x="200" y="30" font-size="16" text-anchor="middle" font-weight="bold" fill="#111111">Circles become ellipses</text>
</svg>
</div>

*Figure 3. A cube in isometric with a circle drawn on the top, the front and the right side. Each circle shows as an ellipse.*

<div class="figure-art">
<svg viewBox="0 0 720 380" width="100%" role="img" aria-labelledby="rd12-f4-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd12-f4-title">Left: one-point perspective of a box seen straight on. The front face is a true rectangle and the receding edges meet at one vanishing point on the horizon line. Right: two-point perspective of a shed seen from a corner. Horizontal edges meet at two vanishing points on the horizon line. Vertical edges stay vertical.</title>
<rect x="0" y="0" width="720" height="380" fill="#ffffff"/>
<line x1="20" y1="170" x2="340" y2="170" stroke="#1f5fa8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="30" y="162" font-size="14" text-anchor="start" font-weight="bold" fill="#1f5fa8">HL</text>
<line x1="197.81" y1="255" x2="150" y2="170" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<line x1="197.81" y1="191.25" x2="150" y2="170" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<line x1="325.31" y1="191.25" x2="150" y2="170" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<polygon points="197.81,255 174.68,213.87 174.68,180.97 197.81,191.25" fill="#bdbdbd" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="197.81,191.25 325.31,191.25 240.48,180.97 174.68,180.97" fill="#f4f4f4" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="197.81,255 325.31,255 325.31,191.25 197.81,191.25" fill="#d9d9d9" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<circle cx="150" cy="170" r="4" fill="#1f5fa8" stroke="#1f5fa8" stroke-width="1.1"/>
<text x="150" y="160" font-size="14" text-anchor="middle" font-weight="bold" fill="#1f5fa8">VP</text>
<text x="180" y="32" font-size="17" text-anchor="middle" font-weight="bold" fill="#111111">ONE-POINT</text>
<text x="180" y="355" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">One vanishing point</text>
<line x1="375" y1="170" x2="715" y2="170" stroke="#1f5fa8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="714" y="192" font-size="14" text-anchor="end" font-weight="bold" fill="#1f5fa8">HL</text>
<line x1="534.06" y1="240" x2="405" y2="170" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<line x1="534.06" y1="240" x2="685" y2="170" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<line x1="534.06" y1="135" x2="405" y2="170" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<line x1="534.06" y1="135" x2="685" y2="170" stroke="#777777" stroke-width="0.9" stroke-dasharray="3 3" fill="none" stroke-linecap="butt"/>
<polygon points="534.06,240 489.34,215.74 489.34,147.13 534.06,135" fill="#bdbdbd" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="534.06,240 594.23,212.09 594.23,148.95 534.06,135" fill="#d9d9d9" stroke="#111111" stroke-width="2.2" stroke-linejoin="round"/>
<polygon points="561.38,227.33 578.69,219.3 578.69,157.67 561.38,155.67" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<circle cx="405" cy="170" r="4" fill="#1f5fa8" stroke="#1f5fa8" stroke-width="1.1"/>
<text x="405" y="160" font-size="14" text-anchor="middle" font-weight="bold" fill="#1f5fa8">VP</text>
<circle cx="685" cy="170" r="4" fill="#1f5fa8" stroke="#1f5fa8" stroke-width="1.1"/>
<text x="685" y="160" font-size="14" text-anchor="middle" font-weight="bold" fill="#1f5fa8">VP</text>
<text x="550" y="32" font-size="17" text-anchor="middle" font-weight="bold" fill="#111111">TWO-POINT</text>
<text x="550" y="355" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">Two vanishing points</text>
<line x1="360" y1="20" x2="360" y2="365" stroke="#cccccc" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
</svg>
</div>

*Figure 4. Left: one-point perspective of a box seen straight on. Its front face is a true rectangle and its receding edges meet at one vanishing point (VP) on the horizon line (HL). Right: two-point perspective of a shed seen from a corner, with a door on the right wall. Its horizontal edges meet at two vanishing points on the horizon line. Its vertical edges stay vertical.*

### Worked example 1: why you cannot measure a sloped line in isometric

**Question:** In Figure 2, the sloped edge on the right face goes from 20 mm high at the front to 50 mm high at the back, over a depth of 60 mm. How long is it really, and how long is it drawn in a full-size isometric?

1. The real edge is the long side of a right triangle. One side is the depth, 60 mm. The other side is the rise, 50 − 20 = 30 mm.
2. Real length = √(60² + 30²) = √(3600 + 900) = √4500 = **67.08 mm**, about 67 mm.
3. On the isometric drawing, the 60 mm depth goes up and across at 30°, and the 30 mm rise goes straight up. Worked out on the drawing, the line comes out about **79 mm** long.
4. The drawn line is about 12 mm too long.

**Answer:** about 67 mm in real life, but about 79 mm on the drawing. Only lines along the three axes can be measured. To draw the sloped edge, mark 20 mm up at the front and 50 mm up at the back, then join the two points.

<div class="figure-art">
<svg viewBox="0 0 720 470" width="100%" role="img" aria-labelledby="rd12-f5-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd12-f5-title">Single-line isometric piping drawing (fictional, not to scale). The pipe starts at a flange, rises 1200, runs east 2400 to a tee, continues east 1500, drops 600, then runs north 1800 to a flange. A gate valve is on the first east run. The tee branch runs north 900 to a capped end. A north arrow points up and to the right.</title>
<rect x="0" y="0" width="720" height="470" fill="#ffffff"/>
<polyline points="99.45,179.23 99.45,84.01 240.82,165.63 358.63,233.64 358.63,294.86 470.55,230.24" fill="none" stroke="#111111" stroke-width="2.6" stroke-linejoin="miter"/>
<line x1="240.82" y1="165.63" x2="329.18" y2="114.62" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="109.45" y1="179.23" x2="89.45" y2="179.23" stroke="#111111" stroke-width="3"/>
<line x1="109.45" y1="174.23" x2="89.45" y2="174.23" stroke="#111111" stroke-width="3"/>
<line x1="465.55" y1="221.58" x2="475.55" y2="238.9" stroke="#111111" stroke-width="3"/>
<line x1="461.22" y1="224.08" x2="471.22" y2="241.4" stroke="#111111" stroke-width="3"/>
<circle cx="329.18" cy="114.62" r="5" fill="#111111"/>
<circle cx="99.45" cy="84.01" r="4" fill="#111111"/>
<circle cx="358.63" cy="233.64" r="4" fill="#111111"/>
<circle cx="358.63" cy="294.86" r="4" fill="#111111"/>
<polygon points="158.36,118.02 141.23,119.68 151.23,102.36" fill="#ffffff" stroke="#111111" stroke-width="2" stroke-linejoin="round"/>
<polygon points="158.36,118.02 165.48,133.68 175.48,116.36" fill="#ffffff" stroke="#111111" stroke-width="2" stroke-linejoin="round"/>
<text x="87.45" y="201.23" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">START (flange)</text>
<text x="460.55" y="214.24" font-size="14" text-anchor="end" font-weight="normal" fill="#111111">END (flange)</text>
<text x="323.18" y="102.62" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">CAP</text>
<text x="154.36" y="148.02" font-size="13" text-anchor="middle" font-weight="normal" fill="#111111">GATE VALVE</text>
<text x="236.82" y="191.63" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">TEE</text>
<line x1="95.99" y1="177.23" x2="64.8" y2="159.23" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="95.99" y1="82.01" x2="64.8" y2="64" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="70" y1="162.23" x2="70" y2="67" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="70,67 72.83,75.55 67.17,75.55" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="70,162.23 67.17,153.68 72.83,153.68" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="20.2" y="104.62" width="39.6" height="19" fill="#ffffff"/>
<text x="40" y="118.62" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">1200</text>
<line x1="99.45" y1="80.01" x2="99.45" y2="44" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="240.82" y1="161.63" x2="240.82" y2="125.62" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="99.45" y1="50" x2="240.82" y2="131.62" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="240.82,131.62 232.01,129.8 234.84,124.9" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="99.45,50 108.27,51.82 105.44,56.72" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="150.34" y="70.81" width="39.6" height="19" fill="#ffffff"/>
<text x="170.14" y="84.81" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">2400</text>
<line x1="240.82" y1="161.63" x2="240.82" y2="125.62" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="358.63" y1="229.64" x2="358.63" y2="193.64" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="240.82" y1="131.62" x2="358.63" y2="199.64" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="358.63,199.64 349.82,197.82 352.65,192.91" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="240.82,131.62 249.64,133.44 246.8,138.34" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="279.93" y="145.63" width="39.6" height="19" fill="#ffffff"/>
<text x="299.73" y="159.63" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">1500</text>
<line x1="355.17" y1="235.64" x2="318.09" y2="257.05" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="355.17" y1="296.86" x2="318.09" y2="318.26" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="323.29" y1="254.05" x2="323.29" y2="315.26" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="323.29,315.26 320.46,306.72 326.12,306.72" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="323.29,254.05 326.12,262.59 320.46,262.59" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="281.69" y="274.66" width="31.2" height="19" fill="#ffffff"/>
<text x="297.29" y="288.66" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">600</text>
<line x1="362.09" y1="296.86" x2="393.28" y2="314.86" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="474.01" y1="232.24" x2="505.2" y2="250.25" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="388.08" y1="311.86" x2="500" y2="247.25" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="500,247.25 494.02,253.97 491.19,249.07" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="388.08,311.86 394.07,305.14 396.9,310.04" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="450.24" y="281.56" width="39.6" height="19" fill="#ffffff"/>
<text x="470.04" y="295.56" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">1800</text>
<line x1="237.36" y1="163.63" x2="209.12" y2="147.32" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="325.71" y1="112.62" x2="297.48" y2="96.31" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="214.32" y1="150.32" x2="302.67" y2="99.31" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="302.67,99.31 296.69,106.04 293.86,101.13" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="214.32,150.32 220.3,143.6 223.13,148.5" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="226.89" y="106.82" width="31.2" height="19" fill="#ffffff"/>
<text x="242.49" y="120.82" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">900</text>
<line x1="600" y1="150" x2="660.62" y2="115" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<polygon points="660.62,115 651.31,125.46 646.91,117.83" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="670.62" y="111" font-size="18" text-anchor="start" font-weight="bold" fill="#111111">N</text>
<text x="610" y="330" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">ISO-101 (fictional)</text>
<text x="610" y="350" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">NOT TO SCALE</text>
<text x="610" y="370" font-size="13" text-anchor="middle" font-weight="normal" fill="#111111">Dimensions in mm</text>
<text x="610" y="388" font-size="13" text-anchor="middle" font-weight="normal" fill="#111111">to pipe centre lines</text>
</svg>
</div>

*Figure 5. A single-line piping isometric, ISO-101 (fictional), not to scale. Starting at a flange, the pipe rises 1200, runs east 2400 to a tee, runs east another 1500, drops 600, then runs north 1800 to a flange. A gate valve is on the first east run. The tee branch runs north 900 to a cap. The north arrow points up and to the right. Dimensions are in millimetres to pipe centre lines.*

### Worked example 2: read a piping isometric

**Question:** Using Figure 5, how much pipe (centre line length) is in the main run, and how many elbows are there?

1. Find the north arrow. North is up and to the right. So east is down and to the right, and vertical lines are up or down.
2. Follow the pipe from START: up 1200, east 2400 (through the valve to the tee), east 1500, down 600, north 1800 to END.
3. Add the main run: 1200 + 2400 + 1500 + 600 + 1800 = **7500 mm** = 7.5 m.
4. Count the changes of direction on the main run: up to east, east to down, down to north. That is **3 elbows**. The tee is where the branch leaves. It is not an elbow.

**Answer:** 7500 mm of pipe in the main run, with 3 elbows. Real fitters take off allowances for fittings. The centre line total is the starting point.

### Worked example 3: cabinet oblique at a scale

**Question:** A cabinetmaker sketches a base cabinet 900 mm wide, 750 mm high and 600 mm deep in cabinet oblique at a scale of 1:10. How long is each line on the paper?

1. At 1:10, divide each real size by 10.
2. Width: 900 ÷ 10 = **90 mm**. Height: 750 ÷ 10 = **75 mm**. These form the true-shape front face.
3. Depth: cabinet oblique uses half depth. 600 ÷ 2 = 300 mm, then 300 ÷ 10 = **30 mm**, drawn back at 45°.

**Answer:** a 90 mm by 75 mm front rectangle, with 30 mm depth lines at 45°.

## Practice

<div class="figure-art">
<svg viewBox="0 0 720 400" width="100%" role="img" aria-labelledby="rd12-f6-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd12-f6-title">Isometric grid exercise. Left: three views of a step block in third-angle projection on a square grid. Right: an isometric grid with one corner point marked as a starting point.</title>
<defs><clipPath id="rd12-f6-gc"><rect x="330" y="30" width="380" height="340"/></clipPath></defs>
<rect x="0" y="0" width="720" height="400" fill="#ffffff"/>
<line x1="20" y1="30" x2="20" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="37" y1="30" x2="37" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="54" y1="30" x2="54" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="71" y1="30" x2="71" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="88" y1="30" x2="88" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="105" y1="30" x2="105" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="122" y1="30" x2="122" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="139" y1="30" x2="139" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="156" y1="30" x2="156" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="173" y1="30" x2="173" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="190" y1="30" x2="190" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="207" y1="30" x2="207" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="224" y1="30" x2="224" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="241" y1="30" x2="241" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="258" y1="30" x2="258" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="275" y1="30" x2="275" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="30" x2="275" y2="30" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="47" x2="275" y2="47" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="64" x2="275" y2="64" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="81" x2="275" y2="81" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="98" x2="275" y2="98" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="115" x2="275" y2="115" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="132" x2="275" y2="132" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="149" x2="275" y2="149" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="166" x2="275" y2="166" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="183" x2="275" y2="183" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="200" x2="275" y2="200" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="217" x2="275" y2="217" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="234" x2="275" y2="234" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="251" x2="275" y2="251" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="268" x2="275" y2="268" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="285" x2="275" y2="285" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="302" x2="275" y2="302" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="319" x2="275" y2="319" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="336" x2="275" y2="336" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="353" x2="275" y2="353" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="20" y1="370" x2="275" y2="370" stroke="#dde6f2" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="37" y1="336" x2="173" y2="336" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="37" y1="234" x2="122" y2="234" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="122" y1="285" x2="173" y2="285" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="37" y1="336" x2="37" y2="234" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="122" y1="285" x2="122" y2="234" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="173" y1="336" x2="173" y2="285" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="37" y1="200" x2="173" y2="200" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="37" y1="115" x2="173" y2="115" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="37" y1="200" x2="37" y2="115" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="122" y1="200" x2="122" y2="115" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="173" y1="200" x2="173" y2="115" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="190" y1="336" x2="275" y2="336" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="190" y1="285" x2="275" y2="285" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="190" y1="234" x2="275" y2="234" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="190" y1="336" x2="190" y2="234" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="275" y1="336" x2="275" y2="234" stroke="#111111" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<text x="105" y="356" font-size="13" text-anchor="middle" font-weight="bold" fill="#111111">FRONT</text>
<text x="105" y="216" font-size="13" text-anchor="middle" font-weight="bold" fill="#111111">TOP</text>
<text x="232.5" y="356" font-size="13" text-anchor="middle" font-weight="bold" fill="#111111">RIGHT</text>
<g clip-path="url(#rd12-f6-gc)">
<line x1="330" y1="30" x2="330" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="349.05" y1="30" x2="349.05" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="368.11" y1="30" x2="368.11" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="387.16" y1="30" x2="387.16" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="406.21" y1="30" x2="406.21" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="425.26" y1="30" x2="425.26" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="444.32" y1="30" x2="444.32" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="463.37" y1="30" x2="463.37" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="482.42" y1="30" x2="482.42" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="501.47" y1="30" x2="501.47" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="520.53" y1="30" x2="520.53" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="539.58" y1="30" x2="539.58" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="558.63" y1="30" x2="558.63" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="577.68" y1="30" x2="577.68" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="596.74" y1="30" x2="596.74" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="615.79" y1="30" x2="615.79" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="634.84" y1="30" x2="634.84" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="653.89" y1="30" x2="653.89" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="672.95" y1="30" x2="672.95" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="692" y1="30" x2="692" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="711.05" y1="30" x2="711.05" y2="370" stroke="#c9d6e8" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="330" y1="-190" x2="710" y2="29.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-190" x2="710" y2="-409.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-168" x2="710" y2="51.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-168" x2="710" y2="-387.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-146" x2="710" y2="73.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-146" x2="710" y2="-365.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-124" x2="710" y2="95.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-124" x2="710" y2="-343.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-102" x2="710" y2="117.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-102" x2="710" y2="-321.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-80" x2="710" y2="139.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-80" x2="710" y2="-299.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-58" x2="710" y2="161.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-58" x2="710" y2="-277.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-36" x2="710" y2="183.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-36" x2="710" y2="-255.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-14" x2="710" y2="205.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="-14" x2="710" y2="-233.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="8" x2="710" y2="227.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="8" x2="710" y2="-211.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="30" x2="710" y2="249.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="30" x2="710" y2="-189.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="52" x2="710" y2="271.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="52" x2="710" y2="-167.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="74" x2="710" y2="293.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="74" x2="710" y2="-145.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="96" x2="710" y2="315.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="96" x2="710" y2="-123.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="118" x2="710" y2="337.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="118" x2="710" y2="-101.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="140" x2="710" y2="359.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="140" x2="710" y2="-79.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="162" x2="710" y2="381.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="162" x2="710" y2="-57.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="184" x2="710" y2="403.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="184" x2="710" y2="-35.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="206" x2="710" y2="425.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="206" x2="710" y2="-13.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="228" x2="710" y2="447.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="228" x2="710" y2="8.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="250" x2="710" y2="469.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="250" x2="710" y2="30.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="272" x2="710" y2="491.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="272" x2="710" y2="52.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="294" x2="710" y2="513.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="294" x2="710" y2="74.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="316" x2="710" y2="535.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="316" x2="710" y2="96.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="338" x2="710" y2="557.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="338" x2="710" y2="118.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="360" x2="710" y2="579.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="360" x2="710" y2="140.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="382" x2="710" y2="601.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="382" x2="710" y2="162.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="404" x2="710" y2="623.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="404" x2="710" y2="184.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="426" x2="710" y2="645.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="426" x2="710" y2="206.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="448" x2="710" y2="667.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="448" x2="710" y2="228.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="470" x2="710" y2="689.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="470" x2="710" y2="250.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="492" x2="710" y2="711.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="492" x2="710" y2="272.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="514" x2="710" y2="733.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="514" x2="710" y2="294.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="536" x2="710" y2="755.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="536" x2="710" y2="316.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="558" x2="710" y2="777.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="558" x2="710" y2="338.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="580" x2="710" y2="799.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="580" x2="710" y2="360.61" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="602" x2="710" y2="821.39" stroke="#c9d6e8" stroke-width="1"/>
<line x1="330" y1="602" x2="710" y2="382.61" stroke="#c9d6e8" stroke-width="1"/>
</g>
<rect x="330" y="30" width="380" height="340" fill="none" stroke="#9fb3cf" stroke-width="1.1"/>
<circle cx="444.32" cy="250" r="5" fill="#b3261e"/>
<text x="436.32" y="272" font-size="13" text-anchor="start" font-weight="normal" fill="#b3261e">start: front left bottom corner</text>
<text x="520" y="22" font-size="14" text-anchor="middle" font-weight="bold" fill="#111111">ISOMETRIC GRID</text>
<text x="170" y="22" font-size="13" text-anchor="middle" font-weight="normal" fill="#111111">1 square = 1 grid step</text>
</svg>
</div>

*Figure 6. Grid exercise. Left: the front, top and right side views of a step block on a square grid (third-angle projection). The block is 8 squares wide, 5 deep and 6 high. A step 3 squares wide and 3 squares down is cut from the top right. Right: isometric grid paper with a red dot at the front left bottom corner.*

**Task 1** (level 1)
Use Figure 1.
a) In which drawings is the hole a true circle?
b) Why is it a true circle in those drawings?
c) What shape is the hole in the isometric drawing?

**Task 2** (level 1)
Use Figure 2.
a) At what angle from horizontal are the width and depth axes drawn?
b) How many degrees apart are the three axes?
c) Which axis is drawn straight up?

**Task 3** (level 1)
Use Figure 4.
a) What do the letters HL and VP stand for?
b) How many vanishing points does each drawing have?
c) In the two-point drawing, what happens to the vertical edges?

**Task 4** (level 2)
The block in Figure 1 is 60 mm deep. All three drawings are full size.
a) How long is the depth line in the cavalier drawing?
b) How long is it in the cabinet drawing?
c) A welder wants to sketch a 600 mm deep tool cart so it does not look stretched. Which kind of oblique should they use, and how long is the depth line at full size?

**Task 5** (level 2)
Use Figure 2. You have a full-size isometric drawing of the sloped block and a ruler.
a) Can you measure the 80 mm bottom front edge? Why?
b) Can you measure the 50 mm height at the back corner? Why?
c) Can you measure the sloped edge? Why?

**Task 6** (level 2)
Use Figure 5. A pipefitter is walking the line. Starting at START, list each run of the main line in order. For each run, give the direction (up, down, north, south, east or west) and the length.

**Task 7** (level 2)
Use Figure 5.
a) How many tees and how many valves are on the drawing?
b) What is the total centre line length of pipe, main run plus branch, in millimetres and in metres?
c) What does the note NOT TO SCALE tell you?

**Task 8** (level 2)
Pick the best kind of pictorial drawing for each job: isometric, oblique or perspective. Give one reason for each.
a) A welder sketches a steel base plate with four bolt holes on its face.
b) A homeowner wants to see what a new deck will look like from the yard.
c) A pipefitter needs the route of a pipe spool with every elbow and dimension.
d) A carpenter sketches a cabinet on grid paper and wants to show all three sizes with no stretching.

**Task 9** (level 3)
Use Figure 6. Sketch the step block on isometric grid paper. Start at the red dot. Use one grid step for each square. Draw the three box edges first (width 8, depth 5, height 6), then cut away the step. Do not draw hidden edges.

**Task 10** (level 3)
On a photocopy of ISO-101, the 1800 dimension is smudged. A helper measures the north run on the paper with a tape, compares it with the 2400 run, and says, "It's about 1800, close enough." Is this a safe way to get the length? Explain why or why not, and say what you would do.

**Task 11** (level 3)
A framer is handed only the two-point perspective of the shed in Figure 4 and asked to cut the door header. Explain why the framer cannot get sizes from this drawing. Name the kind of drawing they need instead, and say what it should show.

_______________________________________________

_______________________________________________

## Check yourself

1. In an isometric drawing, which lines can you measure?
2. What happens to a circle on the face of an isometric drawing?
3. What is the difference between cavalier and cabinet oblique?
4. Where are the vanishing points in a perspective drawing?
5. Why is a piping isometric not drawn to scale, and where do you get the lengths?
