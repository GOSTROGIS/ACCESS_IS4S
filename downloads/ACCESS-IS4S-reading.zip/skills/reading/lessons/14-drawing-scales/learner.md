---
title: Drawing scales and the scale rule
summary: Read imperial architectural scales, engineer's scales and metric ratio scales, use a scale rule, change a measured drawing length into a real size and back, and know when a drawing must not be scaled.
level: 1-3
time: 90 min
components: Identify the information; Make connections between different parts of the document(s); Understand and apply the information; Evaluate the document(s)
---

# Drawing scales and the scale rule

## Why this matters on the job

A house does not fit on a sheet of paper, so it is drawn smaller, to **scale**. On site you need to know what scale a drawing uses, how to read a scale rule, and how to turn a length on paper into a real length. You also need to know when **not** to measure a drawing. Prints shrink, copies get resized, and a dimension can be changed without the line being redrawn. A carpenter who scales a reduced copy can be off by a metre. [Reading lesson 5](../05-read-a-floor-plan/learner.html) introduced "Scale 1:50" and the note "Do not scale this drawing". This lesson goes deeper.

## Key ideas

**1. What a scale is.** A scale compares a length on the drawing with the real length. It is written in the title block, or under the title of a view. One sheet can have more than one scale. A detail is often drawn bigger than the plan.

**2. Imperial architectural scales.** These are written as a length on paper equals one foot: **1/4" = 1'-0"** means every 1/4 inch on the paper stands for 1 foot in real life. Common architectural scales are 1/8" = 1'-0", 3/16" = 1'-0", 1/4" = 1'-0", 1/2" = 1'-0", 3/4" = 1'-0", 1 1/2" = 1'-0" and 3" = 1'-0". The bigger the fraction, the bigger the drawing. Plans are often 1/4" or 1/8". Details are often 3/4", 1 1/2" or 3".

**3. Change paper inches to real feet.** Divide the measured inches by the scale fraction. That is the same as multiplying by a number:

| Scale | Multiply paper inches by | Ratio |
|---|---|---|
| 1/8" = 1'-0" | 8 | 1:96 |
| 3/16" = 1'-0" | 16/3 | 1:64 |
| 1/4" = 1'-0" | 4 | 1:48 |
| 1/2" = 1'-0" | 2 | 1:24 |
| 3/4" = 1'-0" | 4/3 | 1:16 |
| 1 1/2" = 1'-0" | 2/3 | 1:8 |
| 3" = 1'-0" | 1/3 | 1:4 |

The answer is in **feet**. To go the other way (real feet to paper inches), multiply the feet by the scale fraction.

**4. The architect's scale rule.** It has three sides and six edges. Most edges carry two scales that read in **opposite directions**, such as 1/8 from one end and 1/4 from the other. The zero is **not** at the very end. Past the zero is one foot cut into inches. To measure: put a whole-foot mark on one end of the line, so the other end falls in the inch part past zero. Read feet, then inches.

**5. Engineer's scale (civil scale).** It divides an inch into 10, 20, 30, 40, 50 or 60 parts. It is used for site plans, roads and water mains, with scales such as 1" = 20' or 1" = 50'. Lengths are in feet and **tenths** of a foot, not feet and inches.

**6. Metric ratio scales.** **1:50** means 1 mm on paper stands for 50 mm in real life. Common metric scales are 1:200 or 1:500 for site plans, 1:100 and 1:50 for plans, 1:20 for wall sections, and 1:10, 1:5 or 1:1 for details.

- Real size = paper length × the scale number.
- Paper length = real size ÷ the scale number.

A metric scale rule has one ratio on each edge. It reads real lengths straight off, in metres.

**7. Scale bars and NTS.** A **scale bar** (graphic scale) is a small ruler printed on the sheet. If the print is copied bigger or smaller, the bar changes size with the drawing, so it stays right. The written scale does not. **NTS** means "not to scale". Never measure an NTS drawing.

**8. Written dimensions win.** If a dimension is written, use it. Do not measure the drawing. Copies can shrink, paper can stretch, and a changed dimension may not have been redrawn. Scale a drawing **only** when no dimension is given or for a rough check. Treat the answer as approximate, use the scale bar if you can, and confirm it before you cut, drill or pour anything.

<div class="figure-art">
<svg viewBox="0 0 680 300" width="100%" role="img" aria-labelledby="rd14-f1-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd14-f1-title">The 1/4 inch = 1 foot edge of an architect's scale, enlarged. Zero is near the right end. Feet are numbered from zero toward the left, every 2 feet. To the right of zero is one foot divided into 12 inches. A line on a drawing is measured: its left end sits on the 13 foot mark and its right end sits on the 6 inch mark past zero. The reading is 13 feet 6 inches.</title>
<rect x="0" y="0" width="680" height="300" fill="#ffffff"/>
<rect x="30" y="170" width="635" height="80" fill="#f6efe0" stroke="#111111" stroke-width="1.5"/>
<line x1="600" y1="170" x2="600" y2="196" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="600" y="214" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">0</text>
<line x1="562.5" y1="170" x2="562.5" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="525" y1="170" x2="525" y2="196" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="525" y="214" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">2</text>
<line x1="487.5" y1="170" x2="487.5" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="450" y1="170" x2="450" y2="196" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="450" y="214" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">4</text>
<line x1="412.5" y1="170" x2="412.5" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="375" y1="170" x2="375" y2="196" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="375" y="214" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">6</text>
<line x1="337.5" y1="170" x2="337.5" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="300" y1="170" x2="300" y2="196" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="300" y="214" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">8</text>
<line x1="262.5" y1="170" x2="262.5" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="225" y1="170" x2="225" y2="196" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="225" y="214" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">10</text>
<line x1="187.5" y1="170" x2="187.5" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="150" y1="170" x2="150" y2="196" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="150" y="214" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">12</text>
<line x1="112.5" y1="170" x2="112.5" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="75" y1="170" x2="75" y2="196" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="75" y="214" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">14</text>
<line x1="603.12" y1="170" x2="603.12" y2="177" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="606.25" y1="170" x2="606.25" y2="177" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="609.38" y1="170" x2="609.38" y2="181" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="612.5" y1="170" x2="612.5" y2="177" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="615.62" y1="170" x2="615.62" y2="177" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="618.75" y1="170" x2="618.75" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="621.88" y1="170" x2="621.88" y2="177" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="625" y1="170" x2="625" y2="177" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="628.12" y1="170" x2="628.12" y2="181" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="631.25" y1="170" x2="631.25" y2="177" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="634.38" y1="170" x2="634.38" y2="177" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="637.5" y1="170" x2="637.5" y2="186" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="618.75" y="234" font-size="12" text-anchor="middle" font-weight="normal" fill="#777777">inches</text>
<text x="643.5" y="214" font-size="15" text-anchor="start" font-weight="bold" fill="#111111">1/4</text>
<text x="60" y="240" font-size="13" text-anchor="start" font-weight="normal" fill="#777777">feet, counted to the LEFT from 0</text>
<line x1="112.5" y1="130" x2="618.75" y2="130" stroke="#b3261e" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="112.5" y1="118" x2="112.5" y2="170" stroke="#b3261e" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="618.75" y1="118" x2="618.75" y2="170" stroke="#b3261e" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="365.62" y="116" font-size="15" text-anchor="middle" font-weight="normal" fill="#b3261e">wall on the drawing</text>
<polyline points="112.5,168 142.5,75 146.5,75" fill="none" stroke="#1f5fa8" stroke-width="1.1" stroke-linejoin="miter"/>
<polygon points="112.5,168 112.42,158 118.41,159.93" fill="#1f5fa8" stroke="#1f5fa8" stroke-width="1"/>
<text x="151.5" y="81" font-size="14" text-anchor="start" font-weight="normal" fill="#1f5fa8">left end on 13</text>
<polyline points="618.75,168 638.75,80 608.75,80" fill="none" stroke="#1f5fa8" stroke-width="1.1" stroke-linejoin="miter"/>
<polygon points="618.75,168 617.79,158.05 623.92,159.44" fill="#1f5fa8" stroke="#1f5fa8" stroke-width="1"/>
<text x="603.75" y="86" font-size="14" text-anchor="end" font-weight="normal" fill="#1f5fa8">right end on 6&quot;</text>
<text x="340" y="290" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">Reading: 13 feet + 6 inches = 13'-6&quot;  (enlarged, not true size)</text>
</svg>
</div>

*Figure 1. The 1/4" = 1'-0" edge of an architect's scale, enlarged. Zero is near the right end. Feet are numbered to the left of zero, every 2 feet. To the right of zero, one foot is cut into 12 inches. A wall on a drawing has its left end on the 13 mark and its right end on the 6-inch mark. It reads 13'-6".*

<div class="figure-art">
<svg viewBox="0 0 680 330" width="100%" role="img" aria-labelledby="rd14-f2-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd14-f2-title">Two edges of a metric scale rule, enlarged. Both edges have marks 1 mm apart on the paper. The top edge is labelled 1:50 and reads 0 to 3 metres. The bottom edge is labelled 1:100 and reads 0 to 6 metres. A line 47 mm long on the paper reads 2.35 m on the 1:50 edge and 4.7 m on the 1:100 edge.</title>
<rect x="0" y="0" width="680" height="330" fill="#ffffff"/>
<rect x="30" y="110" width="580.0" height="60" fill="#f6efe0" stroke="#111111" stroke-width="1.5"/>
<line x1="50" y1="110" x2="50" y2="134" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="50" y="150" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">0</text>
<line x1="59" y1="110" x2="59" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="68" y1="110" x2="68" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="77" y1="110" x2="77" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="86" y1="110" x2="86" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="95" y1="110" x2="95" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="104" y1="110" x2="104" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="113" y1="110" x2="113" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="122" y1="110" x2="122" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="131" y1="110" x2="131" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="140" y1="110" x2="140" y2="127" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="140" y="150" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">0.5</text>
<line x1="149" y1="110" x2="149" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="158" y1="110" x2="158" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="167" y1="110" x2="167" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="176" y1="110" x2="176" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="185" y1="110" x2="185" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="194" y1="110" x2="194" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="203" y1="110" x2="203" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="212" y1="110" x2="212" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="221" y1="110" x2="221" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="230" y1="110" x2="230" y2="134" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="230" y="150" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">1</text>
<line x1="239" y1="110" x2="239" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="248" y1="110" x2="248" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="257" y1="110" x2="257" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="266" y1="110" x2="266" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="275" y1="110" x2="275" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="284" y1="110" x2="284" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="293" y1="110" x2="293" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="302" y1="110" x2="302" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="311" y1="110" x2="311" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="320" y1="110" x2="320" y2="127" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="320" y="150" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">1.5</text>
<line x1="329" y1="110" x2="329" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="338" y1="110" x2="338" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="347" y1="110" x2="347" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="356" y1="110" x2="356" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="365" y1="110" x2="365" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="374" y1="110" x2="374" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="383" y1="110" x2="383" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="392" y1="110" x2="392" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="401" y1="110" x2="401" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="410" y1="110" x2="410" y2="134" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="410" y="150" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">2</text>
<line x1="419" y1="110" x2="419" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="428" y1="110" x2="428" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="437" y1="110" x2="437" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="446" y1="110" x2="446" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="455" y1="110" x2="455" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="464" y1="110" x2="464" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="473" y1="110" x2="473" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="482" y1="110" x2="482" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="491" y1="110" x2="491" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="500" y1="110" x2="500" y2="127" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="500" y="150" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">2.5</text>
<line x1="509" y1="110" x2="509" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="518" y1="110" x2="518" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="527" y1="110" x2="527" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="536" y1="110" x2="536" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="545" y1="110" x2="545" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="554" y1="110" x2="554" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="563" y1="110" x2="563" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="572" y1="110" x2="572" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="581" y1="110" x2="581" y2="119" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="590" y1="110" x2="590" y2="134" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="590" y="150" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">3</text>
<text x="38" y="166" font-size="14" text-anchor="start" font-weight="bold" fill="#111111">1:50</text>
<text x="602" y="150" font-size="14" text-anchor="start" font-weight="normal" fill="#111111">m</text>
<rect x="30" y="230" width="580.0" height="60" fill="#f6efe0" stroke="#111111" stroke-width="1.5"/>
<line x1="50" y1="230" x2="50" y2="254" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="50" y="270" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">0</text>
<line x1="59" y1="230" x2="59" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="68" y1="230" x2="68" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="77" y1="230" x2="77" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="86" y1="230" x2="86" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="95" y1="230" x2="95" y2="247" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="104" y1="230" x2="104" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="113" y1="230" x2="113" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="122" y1="230" x2="122" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="131" y1="230" x2="131" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="140" y1="230" x2="140" y2="254" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="140" y="270" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">1</text>
<line x1="149" y1="230" x2="149" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="158" y1="230" x2="158" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="167" y1="230" x2="167" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="176" y1="230" x2="176" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="185" y1="230" x2="185" y2="247" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="194" y1="230" x2="194" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="203" y1="230" x2="203" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="212" y1="230" x2="212" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="221" y1="230" x2="221" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="230" y1="230" x2="230" y2="254" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="230" y="270" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">2</text>
<line x1="239" y1="230" x2="239" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="248" y1="230" x2="248" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="257" y1="230" x2="257" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="266" y1="230" x2="266" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="275" y1="230" x2="275" y2="247" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="284" y1="230" x2="284" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="293" y1="230" x2="293" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="302" y1="230" x2="302" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="311" y1="230" x2="311" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="320" y1="230" x2="320" y2="254" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="320" y="270" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">3</text>
<line x1="329" y1="230" x2="329" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="338" y1="230" x2="338" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="347" y1="230" x2="347" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="356" y1="230" x2="356" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="365" y1="230" x2="365" y2="247" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="374" y1="230" x2="374" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="383" y1="230" x2="383" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="392" y1="230" x2="392" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="401" y1="230" x2="401" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="410" y1="230" x2="410" y2="254" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="410" y="270" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">4</text>
<line x1="419" y1="230" x2="419" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="428" y1="230" x2="428" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="437" y1="230" x2="437" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="446" y1="230" x2="446" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="455" y1="230" x2="455" y2="247" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="464" y1="230" x2="464" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="473" y1="230" x2="473" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="482" y1="230" x2="482" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="491" y1="230" x2="491" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="500" y1="230" x2="500" y2="254" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="500" y="270" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">5</text>
<line x1="509" y1="230" x2="509" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="518" y1="230" x2="518" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="527" y1="230" x2="527" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="536" y1="230" x2="536" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="545" y1="230" x2="545" y2="247" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="554" y1="230" x2="554" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="563" y1="230" x2="563" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="572" y1="230" x2="572" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="581" y1="230" x2="581" y2="239" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="590" y1="230" x2="590" y2="254" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<text x="590" y="270" font-size="14" text-anchor="middle" font-weight="normal" fill="#111111">6</text>
<text x="38" y="286" font-size="14" text-anchor="start" font-weight="bold" fill="#111111">1:100</text>
<text x="602" y="270" font-size="14" text-anchor="start" font-weight="normal" fill="#111111">m</text>
<line x1="50" y1="200" x2="473" y2="200" stroke="#b3261e" stroke-width="2.6" fill="none" stroke-linecap="butt"/>
<line x1="50" y1="170" x2="50" y2="230" stroke="#b3261e" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="473" y1="170" x2="473" y2="230" stroke="#b3261e" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<rect x="149.3" y="178" width="224.4" height="19" fill="#ffffff"/>
<text x="261.5" y="192" font-size="15" text-anchor="middle" font-weight="normal" fill="#b3261e">line on the drawing: 47 mm</text>
<text x="483" y="100" font-size="15" text-anchor="start" font-weight="bold" fill="#1f5fa8">2.35 m at 1:50</text>
<text x="483" y="316" font-size="15" text-anchor="start" font-weight="bold" fill="#1f5fa8">4.7 m at 1:100</text>
<text x="340" y="40" font-size="16" text-anchor="middle" font-weight="bold" fill="#111111">Metric scale rule, two edges (enlarged)</text>
<text x="340" y="62" font-size="14" text-anchor="middle" font-weight="normal" fill="#777777">Each small mark is 1 mm on the paper</text>
</svg>
</div>

*Figure 2. Two edges of a metric scale rule, enlarged. The 1:50 edge reads 0 to 3 m. The 1:100 edge reads 0 to 6 m. A line 47 mm long on the paper reads 2.35 m at 1:50 and 4.7 m at 1:100.*

### Worked example 1: paper to real, imperial

**Question:** On a floor plan at 1/4" = 1'-0", a wall measures 3 3/8" with a ruler. How long is the wall? Then check it on the scale rule (Figure 1).

1. At 1/4" = 1'-0", multiply paper inches by 4.
2. 3 3/8 × 4 = 13 1/2 feet. (3 × 4 = 12, and 3/8 × 4 = 1 1/2.)
3. 1/2 foot = 6 inches. So 13 1/2 feet = **13'-6"**.
4. On the scale rule, the line runs from the 13 mark to 6 inches past zero. It reads 13'-6". The two methods agree.

**Answer:** **13'-6"**.

### Worked example 2: real to paper, imperial

**Question:** A 22'-6" wall is drawn at 1/4" = 1'-0". How long is it on the paper?

1. 22'-6" = 22 1/2 feet.
2. Paper length = feet × 1/4 = 22 1/2 × 1/4 = 5 5/8 inches.

**Answer:** **5 5/8"** on the paper.

### Worked example 3: metric both ways

**Question:** a) On a 1:50 plan a line measures 47 mm. How long is it in real life? b) A shed is 3600 mm by 2400 mm. How big is it on paper at 1:50 and at 1:100?

1. a) Real = 47 × 50 = **2350 mm** (2.35 m). This matches the 1:50 edge in Figure 2.
2. b) At 1:50: 3600 ÷ 50 = **72 mm** and 2400 ÷ 50 = **48 mm**.
3. At 1:100: 3600 ÷ 100 = **36 mm** and 2400 ÷ 100 = **24 mm**. The 1:100 drawing is half as big.

**Answer:** a) 2350 mm. b) 72 mm by 48 mm at 1:50, 36 mm by 24 mm at 1:100.

<div class="figure-art">
<svg viewBox="0 0 680 320" width="100%" role="img" aria-labelledby="rd14-f3-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd14-f3-title">The same shed floor plan, 3600 by 2400 mm, drawn at 1:50 on the left and at 1:100 on the right. At 1:50 it is 72 by 48 mm on paper. At 1:100 it is 36 by 24 mm, half as big.</title>
<rect x="0" y="0" width="680" height="320" fill="#ffffff"/>
<rect x="40" y="70" width="230.4" height="153.6" fill="none" stroke="#111111" stroke-width="2.6"/>
<line x1="74.56" y1="223.6" x2="132.16" y2="223.6" stroke="#ffffff" stroke-width="5"/>
<line x1="74.56" y1="223.6" x2="74.56" y2="166" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polyline points="74.56,166 79.58,166.22 84.56,166.88 89.47,167.96 94.26,169.47 98.9,171.4 103.36,173.72 107.6,176.42 111.58,179.48 115.29,182.87 118.68,186.58 121.74,190.56 124.44,194.8 126.76,199.26 128.69,203.9 130.2,208.69 131.28,213.6 131.94,218.58 132.16,223.6" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<text x="155.2" y="152.8" font-size="14" text-anchor="middle" font-weight="normal" fill="#777777">SHED</text>
<text x="155.2" y="257.6" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">SCALE 1:50</text>
<line x1="40" y1="66" x2="40" y2="39" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="270.4" y1="66" x2="270.4" y2="39" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="40" y1="45" x2="270.4" y2="45" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="40,45 48.54,42.17 48.54,47.83" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="270.4,45 261.86,47.83 261.86,42.17" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="155.2" y="40" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">3600</text>
<line x1="36" y1="70" x2="16" y2="70" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="36" y1="223.6" x2="16" y2="223.6" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="22" y1="70" x2="22" y2="223.6" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="22,70 24.83,78.54 19.17,78.54" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="22,223.6 19.17,215.06 24.83,215.06" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="16" y="146.8" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111" transform="rotate(-90 16 146.8)">2400</text>
<text x="155.2" y="300" font-size="14" text-anchor="middle" font-weight="normal" fill="#1f5fa8">on paper: 72 mm x 48 mm</text>
<rect x="440" y="146.8" width="115.2" height="76.8" fill="none" stroke="#111111" stroke-width="2.6"/>
<line x1="457.28" y1="223.6" x2="486.08" y2="223.6" stroke="#ffffff" stroke-width="5"/>
<line x1="457.28" y1="223.6" x2="457.28" y2="194.8" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polyline points="457.28,194.8 459.79,194.91 462.28,195.24 464.73,195.78 467.13,196.54 469.45,197.5 471.68,198.66 473.8,200.01 475.79,201.54 477.64,203.24 479.34,205.09 480.87,207.08 482.22,209.2 483.38,211.43 484.34,213.75 485.1,216.15 485.64,218.6 485.97,221.09 486.08,223.6" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<text x="497.6" y="191.2" font-size="14" text-anchor="middle" font-weight="normal" fill="#777777">SHED</text>
<text x="497.6" y="257.6" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">SCALE 1:100</text>
<line x1="440" y1="142.8" x2="440" y2="115.8" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="555.2" y1="142.8" x2="555.2" y2="115.8" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="440" y1="121.8" x2="555.2" y2="121.8" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="440,121.8 448.54,118.97 448.54,124.63" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="555.2,121.8 546.66,124.63 546.66,118.97" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="497.6" y="116.8" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111">3600</text>
<line x1="559.2" y1="146.8" x2="593.2" y2="146.8" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="559.2" y1="223.6" x2="593.2" y2="223.6" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="587.2" y1="146.8" x2="587.2" y2="223.6" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="587.2,146.8 590.03,155.34 584.37,155.34" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="587.2,223.6 584.37,215.06 590.03,215.06" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="581.2" y="185.2" font-size="15" text-anchor="middle" font-weight="normal" fill="#111111" transform="rotate(-90 581.2 185.2)">2400</text>
<text x="497.6" y="300" font-size="14" text-anchor="middle" font-weight="normal" fill="#1f5fa8">on paper: 36 mm x 24 mm</text>
<line x1="380" y1="30" x2="380" y2="300" stroke="#cccccc" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
</svg>
</div>

*Figure 3. The same shed plan, 3600 by 2400 mm, at 1:50 (left) and 1:100 (right). On paper it is 72 by 48 mm at 1:50 and 36 by 24 mm at 1:100. The dimensions written on both are the same.*

<div class="figure-art">
<svg viewBox="0 0 680 360" width="100%" role="img" aria-labelledby="rd14-f4-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd14-f4-title">Left: a sheet with a shed plan at the written scale 1:100 and a graphic scale bar from 0 to 5 metres. Right: the same sheet copied at 70 percent. The plan and the scale bar both shrink. The written scale still says 1:100, but it is no longer true. The scale bar still measures correctly.</title>
<rect x="0" y="0" width="680" height="360" fill="#ffffff"/>
<rect x="30" y="40" width="330" height="250" fill="none" stroke="#999999" stroke-width="1.1"/>
<rect x="80" y="75" width="144" height="96" fill="none" stroke="#111111" stroke-width="2.6"/>
<line x1="101.6" y1="171" x2="137.6" y2="171" stroke="#ffffff" stroke-width="5"/>
<line x1="101.6" y1="171" x2="101.6" y2="135" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polyline points="101.6,135 104.74,135.14 107.85,135.55 110.92,136.23 113.91,137.17 116.81,138.37 119.6,139.82 122.25,141.51 124.74,143.42 127.06,145.54 129.18,147.86 131.09,150.35 132.78,153 134.23,155.79 135.43,158.69 136.37,161.68 137.05,164.75 137.46,167.86 137.6,171" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<text x="152" y="129" font-size="14" text-anchor="middle" font-weight="normal" fill="#777777">SHED</text>
<text x="195" y="220" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">SCALE 1:100</text>
<rect x="75" y="242" width="40" height="8" fill="#ffffff" stroke="#111111" stroke-width="1"/>
<rect x="75" y="242" width="20" height="8" fill="#111111"/>
<rect x="115" y="242" width="40" height="8" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="155" y="242" width="40" height="8" fill="#ffffff" stroke="#111111" stroke-width="1"/>
<rect x="195" y="242" width="40" height="8" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="235" y="242" width="40" height="8" fill="#ffffff" stroke="#111111" stroke-width="1"/>
<rect x="275" y="242" width="40" height="8" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="75" y="266" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">1</text>
<text x="115" y="266" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">0</text>
<text x="155" y="266" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">1</text>
<text x="195" y="266" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">2</text>
<text x="235" y="266" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">3</text>
<text x="275" y="266" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">4</text>
<text x="315" y="266" font-size="12" text-anchor="middle" font-weight="normal" fill="#111111">5 m</text>
<rect x="410" y="40" width="231" height="175" fill="none" stroke="#999999" stroke-width="1.1"/>
<rect x="448" y="70.5" width="100.8" height="67.2" fill="none" stroke="#111111" stroke-width="2.6"/>
<line x1="463.12" y1="137.7" x2="488.32" y2="137.7" stroke="#ffffff" stroke-width="5"/>
<line x1="463.12" y1="137.7" x2="463.12" y2="112.5" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polyline points="463.12,112.5 465.32,112.6 467.5,112.88 469.64,113.36 471.74,114.02 473.77,114.86 475.72,115.88 477.57,117.06 479.32,118.4 480.94,119.88 482.42,121.5 483.76,123.25 484.94,125.1 485.96,127.05 486.8,129.08 487.46,131.18 487.94,133.32 488.22,135.5 488.32,137.7" fill="none" stroke="#111111" stroke-width="1.1" stroke-linejoin="miter"/>
<text x="498.4" y="110.1" font-size="11.2" text-anchor="middle" font-weight="normal" fill="#777777">SHED</text>
<text x="528.5" y="172" font-size="12" text-anchor="middle" font-weight="bold" fill="#111111">SCALE 1:100</text>
<rect x="444.5" y="187.4" width="28" height="8" fill="#ffffff" stroke="#111111" stroke-width="1"/>
<rect x="444.5" y="187.4" width="14" height="8" fill="#111111"/>
<rect x="472.5" y="187.4" width="28" height="8" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="500.5" y="187.4" width="28" height="8" fill="#ffffff" stroke="#111111" stroke-width="1"/>
<rect x="528.5" y="187.4" width="28" height="8" fill="#111111" stroke="#111111" stroke-width="1"/>
<rect x="556.5" y="187.4" width="28" height="8" fill="#ffffff" stroke="#111111" stroke-width="1"/>
<rect x="584.5" y="187.4" width="28" height="8" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="444.5" y="211.4" font-size="10.2" text-anchor="middle" font-weight="normal" fill="#111111">1</text>
<text x="472.5" y="211.4" font-size="10.2" text-anchor="middle" font-weight="normal" fill="#111111">0</text>
<text x="500.5" y="211.4" font-size="10.2" text-anchor="middle" font-weight="normal" fill="#111111">1</text>
<text x="528.5" y="211.4" font-size="10.2" text-anchor="middle" font-weight="normal" fill="#111111">2</text>
<text x="556.5" y="211.4" font-size="10.2" text-anchor="middle" font-weight="normal" fill="#111111">3</text>
<text x="584.5" y="211.4" font-size="10.2" text-anchor="middle" font-weight="normal" fill="#111111">4</text>
<text x="612.5" y="211.4" font-size="10.2" text-anchor="middle" font-weight="normal" fill="#111111">5 m</text>
<text x="195" y="320" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">Original print</text>
<text x="535" y="320" font-size="15" text-anchor="middle" font-weight="bold" fill="#111111">Copy at 70%</text>
<text x="535" y="342" font-size="13" text-anchor="middle" font-weight="normal" fill="#b3261e">written scale now wrong, bar still right</text>
</svg>
</div>

*Figure 4. Left: a sheet at the written scale 1:100 with a scale bar from 0 to 5 m. Right: the same sheet copied at 70%. Everything shrinks, including the scale bar. The written scale still says 1:100, but it is now wrong. The scale bar still measures correctly.*

<div class="figure-art">
<svg viewBox="0 0 680 300" width="100%" role="img" aria-labelledby="rd14-f5-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="rd14-f5-title">Stair landing detail marked NTS, not to scale. The landing is dimensioned 1200 and the opening beside it 3000, but the 3000 part is drawn shorter than the 1200 part. The written dimensions are the sizes to build.</title>
<rect x="0" y="0" width="680" height="300" fill="#ffffff"/>
<rect x="60" y="120" width="300" height="90" fill="#f4f4f4" stroke="#111111" stroke-width="2.6"/>
<rect x="360" y="120" width="200" height="90" fill="none" stroke="#111111" stroke-width="2.6"/>
<text x="210" y="172" font-size="15" text-anchor="middle" font-weight="normal" fill="#777777">LANDING</text>
<text x="460" y="172" font-size="15" text-anchor="middle" font-weight="normal" fill="#777777">OPENING</text>
<line x1="60" y1="116" x2="60" y2="84" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="360" y1="116" x2="360" y2="84" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="60" y1="90" x2="360" y2="90" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="60,90 68.54,87.17 68.54,92.83" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="360,90 351.46,92.83 351.46,87.17" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="210" y="85" font-size="16" text-anchor="middle" font-weight="normal" fill="#111111">1200</text>
<line x1="360" y1="116" x2="360" y2="84" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="560" y1="116" x2="560" y2="84" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<line x1="360" y1="90" x2="560" y2="90" stroke="#111111" stroke-width="1.1" fill="none" stroke-linecap="butt"/>
<polygon points="360,90 368.54,87.17 368.54,92.83" fill="#111111" stroke="#111111" stroke-width="1"/>
<polygon points="560,90 551.46,92.83 551.46,87.17" fill="#111111" stroke="#111111" stroke-width="1"/>
<text x="460" y="85" font-size="16" text-anchor="middle" font-weight="normal" fill="#111111">3000</text>
<text x="310" y="260" font-size="17" text-anchor="middle" font-weight="bold" fill="#111111">DETAIL 4   NTS</text>
<text x="310" y="284" font-size="13" text-anchor="middle" font-weight="normal" fill="#777777">Dimensions in mm</text>
</svg>
</div>

*Figure 5. Detail 4, marked NTS. The landing is dimensioned 1200 and the opening 3000, but the opening is drawn shorter than the landing. Build to the written dimensions.*

## Practice

**Task 1** (level 1)
a) Where on a drawing do you find the scale?
b) What does NTS mean?
c) Can one sheet have more than one scale? Give an example.

**Task 2** (level 1)
a) What does 1/4" = 1'-0" mean in your own words?
b) Which drawing of the same house is bigger on paper: 1/8" = 1'-0" or 1/4" = 1'-0"?
c) Which is bigger on paper: 1:50 or 1:100?

**Task 3** (level 1)
Use Figure 1.
a) Where is the zero on this edge?
b) Which way do the feet numbers count from zero?
c) What is the small section to the right of zero for?

**Task 4** (level 2)
A framer measures a wall on a plan drawn at 1/4" = 1'-0". It is 5 5/8" long on the paper. How long is the real wall? Give your answer in feet and inches.

**Task 5** (level 2)
Find the real size. Give each answer in feet and inches.
a) A stair section at 1/2" = 1'-0". A line measures 5 3/4".
b) A cabinet detail at 3/4" = 1'-0". A line measures 2 1/4".
c) A trim detail at 3" = 1'-0". A line measures 7 1/2".

**Task 6** (level 2)
A drafter is drawing metric details. How long is each line on the paper?
a) A wall section at 1:20. The wall is 1150 mm high.
b) A flashing detail at 1:5. The flashing leg is 140 mm long.
c) A plan at 1:100. A room is 4200 mm long.

**Task 7** (level 2)
a) A site plan is drawn at 1" = 20'. An excavator operator measures a trench route at 3.4". How long is the trench?
b) A metric site plan is at 1:100. A line measures 85 mm. How long is it in millimetres and in metres?

**Task 8** (level 2)
Use Figure 4. A plan is drawn at 1:50 on a large sheet. The office prints a half-size copy for the site. A helper measures a wall on the copy at 30 mm and says, "30 × 50 = 1500 mm."
a) What is the real length?
b) What should the helper have used instead of the written scale?

**Task 9** (level 3)
Use Figure 5. A carpenter lays a ruler on Detail 4 and sees the opening is drawn shorter than the landing. She thinks the 3000 dimension is a typing mistake.
a) What does NTS tell her?
b) Which size should she build to?
c) If she still thinks something is wrong, what should she do?

**Task 10** (level 3)
An electrician needs to place a ceiling light. The 1:50 plan shows the light but gives no dimension to it. The light measures 63 mm from the north wall on the plan.
a) About how far from the wall is the light?
b) Is it OK to scale the drawing here? Explain.
c) What should the electrician do before cutting the hole in the ceiling?

**Task 11** (level 3)
You must draw a deck 4800 mm by 3600 mm in a space on the sheet that is 150 mm by 100 mm.
a) Will it fit at 1:20? Show your work.
b) Will it fit at 1:50? Show your work.
c) A different deck is 16'-0" by 12'-0". Will it fit at 1/4" = 1'-0" in a space 6" by 4"?

_______________________________________________

_______________________________________________

## Check yourself

1. At 1:100, how many millimetres in real life does 1 mm on the paper stand for?
2. At 1/8" = 1'-0", what do you multiply paper inches by to get feet?
3. On an architect's scale, where are the inch marks?
4. Why does a scale bar stay right on a reduced copy when the written scale does not?
5. A dimension is written on the drawing, but your scaled measurement is different. Which do you use?
