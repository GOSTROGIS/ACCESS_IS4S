---
title: Symbols, legends, grids and schedules
summary: Use grid lines, markers, tags, schedules and each trade's legend to look up what a symbol on a real sheet means, then follow it to the right table.
level: 1-3
time: 90 min
components: Identify the information, Make connections between different parts of the document(s), Understand and apply the information, Evaluate the document(s)
---

# Symbols, legends, grids and schedules

## Why this matters on the job

A drawing is mostly symbols. A small circle with "C / A-502" in it sends you to another sheet. An oval with "119" in it is a door you will hang. A circle with two lines is a receptacle an electrician will rough in. None of these make sense until you look them up. Every set has a **legend** for its symbols and a list of its **abbreviations**, and they are not the same from job to job. Good tradespeople do not memorize every symbol. They know where to look it up.

This lesson uses real sheets from the same three sets as lesson 16: **London Square** (imperial teaching set), **leləm̓ Community Centre** (metric, 2022) and, through lesson 16, **Fire Hall No. 3** (1999).

## Key ideas

**1. The legend is the dictionary for that set.** Look for sheets with names like "Legends", "Symbols" or "Abbreviations", often the first sheet of each trade. In this lesson:
- London Square A-100 has a drawing symbols legend and an abbreviation legend for the architectural sheets.
- leləm̓ E-001 is the electrical symbol legend. M0.01 holds the mechanical legends: pipes, valves, plumbing, ducts, fire protection and abbreviations.
- leləm̓ S200 has a small structural legend. S101 has the structural abbreviations.
- Floor plans often have a small legend of their own, such as the fire rating legend on leləm̓ A-201.

**2. Grid lines and grid bubbles.** Long thin lines with a bubble at the end are **grid lines**. They run through the columns and main walls. One direction is numbered (1, 2, 3...) and the other is lettered (A, B, C...). Crews use them to say where something is: "the door near grid C-2". Dimension strings measure between grid lines, so grids are where layout starts.

**3. North arrow.** A north arrow shows which way north is on the sheet. Some sets show **true north** (on the earth) and **project north** (a direction picked to keep the drawing square on the page).

**4. Markers that send you to another sheet.** A circle split by a line holds two numbers: the **view number** on top and the **sheet number** below. So "C over A-502" means view C on sheet A-502.
- A **section marker** sits at the end of a cut line. The solid triangle or arrow points the way you are looking.
- A **wall section marker** works the same way, for a cut through one wall.
- An **elevation marker** points at a wall to show which way the elevation looks.
- A **detail callout** circles a small area and sends you to a bigger drawing of it.

**5. Tags point to schedules.** A tag is a small shape with a mark in it.
- **Room tag:** room number (and often the name).
- **Door tag:** door mark. Look it up in the door schedule.
- **Wall tag:** wall type. Look it up in the wall assembly schedule.
- **Window tag:** window type. Look it up in the window schedule.
- **Equipment or fixture tag:** for example WC-1 or EF-1. Look it up in that trade's schedule.

The shape of each tag is set in the legend. It changes from office to office.

**6. Schedules are tables.** A schedule lists every item of one kind with its size, type and material. A **door schedule** lists each door mark. A **room finish schedule** lists each room's floor, base, wall and ceiling finish. A **footing schedule** lists footing sizes and rebar. A **panel schedule** lists each electrical circuit and its breaker. The tag on the plan is the key that opens the right row.

**7. Trade symbols.** Electrical plans use symbols for receptacles, switches and lights, plus a circuit label such as **2A:24** (panel 2A, circuit 24). Plumbing plans use fixture tags and line types for each kind of pipe. HVAC plans show ducts with their size and what air they carry. Structural plans use footing, column and wall marks.

**8. Abbreviations change meaning.** The same letters can mean different things in different trades, or even on the same sheet. Always read the abbreviation list for the trade you are working from. If something in the legend looks wrong, ask.

### Worked example

**Question:** On leləm̓ A-201, what does the marker labelled **B** in Figure 3 mean, and where do you go next?

1. Look at the marker: a circle split by a line, with **C** on top and **A-502** below, and a solid black triangle behind the circle. The triangle points up the sheet, the way you look at the cut.
2. The London Square legend (Figure 1) shows this kind of marker for building sections and wall sections. The leləm̓ set uses the same idea. The top is the view, the bottom is the sheet.
3. In the leləm̓ drawing list (lesson 16, Figure 2), A-502 is "Building sections".
4. **Answer: it is building section C, drawn on sheet A-502.** Go to A-502 and find the view titled C.

## Practice documents

Tap a figure to open it full size, then zoom in.

<figure class="figure-art" tabindex="0" aria-label="Figure 1, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/ls-a100-symbols-legend.png"><img src="figures/ls-a100-symbols-legend.png" alt="The London Square drawing symbols legend. North arrow marked true/project north. Drawing title with a circled number and Scale 1:100. Building section and wall section marker: a split circle with 1 over A101 and a triangle. Room tag: room name over 101 in a box. Floor or construction elevation: a half-black circle with name and elevation. Door tag: 101 in a rounded shape. Wall tag: 1i in a rectangle. Window tag: 1t in a hexagon. Floor and roof tag: 1t in an upside-down triangle. Ceiling tag with height: 1i, 1&#x27;-0&quot; A.F.F. Stair tag: 20 R at 7 1/2 inches, 19 T at 11 inches. Revision tag: 1 in a triangle. Elevation view tag: a diamond with A101 in the middle and 1 on each side. Material tag: a diamond with a question mark. Key note tag: K in a square." width="540" height="999" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 1.</strong> London Square, sheet A-100 Cover sheet and code review, drawing symbols legend. Athena Architecture Ltd. (fictional).</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 2, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/ls-a100-abbreviations.png"><img src="figures/ls-a100-abbreviations.png" alt="The London Square abbreviation legend, three columns from Centerline to Wood. It includes A.F.F. listed with the meaning Finished Face, F D. Floor Drain, N.I.C. Not in Contract, N.T.S. Not to Scale, O.C. On Centre, T.O. Top of and TYP. Typical." width="860" height="810" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 2.</strong> London Square, sheet A-100 Cover sheet and code review, abbreviation legend. Athena Architecture Ltd. (fictional).</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 3, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-a201-grids-and-tags.png"><img src="figures/lelem-a201-grids-and-tags.png" alt="Part of the leləm̓ Level 1 floor plan at the gym, with red letters added. A points to grid bubble 3. B points to a section marker reading C over A-502. C points to a marker reading 1 over A-621. D points to a marker reading 06 over A-702. E points to the dimension 19500 between grids 1 and 4. F points to a diamond tag PS12. G points to the room tag 110C under the words GYM. STORAGE. H points to the oval door tag 119. J points to a half-black circle symbol with 98520. K points to a green dashed line along the wall of the gym storage." width="860" height="846" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 3.</strong> leləm̓ Community Centre, sheet A-201 Floor plan Level 1, gym and gym storage. Red letters A to K were added for this lesson. Francl Architecture.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 4, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-a201-legend-notes.png"><img src="figures/lelem-a201-legend-notes.png" alt="The fire rating legend on leləm̓ A-201: a blue dashed line for 0 min, a yellow dashed line for 45 min and a green dash-dot line for 60 min, see code report for full requirements. Floor plan legend and general notes: 1. Floor plan is cut at 1200mm above finished floor. 2. Refer to wall assembly schedule on sheets A-010 and A-011. 3. Unless noted otherwise all interior partitions are type PS11. 4. Refer to room finish schedule and interior elevations for all interior finishes." width="730" height="719" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 4.</strong> leləm̓ Community Centre, sheet A-201 Floor plan Level 1, fire rating legend and floor plan notes. Francl Architecture.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 5, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-a081-door-schedule.png"><img src="figures/lelem-a081-door-schedule.png" alt="Part of the leləm̓ door schedule, Level 1 doors 102 to 120. Columns: level, door description, mark, from room number and name, to room number and name, width x height, thickness, type, material, finish. Doors 118, 119 and 120 are each Flush - Double, from 110C Gym. Storage to 110 Gym, 1828 x 2450, 44 thick, type D, maple veneer, clear finish." width="860" height="379" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 5.</strong> leləm̓ Community Centre, sheet A-081 Door schedule, first columns and Level 1 rows. Francl Architecture.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 6, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-a090-room-finish-schedule.png"><img src="figures/lelem-a090-room-finish-schedule.png" alt="The leləm̓ room finish schedule, 41 rooms. Columns: level, number, name, floor finish, ceiling finish, base finish, wall finish. For example 110 Gym: maple hardwood sport floor, acoustical DLT decking, vented cove base, GWB star. 110C Gym. Storage: rubber sheet, exposed NLT, wood, GWB star. 114 Catering Kitchen: marmoleum, GWB, tile, GWB star, tile double star. Notes below: one star means gypsum wall board to be abuse resistant. Two stars means tile up to 7&#x27;-0&quot; high." width="860" height="695" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 6.</strong> leləm̓ Community Centre, sheet A-090 Room finish schedule with its general notes. Francl Architecture.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 7, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-e001-power-legend.png"><img src="figures/lelem-e001-power-legend.png" alt="Part of the leləm̓ electrical symbol legend, Power and Distribution. Junction boxes, 15A 120V single receptacle, 15A 120V duplex receptacle, 15A 120V above counter duplex receptacle, OC GFI duplex receptacle, 20A 120V T-slot GFI duplex receptacle, USB duplex receptacle, computer duplex receptacle, 4-plex receptacles, special receptacle, direct connection, a square around a device means floor mounted, a circle around a device means ceiling mounted." width="718" height="1000" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 7.</strong> leləm̓ Community Centre, sheet E-001 Electrical symbol legend, power and distribution. DIALOG.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 8, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-e001-switching-legend.png"><img src="figures/lelem-e001-switching-legend.png" alt="The leləm̓ switching legend. An S-shaped symbol is a single pole switch. With a 2 it is double pole, with 3 a 3-way switch, with 4 a 4-way switch, with PL a pilot light, with T a timer, with D a dimmer, with K a key switch. OS in a circle with VS is a ceiling mounted line voltage occupancy sensor in vacancy sensor mode. DL in a circle is a daylight sensor." width="673" height="1000" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 8.</strong> leləm̓ Community Centre, sheet E-001 Electrical symbol legend, switching. DIALOG.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 9, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-e001-abbreviations.png"><img src="figures/lelem-e001-abbreviations.png" alt="The leləm̓ electrical abbreviations. A.F.F. Above Finished Floor. GFI Ground Fault Interupter (spelled this way on the sheet). OC Over Counter. WP Weather Proof. Also a revision symbol, a triangle with a number, meaning revision number." width="520" height="1000" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 9.</strong> leləm̓ Community Centre, sheet E-001 Electrical symbol legend, miscellaneous and abbreviations. DIALOG.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 10, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-e300-catering-kitchen.png"><img src="figures/lelem-e300-catering-kitchen.png" alt="Part of the leləm̓ Level 1 power plan at the catering kitchen, room 114. Receptacle symbols along the counters carry circuit labels such as 2A:48, 2A:15, MW 2A:9, FR 2A:24, 2A:25, 2A:8, 2A:4, 2A:29 and VENT STOVE 2A:2 and 2A:16,18. Two mechanical equipment tags read FC-1-4 and FC-1-3, 2M: 43,45." width="750" height="666" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 10.</strong> leləm̓ Community Centre, sheet E-300 Level 1 power plan (scale 1 : 100), catering kitchen 114. DIALOG.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 11, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-e901-panel-2a.png"><img src="figures/lelem-e901-panel-2a.png" alt="The top of the leləm̓ panel schedule for panel 2A: location 2nd floor elec, supply from MDP, voltage 120/208 Wye, 3 phases, 4 wires, 72 circuits, MCB 400. Rows list circuit number, type, description and breaker size. Circuit 9 is REC. Kitchen 114 Microwave, 20 A. Circuit 24 is REC. Kitchen Fridge, 15 A. Circuits 16 and 18 share a 40 A breaker for KCH. Kitchen Ind. Oven." width="860" height="363" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 11.</strong> leləm̓ Community Centre, sheet E-901 Panel schedules, panel 2A, circuits 1 to 52. DIALOG.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 12, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-m001-plumbing-fire-legend.png"><img src="figures/lelem-m001-plumbing-fire-legend.png" alt="Two leləm̓ mechanical legends side by side. Plumbing and Piping: FCO floor cleanout, CO cleanout, BCO building cleanout, floor drain, funnel floor drain, area drain, roof drain, hose bibb, a box WC-X meaning plumbing fixture or equipment tag, backwater valve, meter, vent through roof, heat trace, and coloured line types SAN sanitary sewer, V sanitary vent, ST storm sewer, DCW domestic water cold, DHW domestic water hot, DHWR hot recirculation, T tempered water. Fire Protection: SP (WET) and SP (DRY) sprinkler piping, F (WET) and F (DRY) fire main, sprinkler head symbols, FHC fire hose cabinet, FVC fire valve cabinet, FEX fire extinguisher, fire department connection, fire hydrant, valves and switches." width="860" height="632" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 12.</strong> leləm̓ Community Centre, sheet M0.01 Mechanical legends and drawing list, plumbing and piping and fire protection. DIALOG.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 13, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-m001-air-distribution.png"><img src="figures/lelem-m001-air-distribution.png" alt="The leləm̓ air distribution legend. Duct dimensioning is the clear inside duct size. S/A 600X300 supply air duct, R/A return air, E/A exhaust air, O/A outside air, T/A transfer air, KE/A kitchen exhaust. Round duct 600ø. Rectangular duct where the first dimension is the visible dimension. A hexagon FD on a duct is a fire damper, SD a smoke damper, MD a motorized damper, BD a balancing damper. Air outlet tag: type S-1, size 200ø, flow 100 L/s." width="463" height="999" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 13.</strong> leləm̓ Community Centre, sheet M0.01 Mechanical legends and drawing list, air distribution. DIALOG.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 14, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-m001-abbreviations.png"><img src="figures/lelem-m001-abbreviations.png" alt="The leləm̓ mechanical abbreviations from AC Air Conditioner to WR Washroom. Among them AFF Above Finished Floor, DN Down, FD Floor Drain, FFD Funnel Floor Drain, LAV Lavatory, UR Urinal and WC Water Closet." width="860" height="823" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 14.</strong> leləm̓ Community Centre, sheet M0.01 Mechanical legends and drawing list, abbreviations (one long list, set in two columns to fit the page). DIALOG.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 15, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/ls-p1-plumbing-legend.png"><img src="figures/ls-p1-plumbing-legend.png" alt="Part of the London Square plumbing legend. Symbol and description: floor drain FD, funnel floor drain FFD, catch basin CB, roof drain RD, planter drain PD, deck drain DD, hose bibb HB, P-trap, elbow down, elbow up, cleanout C.O., WC water closet, WB wash basin, KS kitchen sink, DW dish washer, BT bath tub, CW cloth washer, SH shower." width="772" height="999" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 15.</strong> London Square, sheet P-1 Site plan, plumbing legend (heading and fixture rows). Oslo Mechanical for Athena Architecture Ltd. (both fictional).</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 16, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-s200-legend.png"><img src="figures/lelem-s200-legend.png" alt="The leləm̓ structural legend on S200: concrete wall type W1 see wall schedule and plan, concrete wall below, NLT/DLT panel, beam or header, footing type F1 in a hexagon see plan and schedule, column type C1, base plate type BP1, steel brace frame type BF in an oval, zone reinforcing type Z1, embed plate type EP1, and factored axial force in kN." width="602" height="817" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 16.</strong> leləm̓ Community Centre, sheet S200 Foundation and L1 (lower) plan, legend. Fast + Epp Structural Engineers.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 17, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-s102-footing-schedule.png"><img src="figures/lelem-s102-footing-schedule.png" alt="The leləm̓ footing schedule. F1 450x250 DP. strip FTG., R/W 3-15M CONT. F2 1700x1700x350 DP. pad FTG., R/W 20M @300 E.W. BOT. F3 800x800x300 DP. pad FTG., R/W 20M @300 E.W. BOT. F4 to F10 are strip and pad footings with more rebar. Notes: footings bear on sandy soils as stated in the geotechnical report, see TYP-C-309/S302 for retaining wall footings F6 and F7, see S500 for shear wall footings F8 and F9." width="820" height="715" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 17.</strong> leləm̓ Community Centre, sheet S102 Structural schedules, footing schedule. Fast + Epp Structural Engineers.</figcaption></figure>

<figure class="figure-art" tabindex="0" aria-label="Figure 18, scroll sideways on a small screen" style="margin:16px 0"><a href="figures/lelem-s101-abbreviations.png"><img src="figures/lelem-s101-abbreviations.png" alt="The leləm̓ structural abbreviations from A.BOLTS anchor bolts to WP. work point. Among them BOT. bottom, C/W complete with, CONT. continuous, DP. deep, E.W. each way, FTG. footing, R/W reinforced with, T &amp; B top and bottom, TYP. typical, U.N.O. unless noted otherwise and WP. work point." width="860" height="958" loading="lazy" style="max-width:100%;height:auto;border:1px solid #cfc8c0;background:#fff"></a><figcaption><strong>Figure 18.</strong> leləm̓ Community Centre, sheet S101 General notes, abbreviations. Fast + Epp Structural Engineers.</figcaption></figure>

## Practice

**Task 1** (level 1)
Use Figure 1 (London Square symbols legend).
a) What shape is a door tag? A wall tag? A window tag?
b) What does a number in a triangle mean?
c) The north arrow is marked with two kinds of north. What are they?
d) A stair tag reads "20 R @ 7 1/2" and 19 T @ 11"". What do you think R and T stand for? (Lesson 16 in Numeracy covers stairs.)

**Task 2** (level 1)
Use Figure 3 (leləm̓ A-201, letters A to K) and Figure 4. Write what each lettered item is. For markers, say which sheet it sends you to.

| Letter | What it is | Sheet or schedule it sends you to |
|---|---|---|
| A | | |
| B | | |
| C | | |
| D | | |
| E | | |
| F | | |
| G | | |
| H | | |
| J | | |
| K | | |

**Task 3** (level 2)
Use Figure 3.
a) The dimensions between grids 4, 3, 2 and 1 are 1850, 15800 and 1850. Add them. Does your total match the overall dimension?
b) How far apart are grid 3 and grid 2, in metres?
c) The floor near the stairs at the top of the crop is marked 99520. The gym floor is marked 98520. What is the difference, and which floor is higher?

**Task 4** (level 2)
Use Figures 3 and 5. You are a carpenter hanging door 119.
a) Which room does it go from, and to?
b) What is its size (width x height) and its thickness?
c) What is the door material and finish, and what type is it?
d) How many doors in the schedule go from 110C Gym. Storage into 110 Gym? List their marks.

**Task 5** (level 2)
Use Figure 6 (room finish schedule).
a) What are the floor, base, wall and ceiling finishes in 110C Gym. Storage?
b) What does the star (*) after GWB mean? What do the letters GWB stand for?
c) The wall finish in 114 Catering Kitchen ends with two stars (**). What does that note say? Give the height in millimetres (1 inch = 25.4 mm).

**Task 6** (level 2)
Use Figures 10 and 11. You are an electrician working in the catering kitchen.
a) The receptacle marked MW is on circuit 2A:9. What does the panel schedule say circuit 9 feeds, and what size is its breaker?
b) The receptacle marked FR is on 2A:24. What does circuit 24 feed, and what size breaker?
c) The stove is on 2A:16,18. Why does it have two circuit numbers? What breaker feeds it?
d) Where is panel 2A, and what voltage is it?

**Task 7** (level 2)
Use Figures 7, 8 and 9 (electrical legend).
a) What does a circle drawn around a device mean? A square?
b) What does "OC" mean in "OC GFI duplex receptacle"? Use the abbreviations.
c) What switch has the symbol with a 3 beside it? With a D?
d) What does "OS" with "VS" mean on a ceiling?

**Task 8** (level 2)
Use Figures 12, 13 and 14 (leləm̓ mechanical legends). You are a plumber and a sheet metal worker on the same job.
a) A box with "WC-X" in it. What kind of tag is that?
b) What is FCO? What line type label marks domestic cold water?
c) A duct is labelled "S/A 600X300". What air does it carry, and what do the numbers mean?
d) An air outlet tag reads S-1, 200ø, 100. What do the three lines tell you?
e) What do FHC and FEX mean in the fire protection legend?

**Task 9** (level 2)
Use Figures 16, 17 and 18 (structural). You are a concrete finisher's helper reading the footing schedule.
a) What does a footing mark like F1 look like on the plan, according to the legend?
b) Write footing F2 out in plain words. Use the abbreviations list for DP., FTG., R/W, E.W. and BOT.
c) Which sheet do you go to for the retaining wall footing detail for F6 and F7?

**Task 10** (level 2)
Use Figure 15 (London Square plumbing legend).
a) What do WC and WB stand for on the London Square plumbing sheets?
b) What do the letters FD stand for?

**Task 11** (level 3)
"FD" and "WP" show up in more than one place.
a) In Figure 14, what does FD stand for? In Figure 13, what does FD in a hexagon on a duct mean?
b) In Figure 9 (electrical), what does WP mean? In Figure 18 (structural), what does WP. mean?
c) Write one rule for reading abbreviations that would keep a crew out of trouble.

_______________________________________________

**Task 12** (level 3)
Look at A.F.F. in Figure 2 (London Square architectural abbreviations), and at A.F.F. or AFF in Figure 9 and Figure 14 (leləm̓).
a) What does each legend say A.F.F. means?
b) Which one looks wrong, and how do you know? (Hint: look at the ceiling tag in Figure 1.)
c) What would you do on a London Square job if a note said "outlet at 18" A.F.F."?

_______________________________________________

_______________________________________________

**Task 13** (level 3)
Put Figures 3, 5 and 6 together. You are setting the floor transition at door 119.
a) What floor finish is on each side of the door?
b) Why does that matter to the carpenter and the flooring installer?
c) Which three documents did you use, and what key (tag or mark) linked them?

_______________________________________________

_______________________________________________

## Check yourself

1. Where do you look first when you do not know what a symbol means?
2. On a section marker, what is the top number and what is the bottom number?
3. What do grid lines help a crew do?
4. Name three kinds of tags and the schedule each one points to.
5. Why can you not assume an abbreviation means the same thing on every job?
