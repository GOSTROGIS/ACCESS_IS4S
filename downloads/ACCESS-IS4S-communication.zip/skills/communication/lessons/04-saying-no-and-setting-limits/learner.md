---
title: Saying no and setting limits at work
summary: Say no clearly without over-explaining, offer an alternative when you want to, and refuse unsafe work the way BC law sets out.
level: 2-3
time: 70 min
components: Speak with clarity; Speak with purpose; Adapt to your audience and contexts
rebuilds: A - Oral Communication/Saying No-rb.docx
---

# Saying no and setting limits at work

## Why this matters on the job

Work brings a steady stream of requests: stay late, cover a shift, lend your truck, help a friend of the boss move, do a task you have never been shown. Saying yes to everything wears you out and can put you in danger. Saying no well protects your time, your safety and your working relationships. In BC, refusing unsafe work is also a legal duty, and there is a set way to do it.

## Key ideas

**You can say no.** Being assertive does not mean refusing everything. It means you can weigh your own needs and say no when you decide to.

**Three ways to say no.**

| Way | Example | What often happens |
|---|---|---|
| A flat no, no reason | "No, I can't." | Clear and quick. Can feel abrupt in some situations. Fine for many simple requests. |
| Over-explaining | "Oh, I'd really like to, but my cousin might need the truck, and I think it's making a noise, and I'm not sure about the insurance, and ..." | Sounds unsure. The other person argues with each excuse. You often end up feeling guilty or saying yes. |
| Assertive no | "No, I'm not able to stay tonight." Add a short reason only if you want to. | Clear and respectful. The other person knows where you stand. |

**Keep it short.** One sentence, maybe one short reason. Use a steady voice. Say "no" or "I'm not able to," not "I don't know, maybe."

**Offer an alternative if you want to.** "I can't stay tonight, but I can come in an hour early tomorrow." You do not have to offer one.

**Notice what stops you.** Many people hear an inner voice: "They'll think I'm lazy." "I'll lose the job." "It's rude to say no to someone older or to the boss." Ask: what is the worst that could realistically happen? How would I feel if someone said no to me in the same situation?

**Norms differ.** Families, communities and workplaces have different ideas about when it is acceptable to say no and to whom. You decide what fits you and the situation.

**Refusing unsafe work is different.** It is not a favour you can turn down. Under BC's Occupational Health and Safety Regulation, section 3.12, if you have reasonable cause to believe a task, tool or piece of equipment would create an undue hazard to anyone's health and safety, you must not do it. You must report it to your supervisor or employer right away.

How it works, in three steps:

1. **Stop and report.** Stop the work and tell your supervisor or employer. Say clearly that you are refusing the work as unsafe, not only that something looks risky. Your supervisor or employer must investigate and fix the problem, or tell you if they do not agree that it is unsafe.
2. **If you still do not agree,** your supervisor or employer investigates again with you and a worker member of the joint health and safety committee, a union representative, or another worker you choose.
3. **If it is still not resolved,** both you and your supervisor or employer must contact WorkSafeBC. A prevention officer investigates. The Prevention Information Line is 604.276.3100, or toll-free 1.888.621.7233.

You must not be disciplined or penalized for following these steps. Your employer may move you to other work for a while, at no loss in pay. Your employer also may not give the refused task to another worker unless the matter is resolved or that worker is told in writing about the refusal, the hazard, why the employer thinks it is safe, and their own right to refuse.

The same three steps as a flow chart:

<div class="figure-art">
<svg viewBox="0 0 640 576" width="100%" role="img" aria-labelledby="m04-refuse-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="m04-refuse-title">Flow chart of refusing unsafe work under BC OHS Regulation section 3.12: stop and report, the supervisor investigates, a second investigation with a worker representative, then WorkSafeBC.</title>
<defs><marker id="m04-refuse-ah" viewBox="0 0 10 10" refX="9" refY="5" markerUnits="userSpaceOnUse" markerWidth="13" markerHeight="13" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#2b2b2b"/></marker></defs>
<rect x="0" y="0" width="640" height="576" fill="#ffffff"/>
<rect x="60" y="20" width="520" height="96" rx="8" fill="#fbe6e4" stroke="#1f3a5f" stroke-width="2"/>
<text x="320" y="52.7" font-size="17" text-anchor="middle" font-weight="bold" fill="#2b2b2b">1 Stop and report</text>
<text x="320" y="73.95" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">Tell your supervisor or employer</text>
<text x="320" y="95.2" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">you refuse the work as unsafe.</text>
<line x1="320" y1="118" x2="320" y2="146" stroke="#2b2b2b" stroke-width="2.5" marker-end="url(#m04-refuse-ah)"/>
<rect x="60" y="150" width="520" height="70" rx="8" fill="#eaf1f8" stroke="#1f3a5f" stroke-width="2"/>
<text x="320" y="180.325" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">They investigate and fix it, or tell</text>
<text x="320" y="201.575" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">you why they think it is safe.</text>
<line x1="320" y1="222" x2="320" y2="250" stroke="#2b2b2b" stroke-width="2.5" marker-end="url(#m04-refuse-ah)"/>
<rect x="60" y="254" width="520" height="118" rx="8" fill="#fdf1d8" stroke="#c98a12" stroke-width="2"/>
<text x="320" y="287.075" font-size="17" text-anchor="middle" font-weight="bold" fill="#2b2b2b">2 Still not agreed?</text>
<text x="320" y="308.325" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">Investigate again with you and a</text>
<text x="320" y="329.575" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">JHSC worker member, union rep or</text>
<text x="320" y="350.825" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">a worker you choose.</text>
<line x1="320" y1="374" x2="320" y2="402" stroke="#2b2b2b" stroke-width="2.5" marker-end="url(#m04-refuse-ah)"/>
<rect x="60" y="406" width="520" height="118" rx="8" fill="#fdf1d8" stroke="#c98a12" stroke-width="2"/>
<text x="320" y="439.075" font-size="17" text-anchor="middle" font-weight="bold" fill="#2b2b2b">3 Still not resolved?</text>
<text x="320" y="460.325" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">You and your supervisor or employer</text>
<text x="320" y="481.575" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">must contact WorkSafeBC.</text>
<text x="320" y="502.825" font-size="17" text-anchor="middle" font-weight="normal" fill="#2b2b2b">A prevention officer investigates.</text>
<text x="320" y="556" font-size="17" text-anchor="middle" font-weight="bold" fill="#2a7f62">No discipline for following these steps.</text>
</svg>
</div>

### Worked example

Rae, the foreman at Clearwater Roofing (a fictional company), asks you on Friday at 3:30: "Can you stay till eight tonight? We're behind."

Over-explaining: "Uh, I'd like to, but I kind of have this thing, my sister might need a ride, and I'm pretty tired, and I didn't bring dinner..."

Assertive no: "I'm not able to stay tonight. I can come in at six tomorrow if that helps."

Rae can plan around a clear answer. She cannot plan around "kind of."

## Practice

**Task 1** (level 1) **Three rounds.** Think of a request that is hard for you to turn down. It can be from work or from your life. Tell your partner the situation. Your partner makes the request three times:

- Round 1: say no with no explanation.
- Round 2: say no with as many excuses as you can.
- Round 3: say no assertively, with a short reason if you want one.

Switch roles. After all three rounds, answer:

Which round felt best to you? Why?

______________________________________________

What was your partner's reaction in round 2?

______________________________________________

**Task 2** (level 2) **Cut the excuses.** Rewrite this answer as an assertive no in one or two sentences.

> Co-worker: "Can I borrow your impact driver for the weekend?"
>
> You: "Oh man, I don't know, I mean, I might need it, my uncle was talking about building a deck, but maybe not, and the battery's kind of weak, and last time someone borrowed it they dropped it, not that you would, but..."

______________________________________________

**Task 3** (level 2) **No, plus an alternative.** Write an assertive no for each request. Add an alternative to at least two.

1. Your lead hand asks you to cover a Sunday shift. You have family plans.

______________________________________________

2. A co-worker asks to borrow $100 until payday.

______________________________________________

3. Your supervisor asks you to help clean the site trailer during your lunch break.

______________________________________________

**Task 4** (level 2) **Refuse unsafe work.** Read the situation and answer the questions.

> You are an apprentice at Harbourline Fabrication (a fictional company). The guard on an angle grinder is stopping it from fitting into a tight corner. The lead hand says, "Just take the guard off for this one cut. It'll take two seconds."

a) You believe this would create an undue hazard. What exactly do you say to the lead hand?

______________________________________________

b) The lead hand checks and says it is fine. You still believe it is unsafe. What happens next?

______________________________________________

c) If the matter is still not resolved after that, who must contact WorkSafeBC?

______________________________________________

d) Can you be disciplined for refusing?

______________________________________________

**Task 5** (level 1) **What stops me?** Write one thought that makes it hard for you to say no. Then write a more realistic way to look at it.

Thought: ______________________________________________

A more realistic way to look at it: ______________________________________________

**Task 6** (level 2) **Put the steps in order.** Number these from 1 to 4.

____ You and your supervisor contact WorkSafeBC, and a prevention officer investigates.

____ You stop and tell your supervisor you refuse the work as unsafe.

____ Your supervisor investigates again, with you and a worker you choose.

____ Your supervisor investigates and either fixes the problem or tells you why they think it is safe.

**Task 7** (level 3) **The trench.** You work for a fictional excavation company. The foreman says, "Hop in that trench and grab the tape measure. Two minutes." The walls are wet and bits of soil keep falling in. There is no shoring.

a) Write what you say to refuse. Use the words that start the refusal process.

______________________________________________

b) The foreman says, "It's fine. I'll get Sam to do it, then." What does the lesson say about giving refused work to another worker?

______________________________________________

c) The foreman still disagrees after looking again. What happens next?

______________________________________________

## Check yourself

1. What are the three ways to say no? Which one is assertive?
2. Why does over-explaining often backfire?
3. Under section 3.12 of the BC OHS Regulation, what must you do if you have reasonable cause to believe a task would create an undue hazard?
4. When you refuse unsafe work, why should you say clearly that you are refusing, and not only that something looks risky?
5. While a refusal is being sorted out, can your employer move you to other work? What about your pay?
