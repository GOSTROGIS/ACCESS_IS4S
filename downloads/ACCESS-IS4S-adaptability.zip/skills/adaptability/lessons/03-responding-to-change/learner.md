---
title: Responding to change on a project
summary: Read a change notice, sort what changed from what stayed the same, and rebuild your plan for the day.
level: 1-2
time: 75 min
components: Persist and persevere; Set or adjust your goals and expectations; Plan and prioritize
rebuilds: A - Writing/A - Thinking Skills/Responding to Change-rb.docx; A - Coninuous Learning/Lesson Plan 2 Personal Accountability & responding to change.docx
---

# Responding to change on a project

All people, companies and projects in this lesson are fictional.

## Why this matters on the job

No construction project goes exactly to plan. Drawings get revised, deliveries come late, rain moves a pour and crew members change. The workers who do well are not the ones who never get thrown off. They are the ones who find out what changed, keep the parts of the plan that still work, and get back to productive work quickly.

## Key ideas

### Expected and unexpected change

Some changes you can see coming: a rain forecast, a drawing with a new revision letter, a holiday week. Others hit without warning: a broken pump, a sick foreman, a wrong delivery. You can get ahead of expected change by checking the forecast, the schedule and the revision block on your drawings each day.

### Five steps when something changes

1. **Notice.** Read or hear the whole change. Check that it is the latest version.
2. **Sort.** Make three lists: what changed, what stays the same, what you still do not know.
3. **Ask.** Get answers to the "do not know" list from the right person.
4. **Adjust.** Rebuild your plan. Keep everything that still works.
5. **Check.** At the end, confirm the new plan did what it needed to.

<div class="figure-art">
<svg viewBox="0 0 720 300" width="100%" role="img" aria-labelledby="ad03-f1-title" xmlns="http://www.w3.org/2000/svg" font-family="Arial, Helvetica, sans-serif">
<title id="ad03-f1-title">Flow of five boxes: notice, sort, ask, adjust, check, with an arrow from check back to notice.</title>
<defs><marker id="ad03-f1-ar" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="#222222"/></marker><marker id="ad03-f1-ds" viewBox="0 0 10 10" refX="10" refY="5" markerWidth="8" markerHeight="8" orient="auto-start-reverse"><path d="M0,1.5 L10,5 L0,8.5 z" fill="#222222"/></marker></defs>
<rect x="0" y="0" width="720" height="300" fill="#ffffff"/>
<text x="360.0" y="34.0" font-size="22" text-anchor="middle" font-weight="bold" fill="#222222">Five steps when something changes</text>
<rect x="16.0" y="70.0" width="122.0" height="120.0" rx="8" fill="#d6e4f2" stroke="#2f5d8a" stroke-width="2"/>
<text x="77.0" y="116.1" font-size="16" text-anchor="middle" font-weight="bold" fill="#222222">1 Notice</text>
<text x="77.0" y="135.6" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">whole change,</text>
<text x="77.0" y="155.1" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">latest version</text>
<line x1="140.0" y1="130.0" x2="156.0" y2="130.0" stroke="#222222" stroke-width="2.5" marker-end="url(#ad03-f1-ar)"/>
<rect x="158.0" y="70.0" width="122.0" height="120.0" rx="8" fill="#fbe3c8" stroke="#b85c00" stroke-width="2"/>
<text x="219.0" y="116.1" font-size="16" text-anchor="middle" font-weight="bold" fill="#222222">2 Sort</text>
<text x="219.0" y="135.6" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">changed, same,</text>
<text x="219.0" y="155.1" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">don't know</text>
<line x1="282.0" y1="130.0" x2="298.0" y2="130.0" stroke="#222222" stroke-width="2.5" marker-end="url(#ad03-f1-ar)"/>
<rect x="300.0" y="70.0" width="122.0" height="120.0" rx="8" fill="#d8ecd5" stroke="#2e6b34" stroke-width="2"/>
<text x="361.0" y="116.1" font-size="16" text-anchor="middle" font-weight="bold" fill="#222222">3 Ask</text>
<text x="361.0" y="135.6" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">the right</text>
<text x="361.0" y="155.1" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">person</text>
<line x1="424.0" y1="130.0" x2="440.0" y2="130.0" stroke="#222222" stroke-width="2.5" marker-end="url(#ad03-f1-ar)"/>
<rect x="442.0" y="70.0" width="122.0" height="120.0" rx="8" fill="#e4dcf2" stroke="#5b3f8c" stroke-width="2"/>
<text x="503.0" y="116.1" font-size="16" text-anchor="middle" font-weight="bold" fill="#222222">4 Adjust</text>
<text x="503.0" y="135.6" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">keep what</text>
<text x="503.0" y="155.1" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">still works</text>
<line x1="566.0" y1="130.0" x2="582.0" y2="130.0" stroke="#222222" stroke-width="2.5" marker-end="url(#ad03-f1-ar)"/>
<rect x="584.0" y="70.0" width="122.0" height="120.0" rx="8" fill="#f4f1ea" stroke="#222222" stroke-width="2"/>
<text x="645.0" y="116.1" font-size="16" text-anchor="middle" font-weight="bold" fill="#222222">5 Check</text>
<text x="645.0" y="135.6" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">did the plan</text>
<text x="645.0" y="155.1" font-size="16" text-anchor="middle" font-weight="normal" fill="#222222">work?</text>
<path d="M645.0,192 L645.0,245 L77.0,245 L77.0,198" stroke="#222222" stroke-width="2" fill="none" marker-end="url(#ad03-f1-ar)"/>
<text x="360.0" y="270.0" font-size="16" text-anchor="middle" font-weight="normal" fill="#6b6b6b">If the check finds a problem, start again with what you notice.</text>
</svg>
</div>

### Keep trying, or change the approach?

Ask yourself:

- Is it safe? If not, stop and report it. Never "keep trying" at something unsafe.
- Is the same method failing again and again? Try a different method or ask for help.
- Am I still making progress, even slowly? Keep going.
- Is the problem outside my control (weather, a crane down)? Switch to a task you can do and tell your supervisor.

### Steady anchors

When a lot is changing, it helps to know what stays steady. The writer Alvin Toffler called these "personal stability zones": the people, places, routines and beliefs that stay the same while other parts of life change. A morning routine, a family call every Sunday or a weekly hockey game can all be anchors. The ACCESS lesson this page replaces put it this way: we need both roots and wings.

### Worked example: a plumbing crew's change memo

This memo is for a different crew than the one in the practice tasks.

> **Salal Creek Mechanical Ltd. · Site memo 9**
>
> **Project:** Harbour Road Clinic
> **Date:** Tuesday, May 5, 6:45 a.m.
> **From:** Angela Moss, foreman
> **To:** Plumbing crew
>
> 1. The Level 2 washroom fixtures arrive Thursday, not Wednesday.
> 2. The Level 1 rough-in inspection stays Wednesday at 1:00 p.m.
> 3. Drawing P-201 is now revision D. Floor drain FD-3 moves 600 mm north.
> 4. Hot work permits now come from the site office, not the trailer.

The crew's plan for Wednesday before the memo:

| Time | Task |
|---|---|
| 7:00 to 7:15 | Toolbox talk |
| 7:15 to 10:00 | Set Level 2 washroom fixtures |
| 10:15 to 12:00 | Set Level 2 washroom fixtures |
| 12:30 to 1:00 | Prepare for the Level 1 inspection |
| 1:00 to 2:00 | Level 1 inspection |
| 2:00 to 3:30 | Install FD-3 |

**Step 1. Notice.** Read all four items. Check that P-201 on the table is revision D.

**Step 2. Sort.**

| Changed | Stays the same | Still do not know |
|---|---|---|
| Fixtures arrive Thursday | Inspection Wednesday at 1:00 | Is the old FD-3 sleeve already cast in the slab? |
| FD-3 moves 600 mm north (rev D) | Toolbox talk, breaks and lunch | |
| Hot work permits come from the site office | | |

**Step 3. Ask.** One question for Angela: "Rev D moves FD-3 600 mm north. Is the old sleeve already in the slab, and do we core a new hole or wait for the engineer?"

**Step 4. Adjust.** Setting fixtures is gone on Wednesday. That frees 7:15 to 10:00 and 10:15 to 12:00. FD-3 waits for an answer. The new plan:

| Time | Task |
|---|---|
| 7:00 to 7:15 | Toolbox talk. Ask Angela about FD-3. |
| 7:15 to 10:00 | Prepare the Level 1 inspection: check every joint, test, label |
| 10:15 to 12:00 | Stage the Level 2 washrooms for Thursday's fixtures |
| 12:30 to 1:00 | Walk the Level 1 rough-in with Angela |
| 1:00 to 2:00 | Level 1 inspection |
| 2:00 to 3:30 | Install FD-3 at the rev D location if Angela says go. If not, mark the old revision C prints SUPERSEDED and keep staging. |

**Step 5. Check.** At 3:30 the crew checks: inspection done, Level 2 ready for Thursday, FD-3 question answered.

## The change notice

> **Riverbend Framing Ltd. · Site memo 14**
>
> **Project:** Cedar Row Townhomes
> **Date:** Tuesday, March 10
> **From:** Rob Lacey, site superintendent
> **To:** Framing crew
>
> 1. Drawing A-301 is now revision C. In Unit 4, window W3 on the east wall changes from 1220 mm wide to 1525 mm wide. The header for W3 changes. The new header arrives Thursday morning.
> 2. Do not frame the Unit 4 east wall until the new header is on site. All other Unit 4 walls go ahead as planned.
> 3. Rain is forecast for Wednesday afternoon. Cover the lumber stack by noon Wednesday.
> 4. Mark any printed copy of A-301 revision B "SUPERSEDED" and take it out of the site trailer.
> 5. Questions to Rob on radio channel 3.

## Practice

**Task 1** (level 1)
Read Site memo 14. Make three lists: what changed, what stays the same, and what you still do not know. Put at least two items in each list.

| Changed | Stays the same | Still do not know |
|---|---|---|
| | | |
| | | |

**Task 2** (level 2)
This was the crew's plan for Wednesday before the memo. Lunch is 12:00 to 12:30.

| Time | Task |
|---|---|
| 7:00 to 7:15 | Toolbox talk |
| 7:15 to 10:15 | Frame Unit 4 east wall |
| 10:15 to 12:00 | Frame Unit 4 north wall |
| 12:30 to 3:30 | Frame Unit 4 west wall |

a. Which task can no longer happen on Wednesday?
b. How many hours of work does that free up?
c. Write a new plan for Wednesday that follows the memo. Include covering the lumber (allow 30 minutes). Mark one gap where you would ask Rob what to do.

______________________________________________

______________________________________________

**Task 3** (level 2)
For each situation, write **keep trying**, **change the approach**, or **stop and report**, and give a reason.

1. You have practised converting feet and inches to millimetres twice and still mix them up.
2. You have phoned the supplier three times about a noon delivery and nobody answers.
3. The crane is shut down for high wind, and your task needs the crane.
4. The ladder you were given has a cracked rail.
5. Your first try at a stair stringer layout was close, and the second try was better.

**Task 4** (level 1)
List three steady anchors in your own life: people, places, routines or beliefs that stay the same when other things change. This is for you. You do not have to share it.

______________________________________________

**Task 5** (level 2)
Think of a change that was a turning point in your life. You choose how much to write and whether to share it.

a. Did you start the change, or did someone or something else?
b. What did you do at first? What did you do later?
c. What helped you most?

______________________________________________

______________________________________________

## Check yourself

1. What are the five steps when something changes?
2. Name two expected changes you can check for every morning on a job site.
3. When should you never keep trying?
4. What is a steady anchor?
